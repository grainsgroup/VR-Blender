bl_info = {
    "name": "Interface Configurator",
    "description": "",
    "author": "",
    "version": (0, 0, 2),
    "blender": (2, 79, 0),
    "location": "3D View > Tools",
    "warning": "",  # used for warning icon and text in addons panel
    "wiki_url": "",
    "tracker_url": "",
    "category": "Development"
}

import bpy
from mathutils import Vector

from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       EnumProperty,
                       PointerProperty,
                       FloatVectorProperty,
                       )
from bpy.types import (Panel,
                       Operator,
                       PropertyGroup,
                       )


class SceneItemsFunc(bpy.types.PropertyGroup):
    When = bpy.props.EnumProperty(
        name="When",
        description="Apply Data to attribute.",
        items=[('VR_CONTROL', "VR button", ""),
               ('GRIPPER.R_Down', "Gripper.R (onKeyDown)", ""),
               ('GRIPPER.R_Press', "Gripper.R (onKeyPress)", ""),
               ('GRIPPER.R_Up', "Gripper.R (onKeyUp)", ""),
               ('GRIPPER.L_Down', "Gripper.L (onKeyDown)", ""),
               ('GRIPPER.L_Press', "Gripper.L (onKeyPress)", ""),
               ('GRIPPER.L_Up', "Gripper.L (onKeyUp)", ""),
               ]
    )
    Do = bpy.props.StringProperty()


class SceneItems(bpy.types.PropertyGroup):
    Do = bpy.props.StringProperty()
    When = bpy.props.EnumProperty(
        name="When",
        description="Apply Data to attribute.",
        items=[('VR_CONTROL', "VR control", ""),
               ('TRACKPAD_UR.R_Press', "TrackpadUR.R (onKeyPress)", ""),
               ('TRACKPAD_UR.R_Up', "TrackpadUR.R (onKeyUp)", ""),
               ('TRACKPAD_UL.R_Press', "TrackpadUL.R (onKeyPress)", ""),
               ('TRACKPAD_UL.R_Up', "TrackpadUL.R (onKeyUp)", ""),
               ('TRACKPAD_BR.R_Press', "TrackpadBR.R (onKeyPress)", ""),
               ('TRACKPAD_BR.R_Up', "TrackpadBR.R (onKeyUp)", ""),
               ('TRACKPAD_BL.R_Press', "TrackpadBL.R (onKeyPress)", ""),
               ('TRACKPAD_BL.R_Up', "TrackpadBL.R (onKeyUp)", ""),
               ('TRACKPAD_UR.L_Press', "TrackpadUR.L (onKeyPress)", ""),
               ('TRACKPAD_UR.L_Up', "TrackpadUR.L (onKeyUp)", ""),
               ('TRACKPAD_UL.L_Press', "TrackpadUL.L (onKeyPress)", ""),
               ('TRACKPAD_UL.L_Up', "TrackpadUL.L (onKeyUp)", ""),
               ('TRACKPAD_BR.L_Press', "TrackpadBR.L (onKeyPress)", ""),
               ('TRACKPAD_BR.L_Up', "TrackpadBR.L (onKeyUp)", ""),
               ('TRACKPAD_BL.L_Press', "TrackpadBL.L (onKeyPress)", ""),
               ('TRACKPAD_BL.L_Up', "TrackpadBL.L (onKeyUp)", ""),
               ]
    )


class AddButtonFuncOperator(bpy.types.Operator):
    bl_idname = "scene.add_button_func_operator"
    bl_label = "Add Function"

    def execute(self, context):
        id = len(context.scene.collection_func)
        new = context.scene.collection_func.add()
        new.name = str(id)
        return {'FINISHED'}


class ClearButtonFuncOperator(bpy.types.Operator):
    bl_idname = "scene.cler_button_func_operator"
    bl_label = "Clear"

    def execute(self, context):
        context.scene.collection_func.clear()
        return {'FINISHED'}


class AddButtonOperator(bpy.types.Operator):
    bl_idname = "scene.add_button_operator"
    bl_label = "Add Control"

    def execute(self, context):
        id = len(context.scene.collection)
        new = context.scene.collection.add()
        new.name = str(id)
        new.value = id
        return {'FINISHED'}


class ClearButtonOperator(bpy.types.Operator):
    bl_idname = "scene.cler_button_operator"
    bl_label = "Clear"

    def execute(self, context):
        context.scene.collection.clear()
        return {'FINISHED'}


class ButtonOperator(bpy.types.Operator):
    bl_idname = "scene.button_operator"
    bl_label = ""

    id = bpy.props.IntProperty()

    def execute(self, context):
        # print("Pressed button ", self.id)
        context.scene.collection_func.remove(self.id)

        return {'FINISHED'}


class RemoveButtonOperator(bpy.types.Operator):
    bl_idname = "scene.button_operator_remove"
    bl_label = ""

    id = bpy.props.IntProperty()

    def execute(self, context):
        # print("Pressed button ", self.id)
        context.scene.collection.remove(self.id)

        return {'FINISHED'}


class ButtonOperatorVR(bpy.types.Operator):
    bl_idname = "scene.button_operator_vr"
    bl_label = "Get in VR"
    height_func = Vector((0, 0, 0))
    layers = (False, False, True, False, False,
              False, False, False, False, False,
              False, False, False, False, False,
              False, False, False, False, False)

    def createFuncPanel(self, item):
        print ("[DEBUG] - createFuncPanel: start")
        scn = bpy.context.scene
        src_obj = bpy.data.objects['SettingsPanelFunction']
        new_obj = src_obj.copy()
        new_obj.data = src_obj.data.copy()
        scn.objects.link(new_obj)
        new_obj.layers = self.layers
        # new_obj.hide = True

        bpy.types.Scene.gui.append(new_obj.name)

        for child in src_obj.children:
            new_obj_children = child.copy()
            new_obj_children.data = child.data.copy()
            new_obj_children.parent = new_obj
            scn.objects.link(new_obj_children)
            new_obj_children.layers = self.layers
            # new_obj_children.hide = True

            bpy.types.Scene.gui.append(new_obj_children.name)

            if "Button.ApplyFunc" in new_obj_children.name:
                bpy.types.Scene.gui_map[new_obj_children.name] = item.Do

            if "TextBox_PropertyControl" in new_obj_children.name:
                targetObject, value = self.setLabel(item.Do)
                new_obj_children.data.body = targetObject + "\n" + value

        new_obj.location = self.height_func
        self.height_func[2] += new_obj.dimensions[2]

    def createControlPanel(self, item):
        scn = bpy.context.scene
        src_obj = bpy.data.objects['SettingsPanelControl']
        new_obj = src_obj.copy()
        new_obj.data = src_obj.data.copy()
        scn.objects.link(new_obj)
        new_obj.layers = self.layers
        # new_obj.hide = True

        bpy.types.Scene.gui.append(new_obj.name)

        for child in src_obj.children:
            new_obj_children = child.copy()
            new_obj_children.data = child.data.copy()
            new_obj_children.parent = new_obj
            scn.objects.link(new_obj_children)
            new_obj_children.layers = self.layers
            # new_obj_children.hide = True

            bpy.types.Scene.gui.append(new_obj_children.name)

            if "Button.IncreaseValue" in new_obj_children.name:
                bpy.types.Scene.gui_map[new_obj_children.name] = item.Do
            if "Button.DecreaseValue" in new_obj_children.name:
                bpy.types.Scene.gui_map[new_obj_children.name] = item.Do
            if "TextBox_Property" in new_obj_children.name:
                targetObject, value = self.setLabel(item.Do)
                new_obj_children.data.body = targetObject + "\n" + value
            if "TextBox_Value" in new_obj_children.name:
                if item.Do in bpy.types.Scene.value_textBox_map:
                    bpy.types.Scene.value_textBox_map[item.Do].append(new_obj_children.name)
                else:
                    bpy.types.Scene.value_textBox_map[item.Do] = [new_obj_children.name]
                try:
                    val = eval(item.Do)
                    new_obj_children.data.body = str(val)
                except:
                    new_obj_children.data.body = 'Value N/A'

        new_obj.location = self.height_func
        self.height_func[2] += new_obj.dimensions[2]

    def createPanel(self, item, showValue):
        scn = bpy.context.scene
        src_obj = bpy.data.objects['SettingsPanelControl']
        new_obj = src_obj.copy()
        new_obj.data = src_obj.data.copy()
        scn.objects.link(new_obj)
        new_obj.layers = self.layers

        bpy.types.Scene.gui.append(new_obj.name)

        for child in src_obj.children:

            if "TextBox_Property" in child.name:
                new_obj_children = child.copy()
                new_obj_children.data = child.data.copy()
                new_obj_children.parent = new_obj
                scn.objects.link(new_obj_children)
                new_obj_children.layers = self.layers
                # new_obj_children.hide = True
                bpy.types.Scene.gui.append(new_obj_children.name)

                targetObject, value = self.setLabel(item.Do)
                new_obj_children.data.body = targetObject + "\n" + value + "\n" + item.When

            if "TextBox_Value" in child.name and showValue:
                new_obj_children = child.copy()
                new_obj_children.data = child.data.copy()
                new_obj_children.parent = new_obj
                scn.objects.link(new_obj_children)
                new_obj_children.layers = self.layers
                # new_obj_children.hide = True

                bpy.types.Scene.gui.append(new_obj_children.name)

                if item.Do in bpy.types.Scene.value_textBox_map:
                    bpy.types.Scene.value_textBox_map[item.Do].append(new_obj_children.name)
                else:
                    bpy.types.Scene.value_textBox_map[item.Do] = [new_obj_children.name]

                try:
                    val = eval(item.Do)
                    new_obj_children.data.body = str(val)
                except:
                    new_obj_children.data.body = 'Value N/A'

        new_obj.location = self.height_func
        # new_obj.hide = True
        self.height_func[2] += new_obj.dimensions[2]

    def setLabel(self, value):
        print ("LABEL")

        # [0] - Object
        # [1] - Bone
        # [2] - Constraint
        # [3] - Modifier
        # [.] - ...
        targetObject = ["Generic", "", "", ""]

        # print (1, "." in value, value)
        # Get the last attribute of the path
        if "." in value:
            indices = [i for i, ltr in enumerate(value) if ltr == "."]
            valueToReturn = value[indices[-1] + 1:]

        # print (2, "bpy.context.object", value)
        if "bpy.context.object" in value:
            targetObject[0] = "Selected object"

        if "object.constraint_add" in value:
            targetObject[0] = "Selected object"

        if "object.modifier_add" in value:
            targetObject[0] = "Selected object"

        if "object.shade_" in value:
            targetObject[0] = "Selected object"

            # print (3, ".objects['" in value, value)
        if ".objects['" in value:
            targetObject[0] = value.split(".objects['")[1].split("'].")[0]

        # print (4, '.objects["' in value in value, value)
        if '.objects["' in value:
            targetObject[0] = value.split('.objects["')[1].split('"].')[0]

        # print (5, "SELECTED_OBJECT" in value, value)
        if "SELECTED_OBJECT" in value:
            targetObject[0] = "Selected object"

        # print (6, '.bones["' in value, value)
        if '.bones["' in value:
            targetObject[1] = value.split('.bones["')[1].split('"].')[0]

        # print (7, "SELECTED_BONE" in value, value)
        if "SELECTED_BONE" in value:
            targetObject[1] = "Selected bone"

        if '.constraints["' in value:
            targetObject[2] = value.split('.constraints["')[1].split('"].')[0]

        if "SELECTED_CONSTRAINTS" in value:
            targetObject[1] = "Selected constraint"

        if 'bpy.ops.pose' in value:
            targetObject[0] = "Selected object"
            targetObject[1] = "Selected bone"

        if '.modifiers["' in value:
            targetObject[3] = value.split('.modifiers["')[1].split('"].')[0]

        targetObjToReturn = targetObject[0]
        for i in range(1, len(targetObject)):
            tarObj = targetObject[i]
            if tarObj != "":
                targetObjToReturn = targetObjToReturn + " : " + tarObj

        return targetObjToReturn, valueToReturn
        # if "(" in value:
        #    value = value.split("(")[0]

    def reset_map(self):
        # delete gui elements
        for obj in bpy.data.objects:
            if 'SettingsPanelFunction.' in obj.name or 'SettingsPanelControl.' in obj.name:
                for child in obj.children:
                    bpy.data.scenes[0].objects.unlink(child)
                    bpy.data.objects.remove(child)
                bpy.data.scenes[0].objects.unlink(obj)
                bpy.data.objects.remove(obj)

        # reset data structure
        bpy.types.Scene.gui_map.clear()
        bpy.types.Scene.value_textBox_map.clear
        bpy.types.Scene.gui = ['SettingsPanelFunction', 'TextBox_PropertyControl', 'Button.ApplyFunc',
                               'SettingsPanelControl', 'Button.DecreaseValue', 'Button.IncreaseValue',
                               'TextBox_Property', 'TextBox_Value']

        for item in bpy.types.Scene.controller_map:
            bpy.types.Scene.controller_map[item] = ""

    def execute(self, context):
        self.height_func = Vector((0, 0, 0))
        self.reset_map()

        for i in range(0, len(context.scene.collection_func)):
            item = context.scene.collection_func[i]

            if item.When == 'VR_CONTROL':  # if When = VR control
                # Creates a copy of the SettinfsPanelFucntionObject
                if item.Do != "":
                    self.createFuncPanel(item)
            else:
                self.createPanel(item, False)
                bpy.types.Scene.controller_map[item.When] = item.Do

        for i in range(0, len(context.scene.collection)):
            item = context.scene.collection[i]

            if item.When == 'VR_CONTROL':  # if When = VR control
                # Creates a copy of the SettingsPanelControl
                # Add item in the gui_map dict
                if item.Do != "":
                    self.createControlPanel(item)
            else:
                self.createPanel(item, True)
                bpy.types.Scene.controller_map[item.When] = item.Do

        print ("---------------------")
        print ("Configuration created")
        print ("---------------------")
        print ("\n 1) Scene.controller_map")
        for i in bpy.types.Scene.controller_map:
            print(i, bpy.types.Scene.controller_map[i])
        print ("\n 2) Scene.gui_map")
        for i in bpy.types.Scene.gui_map:
            print(i, bpy.types.Scene.gui_map[i])
        print ("\n 3) Scene.gui")
        for i in bpy.types.Scene.gui:
            print(i)
        print ("\n 4)Scene.value_textBox_map")
        for i in bpy.types.Scene.value_textBox_map:
            print(i, bpy.types.Scene.value_textBox_map[i])
        print ("---------------------")

        return {'FINISHED'}


class FancyPanel(bpy.types.Panel):
    bl_label = "Custom VR Mapping"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_category = 'Custom VR Mapping'

    def draw(self, context):
        #
        # Functions
        #
        row = self.layout.row(align=True)
        row.operator("scene.add_button_func_operator")
        row.operator("scene.cler_button_func_operator")
        for i in range(0, len(context.scene.collection_func)):
            item = context.scene.collection_func[i]
            row = self.layout.row(align=True)
            row.operator("scene.button_operator", icon='ZOOMOUT').id = i
            row.prop(item, "When")
            row.prop(item, "Do")

        #
        # Control
        #
        self.layout.separator()
        row = self.layout.row(align=True)
        row.operator("scene.add_button_operator")
        row.operator("scene.cler_button_operator")

        for i in range(0, len(context.scene.collection)):
            item = context.scene.collection[i]
            row = self.layout.row(align=True)
            row.operator("scene.button_operator_remove", icon='ZOOMOUT').id = i
            row.prop(item, "When")
            row.prop(item, "Do")

        #
        # Get in VR button
        #
        self.layout.separator()
        self.layout.operator("scene.button_operator_vr")



def register():
    #bpy.utils.register_module(__name__)

    bpy.utils.register_class(SceneItems)
    bpy.utils.register_class(SceneItemsFunc)
    bpy.utils.register_class(AddButtonOperator)
    bpy.utils.register_class(ClearButtonOperator)
    bpy.utils.register_class(AddButtonFuncOperator)
    bpy.utils.register_class(ClearButtonFuncOperator)
    bpy.utils.register_class(ButtonOperator)
    bpy.utils.register_class(RemoveButtonOperator)
    bpy.utils.register_class(ButtonOperatorVR)
    bpy.utils.register_class(FancyPanel)

    bpy.types.Scene.collection = bpy.props.CollectionProperty(type=SceneItems)
    bpy.types.Scene.collection_func = bpy.props.CollectionProperty(type=SceneItemsFunc)
    bpy.types.Scene.gui_map = {}
    bpy.types.Scene.controller_map = {'GRIPPER.R_Down': "", 'GRIPPER.R_Press': "", 'GRIPPER.R_Up': "",
                                      'GRIPPER.L_Down': "",
                                      'GRIPPER.L_Press': "", 'GRIPPER.L_Up': "", 'TRACKPAD_UR.R_Up': "",
                                      'TRACKPAD_UL.R_Up': "", 'TRACKPAD_BR.R_Up': "", 'TRACKPAD_BL.R_Up': "",
                                      'TRACKPAD_UR.L_Up': "", 'TRACKPAD_UL.L_Up': "", 'TRACKPAD_BR.L_Up': "",
                                      'TRACKPAD_BL.L_Up': "", 'TRACKPAD_UR.R_Press': "", 'TRACKPAD_UL.R_Press': "",
                                      'TRACKPAD_BR.R_Press': "", 'TRACKPAD_BL.R_Press': "", 'TRACKPAD_UR.L_Press': "",
                                      'TRACKPAD_UL.L_Press': "", 'TRACKPAD_BR.L_Press': "", 'TRACKPAD_BL.L_Press': ""}
    bpy.types.Scene.gui = ['SettingsPanelFunction', 'TextBox_PropertyControl', 'Button.ApplyFunc',
                           'SettingsPanelControl',
                           'Button.DecreaseValue', 'Button.IncreaseValue', 'TextBox_Property', 'TextBox_Value']
    bpy.types.Scene.value_textBox_map = {}

if __name__ == "__main__":
    register()



