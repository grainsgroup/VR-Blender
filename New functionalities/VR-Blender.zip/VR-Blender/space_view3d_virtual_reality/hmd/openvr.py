"""
OpenVR Compatible (HTC Vive)
=============

OpenVR Compatible head mounted display
It uses a python wrapper to connect with the SDK
"""
import threading
import openvr
import bpy
import math
import sys
import copy
from enum import Enum
from mathutils import Quaternion
from mathutils import Matrix
from mathutils import Vector
import winsound

import time

from . import HMD_Base

from ..lib import (
        checkModule,
        )


# ---------------------------------------- #
#   Global Variable
# ---------------------------------------- #

recordFlag = False
playingAnimation = False
currObject = ""
currBone = ""
currObject_l = ""
currBone_l =""
speedPlayRec = 1
recordMode = [True, True, True] # 'LOC', 'ROT', 'SCALE'
mode = "ACTION"                 # 'ACTION', 'KEYFRAME', 'CURVE', 'TUNING', 'EDIT_ACTION', 'FCURVE', 'RIGGING', 'SKINNING', 'CONSTRAINTS'
timelineScale = 1
samplingRate = 4
objectActions = []
curr_frames_r = []
curr_frames_l = []
pointIndex_r = -1
pointIndex_l = -1
actions = []
actionsProp = []
actionsPath = []
property_frame = []
local_repr_ON = False
path_ON = False
prop_ON = False
perf_mode_ON = True


# ---------------------------------------- #
#   Functions
# ---------------------------------------- #

def drawAction(obj, bone, selectState, isRight):
    global actions

    if isRight:
        actionText = bpy.data.objects["Action_Text.R"]

    else:
        actionText = bpy.data.objects["Action_Text.L"]

    if selectState:
        if obj != "":
            if bone != "":
                actionText.data.body = obj + "-" + bone
                actionText.hide = False
            else:
                actionText.data.body = obj
                actionText.hide = False
            print("DEBUG [drawAction] - text setted to:", actionText.data.body)

            for a in actions:
                if a.obj == obj and a.bone == bone and len(a.frames)>0:
                    a.frames.sort(key=lambda x: x.frame, reverse=False)
                    print ("DEBUG [drawAction] - action duration:", a.frames[-1].frame - a.frames[0].frame)
                    act = createPlane("action")
                    act.dimensions = ((a.frames[-1].frame - a.frames[0].frame) / 100, 0, 0.150)
                    act.parent = bpy.data.objects['TimelineRoot']

                    if isRight:
                        act.location = ((a.frames[-1].frame - a.frames[0].frame) / 200 + a.frames[0].frame/100, -0.015, 0.12)
                        act.name = a.name
                    else:
                        act.location = ((a.frames[-1].frame - a.frames[0].frame) / 200 + a.frames[0].frame/100, -0.015, -0.07)
                        act.name = a.name

                    act.data.materials.append(bpy.data.materials['GazeCursor.000'])

    else:
        actionText.hide = True
        recursive_delete_children()
        print ("DESTROY ACTIONS")

def drawActionProp(obj, bone, selectState):
    global actionsProp
    actionText = bpy.data.objects["Action_Text.R"]

    if selectState:
        if obj != "":
            if bone != "":
                actionText.data.body = obj + "-" + bone
                actionText.hide = False
            else:
                actionText.data.body = obj
                actionText.hide = False
            print("DEBUG [drawAction] - text setted to:", actionText.data.body)

            for a in actionsProp:
                if a.obj == obj and a.bone == bone and len(a.frames)>0:
                    a.frames.sort(key=lambda x: x.frame, reverse=False)
                    print ("DEBUG [drawAction] - action duration:", a.frames[-1].frame - a.frames[0].frame)
                    act = createPlane("action")
                    act.dimensions = ((a.frames[-1].frame - a.frames[0].frame) / 100, 0, 0.150)
                    act.parent = bpy.data.objects['TimelineRoot']

                    act.location = ((a.frames[-1].frame - a.frames[0].frame) / 200 + a.frames[0].frame/100, -0.015, 0.12)
                    act.name = a.name

                    act.data.materials.append(bpy.data.materials['GazeCursor.000'])

    else:
        actionText.hide = True
        recursive_delete_children()
        print ("DESTROY ACTIONS")

def drawActionPath(obj, bone, selectState):
    global actionsPath
    actionText = bpy.data.objects["Action_Text.R"]

    if selectState:
        if obj != "":
            if bone != "":
                actionText.data.body = obj + "-" + bone
                actionText.hide = False
            else:
                actionText.data.body = obj
                actionText.hide = False
            print("DEBUG [drawAction] - text setted to:", actionText.data.body)

            for a in actions:
                if a.obj == obj and a.bone == bone and len(a.frames)>0:
                    a.frames.sort(key=lambda x: x.frame, reverse=False)
                    print ("DEBUG [drawAction] - action duration:", a.frames[-1].frame - a.frames[0].frame)
                    act = createPlane("action")
                    act.dimensions = ((a.frames[-1].frame - a.frames[0].frame) / 100, 0, 0.150)
                    act.parent = bpy.data.objects['TimelineRoot']

                    act.location = ((a.frames[-1].frame - a.frames[0].frame) / 200 + a.frames[0].frame/100, -0.015, 0.12)
                    act.name = a.name

                    act.data.materials.append(bpy.data.materials['GazeCursor.000'])

    else:
        actionText.hide = True
        recursive_delete_children()
        print ("DESTROY ACTIONS")

def getBoneCurves(objName, bName):
    fcurve = bpy.data.objects[objName].animation_data.action.fcurves
    boneCurves = []
    bones = []

    for i in range(0, len(fcurve.items())):
        boneName = fcurve[i].data_path.split('"')[1]
        if not boneName in bones:
            bones.append(boneName)
            boneCurves.append([])

        boneCurves[bones.index(boneName)].append(fcurve[i])

    return boneCurves, bones

## Draw the red action
def drawActions_Overview(objName, bName):
    if animDataExist(objName):
        if bName!="":
            boneCurves, bones = getBoneCurves(objName,bName)

            frames = []
            for boneIndex in range(0, len(boneCurves)):
                boneCurve = boneCurves[boneIndex]
                frames += getFrameFromCurve(boneCurve, objName, bones[boneIndex])



        else:
            frames = getFrameFromCurve(bpy.data.objects[objName].animation_data.action.fcurves, objName, bName)

        global objectActions
        min, max = frames[0].frame, frames[0].frame
        for f in frames:
            if f.obj == objName:
                if f.frame < min:
                    min = f.frame
                if f.frame > max:
                    max = f.frame

        if objName in objectActions:
            action = bpy.data.objects['Action.' + objName]
            text = bpy.data.objects['Text.' + objName]
            slot = objectActions.index(objName)

        else:
            action = createPlane("Action." + objName)
            action.data.materials.append(bpy.data.materials['Material_LOC'])

            text = bpy.data.objects['TextBox.001'].copy()
            text.data = bpy.data.objects['TextBox.001'].data.copy()
            text.name = "Text." + objName
            text.data.body = objName
            text.scale = (0.5, 0.5, 1)
            bpy.context.scene.objects.link(text)
            text.layers = (True, False, False, False, False,
                     False, False, False, False, False,
                     False, False, False, False, False,
                     False, False, False, False, False)

            slot = len(objectActions)
            objectActions.append(objName)

        action.location = bpy.data.objects['Timeline'].matrix_world * Vector(
            ((max - min) / 200 + min / 100, 0, 0.22 + 0.045 * slot))
        action.dimensions = ((max - min) / 100, 0, 0.04)
        text.location = action.location - Vector((0, 0.002, 0.008))
        text.hide = False


    else:
        if objName in objectActions:
            action = bpy.data.objects['Action.' + objName]
            action.dimensions = (0, 0, 0.04)




## Returns a new mesh of a plane linked to the Blender scene
def createPlane(name):
    mesh = bpy.data.meshes.new(name)
    verts = [(-1,0,-1), (1,0,-1), (1,0,1), (-1,0,1)]
    faces = [(0, 1, 2, 3)]
    mesh.from_pydata(verts, [], faces)
    mesh.update(calc_edges=True)
    newObj = bpy.data.objects.new(name, mesh)

    bpy.context.scene.objects.link(newObj)

    newObj.layers = (True, False, False, False, False,
                     False, False, False, False, False,
                     False, False, False, False, False,
                     False, False, False, False, False)

    return newObj

## Insert the graphic representation of the key frame
def insertKeyFrameMesh(isRight):

    if isRight:
        global curr_frames_r
        listOfFrame = curr_frames_r
    else:
        global  curr_frames_l
        listOfFrame = curr_frames_l

    for f in listOfFrame:
        frame = createPlane("frame")
        frame.dimensions = (0.005, 0, 0.150)
        frame.parent = bpy.data.objects['TimelineRoot']

        if isRight:
            frame.location = (f.frame / 100, -0.015, 0.12)
            frame.name = 'frame_' + str(f.frame) + ".R"
        else:
            frame.location = (f.frame / 100, -0.015, -0.07)
            frame.name = 'frame_' + str(f.frame) + ".L"

        frame.data.materials.append(bpy.data.materials['Material_LOC/ROT'])

        '''
        if f.frameType == "LOC":
            frame.data.materials.append(bpy.data.materials['Material_LOC'])

        if f.frameType == "ROT":
            frame.data.materials.append(bpy.data.materials['Material_ROT'])

        if f.frameType == "LOC/ROT":
            frame.data.materials.append(bpy.data.materials['Material_LOC/ROT'])
        '''

## recursive delete
def recursive_delete_children():
    for child in bpy.data.objects['TimelineRoot'].children:
        bpy.data.scenes[0].objects.unlink(child)
        bpy.data.objects.remove(child)

## Insert key frame
def insertFrame(frame):
    for f in frame:
        print ("DEBUG [insertFrame] - Frame: ", f.frame, f.frameType,"LOC:",f.loc, "ROT",f.rot, "SCALE",f.scale, "Bone:",f.bone)
        if f.bone!="":
            obj = bpy.data.objects[f.obj]
            pbone = obj.pose.bones[f.bone]
            pbone.rotation_mode = 'QUATERNION'
            pbone.location = f.loc
            pbone.rotation_quaternion = f.rot
            pbone.scale = f.scale

            global local_repr_ON
            if local_repr_ON and '_Local.Repr' in f.obj:
                pboneTarget = bpy.data.objects[f.obj.split('_Local.Repr')[0]].pose.bones[f.bone]
                pboneTarget.rotation_mode = 'QUATERNION'
                pboneTarget.location = f.loc
                pboneTarget.rotation_quaternion = f.rot
                pboneTarget.scale = f.scale
                print ("INSERT KEYFRAME for:", bpy.data.objects[f.obj.split('_Local.Repr')[0]].name,
                       bpy.data.objects[f.obj.split('_Local.Repr')[0]].pose.bones[f.bone].name)

            if f.frameType[0]:
                pbone.keyframe_insert(data_path='location', frame=f.frame)
                global local_repr_ON
                if local_repr_ON and '_Local.Repr' in f.obj:
                    pboneTarget.keyframe_insert(data_path='location',frame=f.frame)

            if f.frameType[1]:
                pbone.keyframe_insert(data_path='rotation_quaternion', frame=f.frame)
                global local_repr_ON
                if local_repr_ON and '_Local.Repr' in f.obj:
                    pboneTarget.keyframe_insert(data_path='rotation_quaternion', frame=f.frame)

            if f.frameType[2]:
                pbone.keyframe_insert(data_path='scale', frame=f.frame)
                global local_repr_ON
                if local_repr_ON and '_Local.Repr' in f.obj:
                    pboneTarget.keyframe_insert(data_path='scale', frame=f.frame)

        else:
            obj = bpy.data.objects[f.obj]
            obj.rotation_mode = 'QUATERNION'
            obj.location = f.loc
            obj.rotation_quaternion = f.rot
            obj.scale = f.scale

            global local_repr_ON
            if local_repr_ON and '_Local.Repr' in f.obj:
                objTarget = bpy.data.objects[f.obj.split('_Local.Repr')[0]]
                objTarget.rotation_mode = 'QUATERNION'
                objTarget.location = f.loc
                objTarget.rotation_quaternion = f.rot
                objTarget .scale = f.scale

            if f.frameType[0]:
                obj.keyframe_insert(data_path='location', frame=f.frame)
            if f.frameType[1]:
                obj.keyframe_insert(data_path='rotation_quaternion', frame=f.frame)
                global local_repr_ON
                if local_repr_ON and '_Local.Repr' in f.obj:
                    objTarget.keyframe_insert(data_path='rotation_quaternion', frame=f.frame)
            if f.frameType[2]:
                obj.keyframe_insert(data_path='scale', frame=f.frame)
                global local_repr_ON
                if local_repr_ON and '_Local.Repr' in f.obj:
                    objTarget.keyframe_insert(data_path='scale', frame=f.frame)

    print("Finished")

## Check if the object contain animation data
def animDataExist(obj):

    try:
        # checks if the object contain animation data
        if bpy.data.objects[obj].animation_data != None:
            if bpy.data.objects[obj].animation_data.action != None:
                if len(bpy.data.objects[obj].animation_data.action.fcurves.items()) > 0:
                    return True
        return False
    except:
        return False

def getFrameFromCurve(boneCurve, obj, bone):
    frames = []
    index_frame = []

    for b in boneCurve:
        for point in range(0, len(b.keyframe_points)):

            #print ("DEBUG [getFrameFromCurve] - points:" , b.data_path, b.array_index, b.keyframe_points[point].co[0],b.keyframe_points[point].co[1])
            if b.keyframe_points[point].co[0] in index_frame:
                # the frame is already implemented, only an update is required
                f = frames[index_frame.index(b.keyframe_points[point].co[0])]
                #print ("DEBUG [getFrameFromCurve] - frame to modify:", f.frame, f.frameType, f.loc, f.rot)

            else:
                index_frame.append(b.keyframe_points[point].co[0])
                f = Keyframe(b.keyframe_points[point].co[0], Vector((1, 0, 0, 0)), Vector((0, 0, 0)), Vector((1, 1, 1)), obj, bone, [True, True, True])
                frames.append(f)


            if 'location' in b.data_path:
                f.loc[b.array_index] = b.keyframe_points[point].co[1]
                f.frameType[0] = True

            if 'rotation_quaternion' in b.data_path:
                f.rot[b.array_index] = b.keyframe_points[point].co[1]
                f.frameType[1] = True

            if 'scale' in b.data_path:
                f.scale[b.array_index] = b.keyframe_points[point].co[1]
                f.frameType[2] = True

            #print ("DEBUG [getFrameFromCurve] - frame:", f.frame,f.frameType, f.loc, f.rot)

            # type = b.data_path
            # chanel = b.array_index
            # #frame = b.keyframe_points[point].co[0]
            # valore = b.keyframe_points[point].co[1]

    frames.sort(key=lambda x: x.frame, reverse=False)
    return frames

'''
def getFrameFromCurve(boneCurve, obj, bone):
    frame = []
    print ("DEBUG [getFrameFromCurve] - pre for loop:")

    for point in range(0, len(boneCurve[0].keyframe_points)):
        frameType = "LOC/ROT"
        try:
            boneCurve[6].keyframe_points[point].co[1]
        except:
            frameType = "ROT"
            try:
                boneCurve[3].keyframe_points[point].co[1]
            except:
                frameType = "LOC"

        print ("DEBUG [getFrameFromCurve] - frameType:",frameType)

        if frameType == "LOC/ROT":
            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                  Quaternion((boneCurve[0].keyframe_points[point].co[1],
                                              boneCurve[1].keyframe_points[point].co[1],
                                              boneCurve[2].keyframe_points[point].co[1],
                                              boneCurve[3].keyframe_points[point].co[1])),
                                  Vector([boneCurve[4].keyframe_points[point].co[1],
                                          boneCurve[5].keyframe_points[point].co[1],
                                          boneCurve[6].keyframe_points[point].co[1]]),
                                  obj, bone, frameType))

        if frameType == "LOC":
            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                  Quaternion((1.0, 0, 0, 0)),
                                  Vector([boneCurve[0].keyframe_points[point].co[1],
                                          boneCurve[1].keyframe_points[point].co[1],
                                          boneCurve[2].keyframe_points[point].co[1]]),
                                  obj, bone, frameType))

        if frameType == "ROT":
            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                  Quaternion((boneCurve[0].keyframe_points[point].co[1],
                                              boneCurve[1].keyframe_points[point].co[1],
                                              boneCurve[2].keyframe_points[point].co[1],
                                              boneCurve[3].keyframe_points[point].co[1])),
                                  Vector([0, 0, 0]),
                                  obj, bone, frameType))

        print ("DEBUG [getFrameFromCurve] - frame defined:", len(frame))

    return frame
'''

'''
def getFrameFromCurve(boneCurve, obj, bone):
    frame = []

    print (len(boneCurve),obj,bone)

    if len(boneCurve) == 3:
        frameType = "LOC"
    if len(boneCurve) == 4:
        frameType = "ROT"
    if len(boneCurve) == 7:
        frameType = "LOC/ROT"


    for point in range(0, len(boneCurve[0].keyframe_points)):
        if frameType == "LOC/ROT":
            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                  Quaternion((boneCurve[0].keyframe_points[point].co[1],
                                              boneCurve[1].keyframe_points[point].co[1],
                                              boneCurve[2].keyframe_points[point].co[1],
                                              boneCurve[3].keyframe_points[point].co[1])),
                                  Vector([boneCurve[4].keyframe_points[point].co[1],
                                          boneCurve[5].keyframe_points[point].co[1],
                                          boneCurve[6].keyframe_points[point].co[1]]),
                                  obj, bone, frameType))

        if frameType == "LOC":
            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                  Quaternion((1.0, 0, 0, 0)),
                                  Vector([boneCurve[0].keyframe_points[point].co[1],
                                          boneCurve[1].keyframe_points[point].co[1],
                                          boneCurve[2].keyframe_points[point].co[1]]),
                                  obj, bone, frameType))

        if frameType == "ROT":
            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                  Quaternion((boneCurve[0].keyframe_points[point].co[1],
                                              boneCurve[1].keyframe_points[point].co[1],
                                              boneCurve[2].keyframe_points[point].co[1],
                                              boneCurve[3].keyframe_points[point].co[1])),
                                  Vector([0, 0, 0]),
                                  obj, bone, frameType))
    return frame
'''

def deleteAction(obj,bone):
    print ("DELETING ANIMATION DATA FOR: ", obj, bone)
    if obj!="":
        if bone != "":
            if animDataExist(obj):
                print("ANIMATIONA data exist")
                boneCurves, bones = getBoneCurves(obj,bone)

                '''
                fcurve = bpy.data.objects[obj].animation_data.action.fcurves

                boneCurves = []
                bones = []

                for i in range(0, len(fcurve.items())):
                    boneName = fcurve[i].data_path.split('"')[1]
                    if boneName != bone:
                        if not boneName in bones:
                            bones.append(boneName)
                            boneCurves.append([])

                        boneCurves[bones.index(boneName)].append(fcurve[i])
                '''

                frame = []
                for boneIndex in range (0, len (boneCurves)):
                    boneCurve = boneCurves[boneIndex]
                    frame += getFrameFromCurve(boneCurve,obj,bones[boneIndex])

                    '''
                    if len(boneCurve)==3:
                        frameType = "LOC"
                    if len(boneCurve)==4:
                        frameType = "ROT"
                    if len(boneCurve)==7:
                        frameType = "LOC/ROT"

                    for point in range(0, len(boneCurve[0].keyframe_points)):
                        if frameType == "LOC/ROT":
                            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                                  Quaternion((boneCurve[0].keyframe_points[point].co[1],
                                                              boneCurve[1].keyframe_points[point].co[1],
                                                              boneCurve[2].keyframe_points[point].co[1],
                                                              boneCurve[3].keyframe_points[point].co[1])),
                                                  Vector([boneCurve[4].keyframe_points[point].co[1],
                                                          boneCurve[5].keyframe_points[point].co[1],
                                                          boneCurve[6].keyframe_points[point].co[1]]),
                                                  obj, bones[boneIndex],frameType))
                        if frameType == "LOC":
                            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                                  Quaternion((1.0,0,0,0)),
                                                  Vector([boneCurve[0].keyframe_points[point].co[1],
                                                          boneCurve[1].keyframe_points[point].co[1],
                                                          boneCurve[2].keyframe_points[point].co[1]]),
                                                  obj, bones[boneIndex],frameType))
                        if frameType == "ROT":
                            frame.append(Keyframe(boneCurve[0].keyframe_points[point].co[0],
                                                  Quaternion((boneCurve[0].keyframe_points[point].co[1],
                                                              boneCurve[1].keyframe_points[point].co[1],
                                                              boneCurve[2].keyframe_points[point].co[1],
                                                              boneCurve[3].keyframe_points[point].co[1])),
                                                  Vector([0,0,0]),
                                                  obj, bones[boneIndex],frameType))
                        '''

                bpy.data.objects[obj].animation_data_clear()

                insertFrame(frame)
                drawActions_Overview(obj,bone)

                '''
                ## IDENTIFY FRAME TYPE
                fcurve = bpy.data.objects[obj].animation_data.action.fcurves
                for i in range(0, len(fcurve.items())):
                    splitted = fcurve[i].data_path.split('"')
                    for c in splitted:
                        print (splitted)
                        if "rotation_quaternion" in splitted[2]:
                            print ("QUAT")
                        if "location" in splitted[2]:
                            print ("LOC")
                '''

                '''
                fcurve = bpy.data.objects[obj].animation_data.action.fcurves
                for i in range(0, len(fcurve.items())):
                    if fcurve[i].data_path.split('"')[1] == bone:
                        while len(fcurve[i].keyframe_points) > 0:
                            # print("Deleting frame:", fcurve[i].keyframe_points[0].co[0], "of", i)
                            fcurve[i].keyframe_points.remove(fcurve[i].keyframe_points[0])
                            
                            
            currentFrame = bpy.context.scene.frame_current
            for index in range(bpy.data.scenes[0].frame_start, bpy.data.scenes[0].frame_end + 1):
                bpy.context.scene.frame_current = index
                bpy.data.objects[obj].pose.bones[bone].rotation_quaternion = Quaternion((1.0,0,0,0))
            bpy.context.scene.frame_current = currentFrame
                '''

        else:
            bpy.data.objects[obj].animation_data_clear()
            drawActions_Overview(obj,bone)

        global mode
        if mode == "KEYFRAME":
            updateKeyframeVisualization()

    '''
    if obj!= "":
    if obj!= "":
        if bone!= "":
            if animDataExist(obj):
                fcurve = bpy.data.objects[obj].animation_data.action.fcurves
                for curve in fcurve:
                    if curve.data_path.split('"')[1] == currBone:
                        for point in curve.keyframe_points:
                            curve.keyframe_points.remove(point)
        else:
            bpy.data.objects[obj].animation_data_clear()
    '''

def removeKeyFrame(frame, obj, bone):
    #Removes keyframe from the Blender Timeline
    if bone != "":
        print ("Is a BONE")
        if animDataExist(obj):
            print("ANIMATION data exist")
            fcurve = bpy.data.objects[obj].animation_data.action.fcurves
            for i in range(0, len(fcurve.items())):
                if fcurve[i].data_path.split('"')[1] == bone:
                    for key in fcurve[i].keyframe_points:
                    #while len(fcurve[i].keyframe_points) > 0:
                        if key.co[0] == frame:
                            # print("Deleting frame:", fcurve[i].keyframe_points[0].co[0], "of", i)
                            fcurve[i].keyframe_points.remove(key)

                            bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'QUATERNION'
                            bpy.data.objects[obj].pose.bones[bone].rotation_quaternion = Quaternion((1.0,0,0,0))
        print ("DEBUG [removeKeyFrame]: {DONE}")
    else:
        print ("Is a OBJECT - removeKeyFrame")
        if animDataExist(obj):
            print("ANIMATIONA data exist")
            fcurve = bpy.data.objects[obj].animation_data.action.fcurves
            for i in range(0, len(fcurve.items())):
                for key in fcurve[i].keyframe_points:
                    if key.co[0] == frame:
                        fcurve[i].keyframe_points.remove(key)

                        bpy.data.objects[obj].rotation_mode = 'QUATERNION'
                        bpy.data.objects[obj].rotation_quaternion = Quaternion((1.0, 0, 0, 0))

    # Removes keyframe from actions
    print ("DEBUG [removeKeyFrame]: Removes keyframe from actions")
    global actions
    for a in actions:
        if a.obj == obj and a.bone == bone:
            for f in a.frames:
                if f.frame == frame:
                    a.frames.remove(f)
    print ("DEBUG [removeKeyFrame]: Removes keyframe from actions {DONE}")

def updateKeyframeList():
    global currObject
    global currObject_l
    global currBone
    global currBone_l

    global curr_frames_r
    global curr_frames_l
    curr_frames_r = []
    curr_frames_l = []

    for a in actions:
        if a.obj == currObject and a.bone == currBone:
            curr_frames_r += a.frames
        if a.obj == currObject_l and a.bone == currBone_l:
            curr_frames_l += a.frames

    '''
    if currObject != "":
        if animDataExist(currObject):
            if currBone != "":
                #print ("DEBUG [updateKeyframeList] - is a bone and animationDataExist")
                fcurve = bpy.data.objects[currObject].animation_data.action.fcurves
                boneCurve = []

                for i in range(0, len(fcurve.items())):
                    boneName = fcurve[i].data_path.split('"')[1]
                    if boneName == currBone:
                        boneCurve.append(fcurve[i])

                #print ("DEBUG [updateKeyframeList] - boneCurve defined")
                curr_frames_r = getFrameFromCurve(boneCurve, currObject, currBone)
                #print ("DEBUG [updateKeyframeList] - curr_frames_r defined")

            else:
                curr_frames_r = getFrameFromCurve(bpy.data.objects[currObject].animation_data.action.fcurves,
                                                  currObject, currBone)

    if currObject_l != "":
        if animDataExist(currObject_l):
            if currBone_l != "":
                fcurve = bpy.data.objects[currObject_l].animation_data.action.fcurves
                boneCurve = []

                for i in range(0, len(fcurve.items())):
                    boneName = fcurve[i].data_path.split('"')[1]
                    if boneName == currBone_l:
                        boneCurve.append(fcurve[i])

                curr_frames_l = getFrameFromCurve(boneCurve, currObject_l, currBone_l)

            else:
                curr_frames_l = getFrameFromCurve(bpy.data.objects[currObject_l].animation_data.action.fcurves,
                                                  currObject_l, currBone_l)
    '''

def updateKeyframeVisualization():
    # Updates keyframe visualization
    recursive_delete_children()
    print ("DEBUG [updateKeyframeVisualization] - recursive_delete_children()")
    updateKeyframeList()
    print ("DEBUG [updateKeyframeVisualization] - updateKeyframeList()")
    insertKeyFrameMesh(True)
    print ("DEBUG [updateKeyframeVisualization] - insertKeyFrameMesh(True)")
    insertKeyFrameMesh(False)
    print ("DEBUG [updateKeyframeVisualization] - insertKeyFrameMesh(False)")

def updatePropKeyframeVisualization():

    global currObject
    global currBone

    # Updates keyframe visualization
    recursive_delete_children()

    # updateKeyframeList()
    global property_frame
    global curr_frames_r
    curr_frames_r = []
    for prop in property_frame:
        if prop.obj == currObject and prop.bone == currBone:
            curr_frames_r.append(prop)

    #insertKeyFrameMesh(True)
    for f in curr_frames_r:
        frame = createPlane("frame")
        frame.dimensions = (0.005, 0, 0.150)
        frame.parent = bpy.data.objects['TimelineRoot']
        frame.location = (f.frame / 100, -0.015, 0.12)
        frame.name = 'frame_' + str(f.frame) + ".R"
        if f.data_path == 'eval_time':
            frame.data.materials.append(bpy.data.materials['Material_LOC'])
        else:
            frame.data.materials.append(bpy.data.materials['Material_ROT'])



# ---------------------------------------- #
#   Thread
# ---------------------------------------- #

class playerSound(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        winsound.Beep(440, 500)

class tester(threading.Thread):
    def __init__(self, threadID, poses, hmd_index,tracker_index):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.poses = poses
        self.hmd_index = hmd_index
        self.tracker_index = tracker_index

    def run(self):
        matrix = self.poses[self.tracker_index].mDeviceToAbsoluteTracking
        # ## MOVE OBJECT TRACKER
        # try:
        #     camera = bpy.data.objects["Camera"]
        #     tracker = bpy.data.objects["Tracker"]
        #
        #     self.trans_matrix = camera.matrix_world * bpy.data.objects['Origin'].matrix_world
        #     RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
        #                               (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
        #                               (matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
        #                               (0, 0, 0, 1)))
        #
        #     if (self.rotFlag):
        #         tracker.matrix_world = self.trans_matrix * RTS_matrix
        #     else:
        #         diff_rot_matr = self.diff_rot.to_matrix()
        #         # RTS_matrix = RTS_matrix.inverted()
        #         inverted_matrix = RTS_matrix * diff_rot_matr.to_4x4()
        #         inverted_matrix = inverted_matrix.inverted()
        #         # stMatrix =  self.diff_trans_matrix * RTS_matrix * diff_rot_matr.to_4x4()
        #         stMatrix = self.diff_trans_matrix * inverted_matrix
        #         quat = stMatrix.to_quaternion()
        #         camera.rotation_quaternion = quat
        # except:
        #     print("ERROR: ")


        # MOVE BONE TRACKER
        # bone = bpy.data.objects["Armature_Tangible_VR"]
        # pbone = bone.pose.bones["IntelligentBrick"]
        # translationMatrix = Matrix(((0.0, 0.0, 0.0, bone.location[0]), (0.0, 0.0, 0.0, bone.location[1]),
        #                            (0.0, 0.0, 0.0, bone.location[2]), (0.0, 0.0, 0.0, 1.0)))
        # quat = Quaternion((0.707, -0.707, 0, 0))
        # diff_rot_matr = quat.to_matrix()
        # RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
        #                     (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
        #                     (matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
        #                     (0, 0, 0, 1)))
        # pbone.matrix = (RTS_matrix - translationMatrix)#* diff_rot_matr.to_4x4()

        camera = bpy.data.objects["Camera"]
        self.trans_matrix = camera.matrix_world * bpy.data.objects['Origin'].matrix_world
        RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
                             (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
                             (matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
                             (0, 0, 0, 1)))
        ## TUI ARMATURE
        bpy.data.objects["Armature_Tangible_VR"].pose.bones["IntelligentBrick"].matrix = self.trans_matrix * RTS_matrix

        ## SNAP CONTROLLER
        bpy.data.objects["TUI.R"].location = bpy.data.objects["Armature_Tangible_VR"].location + \
                                           bpy.data.objects["Armature_Tangible_VR"].pose.bones["IntelligentBrick"].center

        ## HMD
        matrix = self.poses[self.hmd_index].mDeviceToAbsoluteTracking
        RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
                             (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
                             (matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
                             (0, 0, 0, 1)))

        bpy.data.objects["Head"].matrix_world = self.trans_matrix * RTS_matrix

class recorder(threading.Thread):
    def __init__(self, threadID, AppMode):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.AppMode = AppMode

    def run(self):
        global  recordFlag
        overflowFlag = False

        global currObject
        global currBone
        global currObject_l
        global currBone_l
        global speedPlayRec
        global samplingRate
        global recordMode
        global actions

        counter = 24 / samplingRate
        frequency = 24 / samplingRate

        frames_r = []
        frames_l = []

        deleteAction(currObject, currBone)
        deleteAction(currObject_l, currBone_l)
        drawAction(currObject, currBone, False, True)
        drawAction(currObject_l, currBone_l, False, False)

        bpy.data.objects['TimelineSlider'].location[0] = bpy.context.scene.frame_current/100
        if self.AppMode=="BLENDER_VR":
            bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R2.png']
        if self.AppMode == "GEOMETRY_VR":
            bpy.data.textures['Texture.R'].image = bpy.data.images['GEO-Right-rec.png']

        bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

        while recordFlag:
            print ("recording...")

            ## Saving obj/bone location and rotation for the right controller
            if currObject!="":
                obj = bpy.data.objects[currObject]

                if counter==frequency:
                    if obj.type == 'ARMATURE' and currBone!="":
                        pbone = obj.pose.bones[currBone]
                        frames_r.append(Keyframe(bpy.context.scene.frame_current,
                                                 copy.deepcopy(pbone.rotation_quaternion),
                                                 copy.deepcopy(pbone.location),
                                                 copy.deepcopy(pbone.scale),
                                                 currObject,currBone,recordMode))

                    else:
                        frames_r.append(Keyframe(bpy.context.scene.frame_current,
                                                 copy.deepcopy(obj.rotation_quaternion),
                                                 copy.deepcopy(obj.location),
                                                 copy.deepcopy(obj.scale),
                                                 currObject, currBone, recordMode))

                    #bpy.data.objects["Action.R"].hide = False
                    #bpy.data.objects["Action.R"].dimensions[0] = bpy.context.scene.frame_current / 100

            ## Saving obj/bone location and rotation for the left controller
            if currObject_l!="":
                obj = bpy.data.objects[currObject_l]

                if counter == frequency:
                    if obj.type == 'ARMATURE' and currBone_l!="":
                        pbone = obj.pose.bones[currBone_l]
                        frames_l.append(Keyframe(bpy.context.scene.frame_current,
                                                 copy.deepcopy(pbone.rotation_quaternion),
                                                 copy.deepcopy(pbone.location),
                                                 copy.deepcopy(pbone.scale),
                                                 currObject_l,currBone_l, recordMode))
                    else:
                        frames_l.append(Keyframe(bpy.context.scene.frame_current,
                                                 copy.deepcopy(obj.rotation_quaternion),
                                                 copy.deepcopy(obj.location),
                                                 copy.deepcopy(obj.scale),
                                                 currObject_l, currBone_l, recordMode))

                    #bpy.data.objects["Action.L"].hide = False
                    #bpy.data.objects["Action.L"].dimensions[0] = bpy.context.scene.frame_current / 100

            ## Moves the timeline slider
            if currObject!="" or currObject_l!="":
                if counter == frequency:
                    counter = 1
                else:
                    counter +=1

                bpy.context.scene.frame_current += 1
                bpy.data.objects['TimelineSlider'].location[0]+=0.01
                bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)
                time.sleep(1 / (24 * speedPlayRec))

                if bpy.context.scene.frame_current > bpy.data.scenes[0].frame_end:
                    overflowFlag = True
            else:
                time.sleep(1 / (24 * speedPlayRec))

        #Recording is completed
        if self.AppMode=="BLENDER_VR":
            bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R.png']
        if self.AppMode == "GEOMETRY_VR":
            bpy.data.textures['Texture.R'].image = bpy.data.images['Hand-R.png']

        if overflowFlag:
            print ("DEBUG [recorder] - overflowFlag --> frameEnd=", bpy.context.scene.frame_current)
            bpy.data.scenes[0].frame_end = bpy.context.scene.frame_current
            bpy.data.objects['Timeline'].dimensions[0] = bpy.data.scenes[0].frame_end/100

        if currObject!="":
            actions.append(Action("Action" + currObject + currBone  + "." + str(frames_r[0].frame) + "_" + str(frames_r[-1].frame),
                                  currObject, currBone, copy.deepcopy(frames_r)))


            # Restores frames of alredy defined actions
            for a in actions:
                print ("DEBUG [recorder] - action:", a.name , "Condition", a.obj == currObject and a.bone== currBone)
                if a.obj == currObject and a.bone== currBone:
                    print ("DEBUG [recorder] - adding", len(a.frames), "frames of", a.name)
                    frames_r += a.frames


            #frames_r.sort(key=lambda x: x.frame, reverse=False)
            insertFrame(frames_r)
            drawAction(currObject, currBone, True, True)
            drawActions_Overview(currObject,currBone)

        if currObject_l!="":
            actions.append(Action("Action" + currObject_l + currBone_l + "."  + str(frames_l[0].frame) + "_" + str(frames_l[-1].frame),
                                  currObject_l, currBone_l, copy.deepcopy(frames_l)))

            # Restores frames of alredy defined actions
            for a in actions:
                if a.obj == currObject_l and a.bone == currBone_l:
                    frames_l += a.frames

            insertFrame(frames_l)
            drawAction(currObject_l, currBone_l, True, False)
            drawActions_Overview(currObject_l,currBone_l)

        print ("DEBUG [recorder] - recording finished")
        print ("DEBUG [recorder] - #actions = ", len(actions))
        for a in actions:
            print ("DEBUG [recorder] - action:", a.obj, a.frames[0].frame, a.frames[-1].frame)

class recorder_prop(threading.Thread):
    def __init__(self, properties, prop_index, isCurveMode):
        threading.Thread.__init__(self)
        self.properties = properties
        self.prop_index = prop_index
        self.isCurveMode = isCurveMode

    def run(self):
        print ("DEBUG [recorder_prop] - Thread strats ")
        global recordFlag
        overflowFlag = False

        global currObject
        global currBone
        global speedPlayRec
        global samplingRate
        global property_frame

        counter = 24 / samplingRate
        frequency = 24 / samplingRate

        values = []

        keyframes = [] # for action Visualization


        bpy.data.objects['TimelineSlider'].location[0] = bpy.context.scene.frame_current / 100

        if self.isCurveMode:
            bpy.data.textures['Texture.R'].image = bpy.data.images['PathPerf2-R.png']
            drawActionPath(currObject, currBone, False)

        else:
            bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R2.png']
            drawActionProp(currObject_l, currBone_l, False)

        bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

        while recordFlag:
            print ("recording...")

            if counter == frequency:
                if self.isCurveMode:
                    # insert curve_mode frame
                    if currObject + currBone + "_PATH" in bpy.data.curves:
                        #bpy.data.curves[currObject + currBone+ "_PATH"].keyframe_insert(data_path='eval_time')
                        values.append((bpy.context.scene.frame_current, bpy.data.curves[currObject+ currBone + "_PATH"].eval_time))
                        property_frame.append(Property(bpy.context.scene.frame_current, currObject, currBone, 'eval_time'))

                        keyframes.append(Property(bpy.context.scene.frame_current, currObject, currBone, 'eval_time')) # for action Visualization


                else:
                    # insert prop_mode frame
                    if 'Material_Diffuse_' in self.properties[self.prop_index]:
                        slot = int(self.properties[self.prop_index].split('Material_Diffuse_')[1])
                        bpy.data.materials[bpy.data.objects[currObject].material_slots[slot].name].keyframe_insert(data_path='diffuse_color')
                        property_frame.append(Property(bpy.context.scene.frame_current, currObject, currBone, self.properties[self.prop_index]))

                        keyframes.append(Property(bpy.context.scene.frame_current, currObject, currBone, self.properties[self.prop_index])) # for action Visualization

                    if 'ShapeKey_' in self.properties[self.prop_index]:
                        slot = int(self.properties[self.prop_index].split('ShapeKey_')[1])
                        bpy.data.objects[currObject].data.shape_keys.key_blocks[slot].keyframe_insert(data_path='value')
                        property_frame.append(Property(bpy.context.scene.frame_current, currObject, currBone, self.properties[self.prop_index]))

                        keyframes.append(Property(bpy.context.scene.frame_current, currObject, currBone,self.properties[self.prop_index])) # for action Visualization

                    if 'Material_Alpha_' in self.properties[self.prop_index]:
                        slot = int(self.properties[self.prop_index].split('Material_Alpha_')[1])
                        bpy.data.materials[bpy.data.objects[currObject].material_slots[slot].name].keyframe_insert(data_path='alpha')
                        property_frame.append(Property(bpy.context.scene.frame_current, currObject, currBone, self.properties[self.prop_index]))

                        keyframes.append(Property(bpy.context.scene.frame_current, currObject, currBone,self.properties[self.prop_index])) # for action Visualization

            ## Moves the timeline slider
            if currObject != "":
                if counter == frequency:
                    counter = 1
                else:
                    counter += 1

                bpy.context.scene.frame_current += 1
                bpy.data.objects['TimelineSlider'].location[0] += 0.01
                bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)
                time.sleep(1 / (24 * speedPlayRec))

                if bpy.context.scene.frame_current > bpy.data.scenes[0].frame_end:
                    overflowFlag = True
            else:
                time.sleep(1 / (24 * speedPlayRec))

        # Recording is completed

        if self.isCurveMode:
            global actionsPath # for action Visualization
            actionsPath.append(ActionProp(
                "Action" + currObject + currBone + "." + str(keyframes[0].frame) + "_" + str(keyframes[-1].frame),
                currObject, currBone, copy.deepcopy(keyframes)))  # for action Visualization

            for f in values:
                bpy.data.curves[currObject + currBone + "_PATH"].eval_time = f[1]
                bpy.data.curves[currObject + currBone + "_PATH"].keyframe_insert(data_path='eval_time',frame=f[0])

            bpy.data.textures['Texture.R'].image = bpy.data.images['PathPerf-R.png']

            drawActionPath(currObject, currBone, True)


        else:
            global actionsProp
            actionsProp.append(ActionProp(
                "Action" + currObject + currBone + "." + str(keyframes[0].frame) + "_" + str(keyframes[-1].frame),
                currObject, currBone, copy.deepcopy(keyframes)))  # for action Visualization

            bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R.png']

            drawActionProp(currObject, currBone, True)

        if overflowFlag:
            print ("DEBUG [recorder] - overflowFlag --> frameEnd=", bpy.context.scene.frame_current)
            bpy.data.scenes[0].frame_end = bpy.context.scene.frame_current
            bpy.data.objects['Timeline'].dimensions[0] = bpy.data.scenes[0].frame_end / 100

        # TODO: Implementing draw action
        #updatePropKeyframeVisualization()
        print ("DEBUG [recorder_prop] - Implementing draw action")
        print ("DEBUG [recorder_prop] - recorder_prop finished")

class animator(threading.Thread):
    def __init__(self, AppMode):
        threading.Thread.__init__(self)
        self.AppMode = AppMode

    def run(self):

        global playingAnimation
        global speedPlayRec

        # save the current frame
        currentFrame = bpy.context.scene.frame_current
        # initialize counter
        count = bpy.data.scenes[0].frame_start

        # play animation
        while count < bpy.data.scenes[0].frame_end and playingAnimation:
            time.sleep(1/(24*speedPlayRec))
            count += 1
            bpy.context.scene.frame_current = count
            bpy.data.objects['TimelineSlider'].location[0] = count/100
            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

        # restore current frame
        bpy.context.scene.frame_current = currentFrame
        bpy.data.objects['TimelineSlider'].location[0] = currentFrame/100
        bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

        if bpy.data.objects['SettingsPanel'].hide:
            if self.AppMode=="BLENDER_VR":
                bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R.png']
            if self.AppMode=="GEOMETRY_VR":
                bpy.data.textures['Texture.R'].image = bpy.data.images['Hand-R.png']
        else:
            bpy.data.textures['Texture.Button(Play)'].image = bpy.data.images['Button(Play).png']



        playingAnimation = False

# ---------------------------------------- #
# Utilities
# ---------------------------------------- #

class State(Enum):
    IDLE = 1
    DECISIONAL = 2
    INTERACTION_GLOBAL = 3
    INTERACTION_LOCAL = 4
    NAVIGATION_ENTER = 5
    NAVIGATION = 6
    NAVIGATION_EXIT = 7
    ZOOM_IN = 8
    ZOOM_OUT = 9
    CAMERA_MOVE_STEP = 10
    CAMERA_MOVE_CONT = 11
    CAMERA_ROT_CONT = 12
    ON_BUTTON_PRESSED = 13
    START_RECORD = 14
    END_RECORD = 15
    PLAY_ANIMATION = 16
    SETTING = 17
    MOVE_RIGHT = 18
    MOVE_LEFT = 19
    MULTIPLY_ACTION = 20
    DIVIDE_ACTION = 21
    START_ANIMATION = 22
    STOP_ANIMATION = 23
    MOVE_TIMELINE_CURSOR_ENTER = 24
    MOVE_TIMELINE_CURSOR = 25
    IDLE_KEYMODE = 26
    NEXT_FRAME = 27
    PREV_FRAME = 28
    SCALING = 29
    CREATE_CURVE = 31
    ADD_POINT_CURVE = 32
    INTERACTION_CURVEMODE = 33
    DECISIONAL_CURVEMODE = 34
    INSERT_KEYFRAME = 38
    DELETE_KEYFRAME = 39
    IDLE_EDIT_ACTION = 40
    DECISIONAL_EDIT_ACTION = 41
    START_RECORD_PROP = 42
    END_RECORD_PROP = 43
    IDLE_LOCAL = 44
    IDLE_F_CURVEMODE = 45
    DECISIONAL_F_CURVEMODE = 46
    INTERACTION_F_CURVEMODE = 47
    CHANGE_AXES = 48
    INSERT_EVAL_KEYFRAME = 49
    DELETE_EVAL_KEYFRAME = 50
    IDLE_CURVEMODE_PERF = 51
    IDLE_CURVEMODE_KEY = 52
    IDLE_TUNING_PERF = 53
    IDLE_TUNING_KEY = 54
    INSERT_PROP_KEYFRAME = 55
    DELETE_PROP_KEYFRAME = 56
    DELETE = 57
    IDLE_RIGGING = 58
    DECISIONAL_RIGGING = 59
    INTERACTION_RIGGING = 60
    IDLE_SKINNING = 61
    ADD_BONE = 62
    INCREASE_BONE_ROLL = 63
    DECREASE_BONE_ROLL = 64
    INCREASE_BRUSH_DIM = 65
    DECREASE_BRUSH_DIM = 66
    INCREASE_BRUSH_WEIGHT = 67
    DECREASE_BRUSH_WEIGHT = 68
    INTERACTION_SKINNING = 69
    CHANGE_VERTEX_GROUP = 70
    IDLE_ARM_CONSTR = 71
    INCREASE_CHAIN_LENGTH = 72
    DECREASE_CHAIN_LENGTH = 73
    SET_TARGET_IK = 74
    SET_POLE_IK = 75
    REMOVE_BONE = 76
    CUSTOM_CONTROL = 100
    CUSTOM_CONTROL_ENTER = 101
    CUSTOM_CONTROL_GRIPPER_RELEASED = 102
    CUSTOM_CONTROL_TRACKPAD_RELEASED = 103


class StateLeft(Enum):
    IDLE = 1
    TIMELINE_NAV = 2
    TIMELINE_NAV_PREV = 3
    TIMELINE_NAV_NEXT = 4
    SETTING = 6
    SETTING_ENTER = 7
    SETTING_EXIT = 8
    DECISIONAL = 9
    INTERACTION_LOCAL = 10
    MULTIPLY_ACTION = 11
    DIVIDE_ACTION = 12
    MOVE_RIGHT = 13
    MOVE_LEFT = 14
    HELP = 15
    IDLE_KEYMODE = 16
    SCALING = 17
    IDLE_CURVEMODE = 20
    INTERACTION_CURVEMODE = 21
    DECISIONAL_CURVEMODE = 22
    IDLE_TUNING = 23
    CHANGE_PROP = 24
    INSERT_KEYFRAME = 27
    DELETE_KEYFRAME = 28
    IDLE_EDIT_ACTION = 29
    DECISIONAL_EDIT_ACTION = 30
    IDLE_LOCAL = 31
    IDLE_F_CURVEMODE = 32
    CHANGE_FCURVE = 33
    CHANGE_AXES = 34
    NAVIGATION = 35
    MOVE_COLOR_CURSOR_ENTER = 36
    MOVE_COLOR_CURSOR = 37
    IDLE_RIGGING = 38
    RIGGING_ARMATURE_AUTO = 39
    RIGGING_ARMATURE_EMPTY = 40
    TOOGLE_CONNECTION_BONE = 41
    SUBDIVIDE_BONE = 42
    IDLE_SKINNING = 43
    IDLE_ARM_CONSTR = 44
    SET_ORTHOGONAL_VIEW = 45
    SET_PERSPECTIVE_VIEW = 46
    ON_BUTTON_PRESSED = 47
    NEXT_FRAME = 48
    PREV_FRAME = 49
    CUSTOM_CONTROL = 100
    CUSTOM_CONTROL_ENTER = 101
    CUSTOM_CONTROL_GRIPPER_RELEASED = 102
    CUSTOM_CONTROL_TRACKPAD_RELEASED = 103

    #?# GEOMETRIA VR #?#
    APPLY_BOOL_OPERATION = 48
    INCREASE_OPERATOR = 49
    DECREASE_OPERATOR = 50


class Keyframe:
    def __init__(self, frame, rot, loc, scale, obj, bone, frameType):
        self.frame = frame
        self.rot = rot
        self.loc = loc
        self.scale = scale
        self.obj = obj
        self.bone = bone
        self.frameType = frameType

class Property:
    def __init__(self, frame, obj, bone, data_path):
        self.frame = frame
        self.obj = obj
        self.bone = bone
        self.data_path = data_path

class Action:
    def __init__(self, name, obj, bone, frames):
        self.name = name
        self.obj = obj
        self.bone = bone
        self.frames = frames

class ActionProp:
    def __init__(self, name, obj, bone, frames):
        self.name = name
        self.obj = obj
        self.bone = bone
        self.frames = frames




# ---------------------------------------- #
# Main
# ---------------------------------------- #

class OpenVR(HMD_Base):
    AppMode = "BLENDER_VR" # TANGIBLE_VR,GEOMETRY_VR
    ctrl_index_r = 0
    ctrl_index_l = 0
    tracker_index = 0
    hmd_index = 0
    state = State.IDLE
    state_l = StateLeft.IDLE
    diff_rot = Quaternion()
    diff_loc = bpy.data.objects['Controller.R'].location
    initial_loc = Vector((0,0,0))
    initial_rot = Quaternion()

    diff_rot_l = Quaternion()
    diff_loc_l = bpy.data.objects['Controller.L'].location
    initial_loc_l = Vector((0, 0, 0))
    initial_rot_l = Quaternion()

    diff_distance = 0
    initial_scale = 0

    trans_matrix = bpy.data.objects['Camera'].matrix_world * bpy.data.objects['Origin'].matrix_world
    diff_trans_matrix = bpy.data.objects['Camera'].matrix_world * bpy.data.objects['Origin'].matrix_world

    objToControll = ""
    boneToControll = ""
    objToControll_l = ""
    boneToControll_l = ""
    zoom  = 1
    rotFlag = True
    offsetTimeSlider = 0
    offesetColorCursor = Vector((0,0,0))
    offesetCurvePoint_r = Vector((0,0,0))
    offesetCurveHandle_r = [Vector((0,0,0)), Vector((0,0,0))]
    #offesetCurvePoint_l = Vector((0, 0, 0)) -> replaced with diff_loc_l

    properties = []
    prop_index = 0
    action_r_index = -1
    action_l_index = -1

    colorPalette = bpy.data.objects['ColorPalette']
    colorPaletteCursor = bpy.data.objects['ColorPaletteCursor']
    bool_operators = ['DIFFERENCE', 'UNION', 'INTERSECT']
    axes = ['LOC/ROT_XYZ','LOC_XYZ','LOC_X','LOC_Y','LOC_Z','ROT_XYZ','ROT_X','ROT_Y','ROT_Z']
    curr_axes_r = 0
    curr_axes_l = 0
    mirror_axes = [False, False, False]  # 'X', 'Y', 'Z'
    arm_selection = False # False = Bone selection ; True= armature selection

    gui_obj = ['TUI.R', 'TUI.L', 'Camera',
               'Controller.R', 'Controller.L',
               'SelectedObj', 'Text.R', 'Text.L',
               'Action_Text.R', 'Action_Text.L',
               'Action.R', 'Action.L',
               'Timeline', 'TimelineSlider', 'TimelineRoot',
               'ColorPalette', 'ColorPaletteCursor',
               '_Help.001','_Help.002','_Help.003','_Help.004',
               '_Help.005','_Help.006','_Help.007','_Help.008',
               '_Help.009','_Help.010','_Help.011','_Help.012',
               'Button.000','SettingsPanel',
               'Button.001','Button.002','Button.003','Button.004',
               'Button.005','Button.006','Button.007','Button.008',
               'Button.009','Button.010','Button.011','Button.012',
               'Button.013','Button.014','Button.015','Button.016',
               'Button.017', 'Button.018', 'Button.019',
               'Button.020', 'Button.021', 'Button.022',
               'Button.023',
               'Head','Hit_Obj','Hit_Position','Hit_Target','Origin',
               'TextBox.000','TextBox.001','TextBox.002',
               'TextBox.003','TextBox.004','TextBox.005', 'TextBox.006'
               'Timeline.001',
               'TextBox.007','TextBox.008','TextBox.009','TextBox.010',
               'TextBox.011','TextBox.012','TextBox.013','TextBox.014',
               'TextBox.015','TextBox.016','TextBox.017','TextBox.018','TextBox.019',
               'Screen.R','Screen.L','Brush', 'F-Curve-Grid']
    gui_obj_custom_buttons = []


    def __init__(self, context, error_callback):
        super(OpenVR, self).__init__('OpenVR', True, context, error_callback)
        checkModule('hmd_sdk_bridge')

    def _getHMDClass(self):
        """
        This is the python interface to the DLL file in hmd_sdk_bridge.
        """
        from bridge.hmd.openvr import HMD
        return HMD

    @property
    def projection_matrix(self):
        if self._current_eye:
            if bpy.data.objects['Origin'].hide:
                matrix = self._hmd.getProjectionMatrixRight(self._near, self._far)
            else:
                matrix = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, 0.0, 1.0]

        else:
            if bpy.data.objects['Origin'].hide:
                matrix = self._hmd.getProjectionMatrixLeft(self._near, self._far)
            else:
                matrix = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, 0.0, 1.0]

        self.projection_matrix = matrix
        return super(OpenVR, self).projection_matrix

    @projection_matrix.setter
    def projection_matrix(self, value):
        self._projection_matrix[self._current_eye] = \
            self._convertMatrixTo4x4(value)

    ## Finds the index position of the first controller(Right Controller)
    def findControllers(self, vrSys):
        r_index, l_index, tracker_index, hmd_index = -1,-1,-1,-1

        for i in range(openvr.k_unMaxTrackedDeviceCount):
            if openvr.IVRSystem.getTrackedDeviceClass(vrSys, i) == openvr.TrackedDeviceClass_Invalid:
                print(i, openvr.IVRSystem.getTrackedDeviceClass(vrSys, i), " - ")
            if openvr.IVRSystem.getTrackedDeviceClass(vrSys, i) == openvr.TrackedDeviceClass_HMD:
                print(i, openvr.IVRSystem.getTrackedDeviceClass(vrSys, i), " - HMD")
                hmd_index = i
            if openvr.IVRSystem.getTrackedDeviceClass(vrSys, i) == openvr.TrackedDeviceClass_TrackingReference:
                print(i, openvr.IVRSystem.getTrackedDeviceClass(vrSys, i), " - TrackingReference")
            if openvr.IVRSystem.getTrackedDeviceClass(vrSys, i) == openvr.TrackedDeviceClass_Controller:
                print(i, openvr.IVRSystem.getTrackedDeviceClass(vrSys, i), " - Controller")
                if r_index==-1:
                    r_index = i
                else:
                    l_index = i
            if openvr.IVRSystem.getTrackedDeviceClass(vrSys, i) == 3:
                print(i, openvr.IVRSystem.getTrackedDeviceClass(vrSys, i), " - VIVE Tracker")
                tracker_index = i

        print('r_index = ', r_index,' l_index = ', l_index)
        return r_index, l_index, tracker_index, hmd_index

    def init(self, context):
        """
        Initialize device

        :return: return True if the device was properly initialized
        :rtype: bool
        """

        vrSys = openvr.init(openvr.VRApplication_Scene)
        self.ctrl_index_r, self.ctrl_index_l, self.tracker_index, self.hmd_index  = self.findControllers(vrSys)
        print("APP MODE = ", self.AppMode)
        bpy.data.window_managers['WinMan'].virtual_reality.lock_camera = True

        try:
            HMD = self._getHMDClass()
            self._hmd = HMD()

            # bail out early if we didn't initialize properly
            if self._hmd.get_state_bool() == False:
                raise Exception(self._hmd.get_status())

            # Tell the user our status at this point.
            self.status = "HMD Init OK. Make sure lighthouses running else no display."

            # gather arguments from HMD
            self.setEye(0)
            self.width = self._hmd.width_left
            self.height = self._hmd.height_left

            self.setEye(1)
            self.width = self._hmd.width_right
            self.height = self._hmd.height_right

            # initialize FBO
            if not super(OpenVR, self).init():
                raise Exception("Failed to initialize HMD")

            # send it back to HMD
            if not self._setup():
                raise Exception("Failed to setup OpenVR Compatible HMD")

        except Exception as E:
            self.error("OpenVR.init", E, True)
            self._hmd = None
            return False

        else:
            return True

    def _setup(self):
        return self._hmd.setup(self._color_texture[0], self._color_texture[1])

    # ---------------------------------------- #
    # Utilities functions
    # ---------------------------------------- #

    ## Sets the location and orientation of the controller model and TUI pointer
    def setController(self, ctrl_index_r):
        poses_t = openvr.TrackedDevicePose_t * openvr.k_unMaxTrackedDeviceCount
        poses = poses_t()
        openvr.VRCompositor().waitGetPoses(poses, len(poses), None, 0)

        matrix = poses[self.ctrl_index_r].mDeviceToAbsoluteTracking
        matrix2 = poses[self.ctrl_index_l].mDeviceToAbsoluteTracking

        try:
            camera = bpy.data.objects["Camera"]
            ctrl = bpy.data.objects["Controller.R"]
            ctrl_l = bpy.data.objects["Controller.L"]

            #get location
            #ctrl.location[0] = matrix[0][3] * self.zoom + camera.location[0]
            #ctrl.location[1] = -matrix[2][3] * self.zoom + camera.location[1]
            #ctrl.location[2] = matrix[1][3] * self.zoom + camera.location[2]

            # get orientation
            #w = math.sqrt(max(0, 1 + matrix.m[0][0] + matrix.m[1][1] + matrix.m[2][2])) / 2;
            #x = math.sqrt(max(0, 1 + matrix.m[0][0] - matrix.m[1][1] - matrix.m[2][2])) / 2;
            #z = math.sqrt(max(0, 1 - matrix.m[0][0] + matrix.m[1][1] - matrix.m[2][2])) / 2;
            #y = math.sqrt(max(0, 1 - matrix.m[0][0] - matrix.m[1][1] + matrix.m[2][2])) / 2;
            #x = math.copysign(x, matrix.m[2][1] - matrix.m[1][2]);
            #z = math.copysign(z, matrix.m[0][2] - matrix.m[2][0]);
            #y = -math.copysign(y, matrix.m[1][0] - matrix.m[0][1]);
            #ctrl.rotation_quaternion = (w, x, y, z)

            self.trans_matrix = camera.matrix_world * bpy.data.objects['Origin'].matrix_world
            RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
                                 (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
                                 (matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
                                 (0, 0, 0, 1)))

            RTS_matrix2 = Matrix(((matrix2[0][0], matrix2[0][1], matrix2[0][2], matrix2[0][3]),
                                 (matrix2[1][0], matrix2[1][1], matrix2[1][2], matrix2[1][3]),
                                 (matrix2[2][0], matrix2[2][1], matrix2[2][2], matrix2[2][3]),
                                 (0, 0, 0, 1)))

            if(self.rotFlag):

                ctrl.matrix_world = self.trans_matrix * RTS_matrix
                bpy.data.objects["Text.R"].location = ctrl.location
                bpy.data.objects["Text.R"].rotation_quaternion = ctrl.rotation_quaternion * Quaternion((0.707, -0.707, 0, 0))

                if not bpy.data.objects["_Help.001"].hide:
                    bpy.data.objects["_Help.001"].location = ctrl.location
                    bpy.data.objects["_Help.001"].rotation_quaternion = ctrl.rotation_quaternion
                    bpy.data.objects["_Help.002"].location = ctrl.location
                    bpy.data.objects["_Help.002"].rotation_quaternion = ctrl.rotation_quaternion
                    bpy.data.objects["_Help.003"].location = ctrl.location
                    bpy.data.objects["_Help.003"].rotation_quaternion = ctrl.rotation_quaternion
                    bpy.data.objects["_Help.004"].location = ctrl.location
                    bpy.data.objects["_Help.004"].rotation_quaternion = ctrl.rotation_quaternion
                    bpy.data.objects["_Help.005"].location = ctrl.location
                    bpy.data.objects["_Help.005"].rotation_quaternion = ctrl.rotation_quaternion
                    bpy.data.objects["_Help.006"].location = ctrl.location
                    bpy.data.objects["_Help.006"].rotation_quaternion = ctrl.rotation_quaternion


                ctrl_l.matrix_world = self.trans_matrix * RTS_matrix2
                bpy.data.objects["Text.L"].location = ctrl_l.location
                bpy.data.objects["Text.L"].rotation_quaternion = ctrl_l.rotation_quaternion * Quaternion((0.707, -0.707, 0, 0))

                if not bpy.data.objects["_Help.007"].hide:
                    bpy.data.objects["_Help.007"].location = ctrl_l.location
                    bpy.data.objects["_Help.007"].rotation_quaternion = ctrl_l.rotation_quaternion
                    bpy.data.objects["_Help.008"].location = ctrl_l.location
                    bpy.data.objects["_Help.008"].rotation_quaternion = ctrl_l.rotation_quaternion
                    bpy.data.objects["_Help.009"].location = ctrl_l.location
                    bpy.data.objects["_Help.009"].rotation_quaternion = ctrl_l.rotation_quaternion
                    bpy.data.objects["_Help.010"].location = ctrl_l.location
                    bpy.data.objects["_Help.010"].rotation_quaternion = ctrl_l.rotation_quaternion
                    bpy.data.objects["_Help.011"].location = ctrl_l.location
                    bpy.data.objects["_Help.011"].rotation_quaternion = ctrl_l.rotation_quaternion
                    bpy.data.objects["_Help.012"].location = ctrl_l.location
                    bpy.data.objects["_Help.012"].rotation_quaternion = ctrl_l.rotation_quaternion

            else:
                diff_rot_matr = self.diff_rot.to_matrix()
                inverted_matrix = RTS_matrix * diff_rot_matr.to_4x4()
                inverted_matrix = inverted_matrix.inverted()
                stMatrix = self.diff_trans_matrix * inverted_matrix
                quat = stMatrix.to_quaternion()
                camera.rotation_quaternion = quat


            ## SNAP CONTROLLER
            bpy.data.objects["TUI.R"].location = ctrl.location
            bpy.data.objects["TUI.L"].location = ctrl_l.location
            bpy.data.objects['Brush'].location = ctrl.location


        except:
            print("ERROR: ")

    ## Sets the location and orientation of the controller model and TUI pointer
    def setTracker(self):

        poses_t = openvr.TrackedDevicePose_t * openvr.k_unMaxTrackedDeviceCount
        poses = poses_t()
        openvr.VRCompositor().waitGetPoses(poses, len(poses), None, 0)

        # Thread Version
        tester(3, poses, self.hmd_index, self.tracker_index).start()

        '''
        # Function Version
        matrix = poses[self.tracker_index].mDeviceToAbsoluteTracking
        camera = bpy.data.objects["Camera"]
        self.trans_matrix = camera.matrix_world * bpy.data.objects['Origin'].matrix_world
        RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
                             (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
                             (matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
                             (0, 0, 0, 1)))
        ## TUI ARMATURE
        bpy.data.objects["Armature_Tangible_VR"].pose.bones["IntelligentBrick"].matrix = self.trans_matrix * RTS_matrix
        
        ## SNAP CONTROLLER
        bpy.data.objects["TUI"].location = bpy.data.objects["Armature_Tangible_VR"].location + \
                                           bpy.data.objects["Armature_Tangible_VR"].pose.bones["IntelligentBrick"].center
        
        ## HMD
        matrix = poses[self.hmd_index].mDeviceToAbsoluteTracking
        RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
                               (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
                               (matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
                               (0, 0, 0, 1)))
        bpy.data.objects["Head"].matrix_world = self.trans_matrix * RTS_matrix
        '''

        '''
        ## MOVE OBJECT TRACKER
        try:
            camera = bpy.data.objects["Camera"]
            tracker = bpy.data.objects["Tracker"]
            self.trans_matrix = camera.matrix_world * bpy.data.objects['Origin'].matrix_world
            RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
                                 (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
                                 matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
                                (0, 0, 0, 1)))
            if (self.rotFlag):
                tracker.matrix_world = self.trans_matrix * RTS_matrix
            else:
                diff_rot_matr = self.diff_rot.to_matrix()
                # RTS_matrix = RTS_matrix.inverted()
                inverted_matrix = RTS_matrix * diff_rot_matr.to_4x4()
                inverted_matrix = inverted_matrix.inverted()
                # stMatrix =  self.diff_trans_matrix * RTS_matrix * diff_rot_matr.to_4x4()
                stMatrix = self.diff_trans_matrix * inverted_matrix
                quat = stMatrix.to_quaternion()
                camera.rotation_quaternion = quat
        except:
            print("ERROR: ")
        '''

        '''
        ## MOVE BONE TRACKER
        bone = bpy.data.objects["Armature_Tangible_VR"]
        pbone = bone.pose.bones["IntelligentBrick"]
        translationMatrix = Matrix(((0.0, 0.0, 0.0, bone.location[0]), (0.0, 0.0, 0.0, bone.location[1]),
                                    (0.0, 0.0, 0.0, bone.location[2]), (0.0, 0.0, 0.0, 1.0)))
        quat = Quaternion((0.707, -0.707, 0, 0))
        diff_rot_matr = quat.to_matrix()
        RTS_matrix = Matrix(((matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3]),
                             (matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3]),
                             (matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3]),
                             0, 0, 0, 1)))
        pbone.matrix = (RTS_matrix - translationMatrix)#* diff_rot_matr.to_4x4()
        '''

    ## Returns the object closest to the TUI pointer
    def getClosestItem(self, pointer,isRight):
        dist = sys.float_info.max
        cObj = ""
        cBone = ""
        distThreshold = 0.5

        for object in bpy.data.objects:
            # if (object.type != 'CAMERA' and object.name != 'TUI' and object.name != 'Controller' and object.name != 'SelectedObj'):

            if object.type == 'ARMATURE':
                if not ':TEST_REF' in object.name:
                    for bone in object.pose.bones:
                        currDist = self.computeTargetObjDistance(object.name, bone.name,isRight)
                        bone.bone_group = None
                        if (currDist < dist and currDist < distThreshold):
                            dist = currDist
                            cObj = object.name
                            cBone = bone.name
                            pointer.location = bone.center + object.location

            else:
                '''
                if object.type != 'CAMERA' and object.name != 'TUI.R' and object.name != 'TUI.L' \
                        and object.name != 'Controller.R' and object.name != 'Controller.L' \
                        and object.name != 'SelectedObj' and object.name != 'Text.R' and object.name != 'Text.L'\
                        and object.name != 'Action_Text.R' and object.name != 'Action_Text.L' \
                        and object.name != 'Action.R' and object.name != 'Action.L' \
                        and not "_Help." in object.name:
                '''

                #if object.type != 'CAMERA' and not object.name in self.gui_obj:
                if not object.name in self.gui_obj and not object.name in bpy.types.Scene.gui:
                    currDist = self.computeTargetObjDistance(object.name, "",isRight)
                    # print(object.name, bone.name, currDist)
                    if (currDist < dist and currDist < distThreshold):
                        dist = currDist
                        cObj = object.name
                        cBone = ""
                        pointer.location = object.location


        # Select the new closest item
        print(cObj, cBone)
        print("--------------------------------")
        if(cBone!=""):
            bpy.data.objects[cObj].pose.bones[cBone].rotation_mode = 'QUATERNION'
            #bpy.data.objects[cObj].pose.bones[cBone].bone_group = bpy.data.objects[cObj].pose.bone_groups["SelectedBones"]

        return cObj, cBone

    ## Returns the point of the path closest to the TUI pointer
    def getClosestPoint(self, isRight):
        print ("DEBUG [getClosestPoint] - getClosestPoint enter")
        dist = sys.float_info.max
        objCurve = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]
        pointIndex = -1

        if isRight:
            tui = bpy.data.objects['TUI.R']
        else:
            tui = bpy.data.objects['TUI.L']

        for index in range(0, len(objCurve.data.splines.active.points)):
            p = objCurve.data.splines.active.points[index]
            location = Vector((p.co[0], p.co[1], p.co[2])) + objCurve.location
            curr_distance = (math.sqrt(pow((tui.location[0] - location[0]), 2) +
                                       pow((tui.location[1] - location[1]), 2) +
                                       pow((tui.location[2] - location[2]), 2)))

            if curr_distance < dist:
                pointIndex = index
                dist = curr_distance

        print ("DEBUG [getClosestPoint] - getClosestPoint exit with point:", pointIndex)
        return pointIndex

    ## Returns the point of the BezierCurve closest to the TUI pointer
    def getClosestBezierPoint(self, isRight, curveName):
        print ("DEBUG [getClosestBezierPoint] - getClosestPoint enter")
        dist = sys.float_info.max
        objCurve = bpy.data.objects[curveName]
        pointIndex = -1

        if isRight:
            tui = bpy.data.objects['TUI.R']
        else:
            tui = bpy.data.objects['TUI.L']

        for index in range(0, len(objCurve.data.splines.active.bezier_points)):
            # Handle_Left
            hl = objCurve.data.splines.active.bezier_points[index].handle_left
            location = hl + objCurve.location
            curr_distance = (math.sqrt(pow((tui.location[0] - location[0]), 2) +
                                       pow((tui.location[1] - location[1]), 2) +
                                       pow((tui.location[2] - location[2]), 2)))
            if curr_distance < dist:
                pointIndex = (index,-1)
                dist = curr_distance

            # Handle_Right
            hr = objCurve.data.splines.active.bezier_points[index].handle_right
            location = hr + objCurve.location
            curr_distance = (math.sqrt(pow((tui.location[0] - location[0]), 2) +
                                       pow((tui.location[1] - location[1]), 2) +
                                       pow((tui.location[2] - location[2]), 2)))
            if curr_distance < dist:
                pointIndex = (index, 1)
                dist = curr_distance

            # Point
            p = objCurve.data.splines.active.bezier_points[index].co
            location = p + objCurve.location
            curr_distance = (math.sqrt(pow((tui.location[0] - location[0]), 2) +
                                       pow((tui.location[1] - location[1]), 2) +
                                       pow((tui.location[2] - location[2]), 2)))

            if curr_distance < dist:
                pointIndex = (index, 0)
                dist = curr_distance

            '''
            print(objCurve.data.splines.active.bezier_points[index].handle_left)
            print(objCurve.data.splines.active.bezier_points[index].handle_right)
            print(objCurve.data.splines.active.bezier_points[index].co)
            '''

        print ("DEBUG [getClosestPoint] - getClosestPoint exit with point:", pointIndex)
        return pointIndex

    ## Returns the part of the bone (Head, center or tail) closest to the TUI pointer
    def getClosestBonePart(self, isRight, armName):
        print ("DEBUG [getClosestBonePart] - getClosestBonePart enter")
        dist = sys.float_info.max
        objArm = bpy.data.objects[armName]
        pointIndex = (-1,-1)
        distThreshold = 0.5

        if isRight:
            tui = bpy.data.objects['TUI.R']
        else:
            tui = bpy.data.objects['TUI.L']

        for index in range(0, len(objArm.data.edit_bones)):
            # Head
            head = objArm.data.edit_bones[index].head
            location = head + objArm.location
            curr_distance = (math.sqrt(pow((tui.location[0] - location[0]), 2) +
                                       pow((tui.location[1] - location[1]), 2) +
                                       pow((tui.location[2] - location[2]), 2)))
            if curr_distance < dist and curr_distance < distThreshold :
                pointIndex = (index,-1)
                dist = curr_distance
                self.boneToControll = objArm.data.edit_bones[index].name

            # Tail
            tail = objArm.data.edit_bones[index].tail
            location = tail + objArm.location
            curr_distance = (math.sqrt(pow((tui.location[0] - location[0]), 2) +
                                       pow((tui.location[1] - location[1]), 2) +
                                       pow((tui.location[2] - location[2]), 2)))
            if curr_distance < dist and curr_distance < distThreshold:
                pointIndex = (index, 1)
                dist = curr_distance
                self.boneToControll = objArm.data.edit_bones[index].name

            # Center
            center = objArm.data.edit_bones[index].center
            location = center + objArm.location
            curr_distance = (math.sqrt(pow((tui.location[0] - location[0]), 2) +
                                       pow((tui.location[1] - location[1]), 2) +
                                       pow((tui.location[2] - location[2]), 2)))
            if curr_distance < dist and curr_distance < distThreshold:
                pointIndex = (index, 0)
                dist = curr_distance
                self.boneToControll = objArm.data.edit_bones[index].name

            '''
            print(objArm.data.splines.active.bezier_points[index].handle_left)
            print(objArm.data.splines.active.bezier_points[index].handle_right)
            print(objArm.data.splines.active.bezier_points[index].co)
            '''

        print ("DEBUG [getClosestBonePart] - getClosestBonePart exit with point:", pointIndex)
        return pointIndex

    ## Returns the bone closest to the TUI pointer
    def getClosestBone(self, isRight, armName):
        print ("DEBUG [getClosestBone] - getClosestBone enter")
        dist = sys.float_info.max
        objArm = bpy.data.objects[armName]
        distThreshold = 0.5
        closestBone = ""

        print (armName)

        for bone in objArm.pose.bones:
            currDist = self.computeTargetObjDistance(objArm.name, bone.name, isRight)
            if (currDist < dist and currDist < distThreshold):
                dist = currDist
                closestBone = bone.name
                #pointer.location = bone.center + objArm.location

        print ("DEBUG [getClosestBone] - getClosestBone exit with bone:", closestBone)
        return closestBone

    ## Returns the actions in the GUI_TIMELINE closest to the TUI pointer
    def getClosestAction(self, isRight):
        #print ("DEBUG [getClosestAction] - getClosestAction Enter")
        dist = sys.float_info.max
        closest_action_name = ""

        if isRight:
            tui = bpy.data.objects['TUI.R']
        else:
            tui = bpy.data.objects['TUI.L']

        for child in bpy.data.objects['TimelineRoot'].children:
            if "Action" in child.name:
                #print ("DEBUG [getClosestAction] - getClosestAction ChildName:",child.name )
                location = child.matrix_world.to_translation()
                curr_distance = (math.sqrt(pow((tui.location[0] - location[0]), 2) +
                                           pow((tui.location[1] - location[1]), 2) +
                                           pow((tui.location[2] - location[2]), 2)))

                if curr_distance < dist:
                    closest_action_name = child.name
                    dist = curr_distance

        #print ("DEBUG [getClosestAction] - closest_action_name:", closest_action_name)
        global actions
        for index in range(0, len(actions)):
            a = actions[index]
            #print ("DEBUG [getClosestAction] - a.name:", a.name ," closest_action_name:", closest_action_name)
            if a.name in closest_action_name:
                return index
        return -1

    ## Returns the object closest to the TUI pointer
    def getButtonPressed(self, isRight):
        dist = sys.float_info.max
        cObj = ""
        distThreshold = 0.2

        for but in ['TimelineSlider',
                    'Button.000',
                    'Button.001','Button.002',
                    'Button.008','Button.009',
                    'Button.005','Button.006','Button.007',
                    'Button.010','Button.011','Button.012',
                    'Button.004','Button.003','Button.014',
                    'Button.013','Button.015','Button.016',
                    'Button.017','Button.018','Button.019',
                    'Button.020','Button.021','Button.022','Button.023']:
            object = bpy.data.objects[but]
            currDist = self.computeTargetObjDistance(object.name, "", isRight)
            if (currDist < dist and currDist < distThreshold):
                dist = currDist
                cObj = object.name

        for but in self.gui_obj_custom_buttons:
            object = bpy.data.objects[but]
            currDist = self.computeTargetObjDistance(object.name, "", isRight)
            if (currDist < dist and currDist < distThreshold):
                dist = currDist
                cObj = object.name

        return cObj

    ## Computes distance from TUI pointer
    def computeTargetObjDistance(self, Object, Bone, isRotFlag):

        if isRotFlag:
            tui = bpy.data.objects['TUI.R']
        else:
            tui = bpy.data.objects['TUI.L']

        obj = bpy.data.objects[Object]
        if Bone != "":
            pbone = obj.pose.bones[Bone]
            return (math.sqrt(pow((tui.location[0] - (pbone.center[0] + obj.location[0])), 2) + pow((tui.location[1] - (pbone.center[1] + obj.location[1])), 2) + pow((tui.location[2] - (pbone.center[2] + obj.location[2])), 2)))
        else:
            loc = obj.matrix_world.to_translation()
            return (math.sqrt(pow((tui.location[0] - loc[0]), 2) + pow((tui.location[1] - loc[1]), 2) + pow((tui.location[2] - loc[2]), 2)))

    def computeCameraTranslationOffset(self):
        dirMax = 0
        dirMaxIndex = 0
        offset = 1

        direction = bpy.data.objects['Controller.R'].matrix_world * Vector((0, 1, 0, 0))

        for i in range(4):
            if (math.fabs(direction[i]) > dirMax):
                dirMaxIndex = i
                dirMax = math.fabs(direction[i])

        offset = math.copysign(offset, direction[dirMaxIndex])
        return dirMaxIndex, offset

    def changeSelection(self,obj,bone,selectState):

        if selectState:
            print("SELECT: ", obj, bone)
            if obj != "":
                if bone != "":
                    bpy.data.objects[obj].select = True
                    bpy.context.scene.objects.active = bpy.data.objects[obj]
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.data.objects[obj].data.bones[bone].select = True
                    #bpy.data.objects[obj].data.bones.active = bpy.data.armatures[obj].bones[bone]
                    bpy.data.objects[obj].data.bones.active = bpy.data.objects[obj].data.bones.id_data.bones[bone]


                else:
                    bpy.data.objects[obj].select = True
                    bpy.context.scene.objects.active = bpy.data.objects[obj]
                    bpy.ops.object.mode_set(mode='OBJECT')

        else:
            print ("DESELECT: ", obj, bone)
            if obj != "":
                if bone != "":
                    bpy.data.objects[obj].select = True
                    bpy.context.scene.objects.active = bpy.data.objects[obj]
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.data.objects[obj].data.bones[bone].select = False
                    bpy.data.objects[obj].select = False
                else:
                    bpy.data.objects[obj].select = True
                    bpy.context.scene.objects.active = bpy.data.objects[obj]
                    bpy.data.objects[obj].select = False
                    bpy.ops.object.mode_set(mode='OBJECT')

    def multiplyKeyframe(self, factor, isRight):
        print ("DEBUG [multiplyKeyframe] - multiplyKeyframe Enter")
        global actions

        if isRight:
            actionToUpdate = actions[self.action_r_index]
        else:
            actionToUpdate = actions[self.action_l_index]

        #print ("DEBUG [multiplyKeyframe] - action to update:", actionToUpdate.name, actionToUpdate.frames[0].frame, " - ",actionToUpdate.frames[-1].frame)

        actions.remove(actionToUpdate)
        deleteAction(actionToUpdate.obj, actionToUpdate.bone)

        # Update frames of actionToUpdate
        delta = actionToUpdate.frames[0].frame
        for f in actionToUpdate.frames:
            f.frame = ((f.frame - delta) * factor) + delta

        # create data struct for the insertFrame function
        frames = copy.deepcopy(actionToUpdate.frames)

        # Updates action name
        actionToUpdate.name = "Action" + actionToUpdate.obj + actionToUpdate.bone + "." + \
                              str(actionToUpdate.frames[0].frame) + "_" + str(actionToUpdate.frames[-1].frame)

        # Restore the remaining actions
        for a in actions:
            if a.obj == actionToUpdate.obj and a.bone == actionToUpdate.bone:
                frames += a.frames

        actions.append(actionToUpdate)
        if isRight:
            self.action_r_index = actions.index(actionToUpdate)
        else:
            self.action_l_index = actions.index(actionToUpdate)

        frames.sort(key=lambda x: x.frame, reverse=False)
        # Insert KeyFrame
        insertFrame(frames)
        drawAction(self.objToControll, self.boneToControll, True, True)
        drawAction(self.objToControll_l, self.boneToControll_l, True, False)
        drawActions_Overview(currObject,currBone)
        print ("DEBUG [multiplyKeyframe] - DONE -> action to update:", actionToUpdate.name, "from frame", actionToUpdate.frames[0].frame, " to ",actionToUpdate.frames[-1].frame)

    '''
    if isRight:
            global currObject
            global currBone
            object = currObject
            bone = currBone
        else:
            global currObject_l
            global currBone_l
            object = currObject_l
            bone = currBone_l

        if object != "":
            if bone != "":
                if animDataExist(object):
                    fcurve = bpy.data.objects[object].animation_data.action.fcurves

                    boneCurve = []
                    for i in range(0, len(fcurve.items())):
                        if fcurve[i].data_path.split('"')[1] == bone:
                            boneCurve.append(fcurve[i])

                    frame = getFrameFromCurve(boneCurve, object, bone)

                    ## Remove old keyframe
                    for i in range(0, len(fcurve.items())):
                        if fcurve[i].data_path.split('"')[1] == bone:
                            while len(fcurve[i].keyframe_points) > 0:
                                #print("Deleting frame:", fcurve[i].keyframe_points[0].co[0], "of", i)
                                fcurve[i].keyframe_points.remove(fcurve[i].keyframe_points[0])

                    # Insert new keyframe
                    obj = bpy.data.objects[object]
                    pbone = obj.pose.bones[bone]
                    pbone.rotation_mode = 'QUATERNION'
                    for f in frame:
                        print("INSERTING FRAME:", f.frame)
                        pbone.location = f.loc
                        pbone.rotation_quaternion = f.rot
                        pbone.keyframe_insert(data_path='rotation_quaternion', frame=f.frame * factor)
                        pbone.keyframe_insert(data_path='location', frame=f.frame * factor)
            else:
                if animDataExist(object):
                    fcurve = bpy.data.objects[object].animation_data.action.fcurves
                    # Reading old frame
                    frame = getFrameFromCurve(fcurve, object, bone)

                    ## Remove old keyframe
                    for i in range(0, len(fcurve.items())):
                        while len(fcurve[i].keyframe_points) > 0:
                            print("Deleting frame:", fcurve[i].keyframe_points[0].co[0], "of", i)
                            fcurve[i].keyframe_points.remove(fcurve[i].keyframe_points[0])

                    obj = bpy.data.objects[object]
                    obj.rotation_mode = 'QUATERNION'
                    for f in frame:
                        print("INSERTING FRAME:", f.frame)
                        obj.location = f.loc
                        obj.rotation_quaternion = f.rot
                        obj.keyframe_insert(data_path='rotation_quaternion', frame=f.frame * factor)
                        obj.keyframe_insert(data_path='location', frame=f.frame * factor)

            if isRight:
                drawAction(object, bone, True, True)
            else:
                drawAction(object, bone, True, False)
    '''

    def moveAction(self, offset, isRight):
        global actions

        if isRight:
            actionToUpdate = actions[self.action_r_index]
        else:
            actionToUpdate = actions[self.action_l_index]

        actions.remove(actionToUpdate)
        deleteAction(actionToUpdate.obj, actionToUpdate.bone)

        # Update frames of actionToUpdate
        for f in actionToUpdate.frames:
            f.frame = f.frame + offset

        # create data struct for the insertFrame function
        frames = copy.deepcopy(actionToUpdate.frames)

        # Updates action name
        actionToUpdate.name = "Action" + actionToUpdate.obj + actionToUpdate.bone + "." + \
                              str(actionToUpdate.frames[0].frame) + "_" + str(actionToUpdate.frames[-1].frame)

        # Restore the remaining actions
        for a in actions:
            if a.obj == actionToUpdate.obj and a.bone == actionToUpdate.bone:
                frames += a.frames

        actions.append(actionToUpdate)
        if isRight:
            self.action_r_index = actions.index(actionToUpdate)
        else:
            self.action_l_index = actions.index(actionToUpdate)


        frames.sort(key=lambda x: x.frame, reverse=False)
        # Insert KeyFrame
        insertFrame(frames)
        drawAction(self.objToControll, self.boneToControll, True, True)
        drawAction(self.objToControll_l, self.boneToControll_l, True, False)
        drawActions_Overview(currObject, currBone)


        '''
        if isRight:
            global currObject
            global currBone
            object = currObject
            bone = currBone
        else:
            global currObject_l
            global currBone_l
            object = currObject_l
            bone = currBone_l

        if object != "":
            if bone != "":
                if animDataExist(object):
                    fcurve = bpy.data.objects[object].animation_data.action.fcurves

                    boneCurve = []
                    for i in range(0, len(fcurve.items())):
                        if fcurve[i].data_path.split('"')[1] == bone:
                            boneCurve.append(fcurve[i])

                    # Reading old frame
                    frame = getFrameFromCurve(boneCurve,object,bone)

                    ## Remove old keyframe
                    for i in range(0, len(fcurve.items())):
                        if fcurve[i].data_path.split('"')[1] == bone:
                            while len(fcurve[i].keyframe_points) > 0:
                                print("Deleting frame:", fcurve[i].keyframe_points[0].co[0], "of", i)
                                fcurve[i].keyframe_points.remove(fcurve[i].keyframe_points[0])

                    # Insert new keyframe
                    obj = bpy.data.objects[object]
                    pbone = obj.pose.bones[bone]
                    pbone.rotation_mode = 'QUATERNION'
                    for f in frame:
                        print("INSERTING FRAME:", f.frame)
                        pbone.location = f.loc
                        pbone.rotation_quaternion = f.rot
                        pbone.keyframe_insert(data_path='rotation_quaternion', frame=f.frame + offset)
                        pbone.keyframe_insert(data_path='location', frame=f.frame + offset)
            else:
                if animDataExist(object):
                    fcurve = bpy.data.objects[object].animation_data.action.fcurves

                    # Reading old frame
                    frame = getFrameFromCurve(fcurve,object,bone)

                    ## Remove old keyframe
                    for i in range(0, len(fcurve.items())):
                        while len(fcurve[i].keyframe_points) > 0:
                            print("Deleting frame:", fcurve[i].keyframe_points[0].co[0], "of", i)
                            fcurve[i].keyframe_points.remove(fcurve[i].keyframe_points[0])

                    obj = bpy.data.objects[object]
                    obj.rotation_mode = 'QUATERNION'
                    for f in frame:
                        print("INSERTING FRAME:", f.frame)
                        obj.location = f.loc
                        obj.rotation_quaternion = f.rot
                        obj.keyframe_insert(data_path='rotation_quaternion', frame=f.frame + offset)
                        obj.keyframe_insert(data_path='location', frame=f.frame + offset)

            if isRight:
                drawAction(object, bone, True, True)
            else:
                drawAction(object, bone, True, False)
        '''

    def display_menu(self, hide):

        print("[DEBUG] - display_menu: START")
        if not hide:
            bpy.data.objects['SettingsPanel'].location = bpy.data.objects['TUI.L'].location
            loc = copy.deepcopy(bpy.data.objects['SettingsPanel'].location) + Vector((0.55, 0.0, -0.46))

            for itemDict in bpy.types.Scene.value_textBox_map:
                for obj in bpy.types.Scene.value_textBox_map[itemDict]:
                    stringToEval = self.checkForKeywords(itemDict)
                    try:
                        var = eval(stringToEval)
                        bpy.data.objects[obj].data.body = str(var)
                    except:
                        bpy.data.objects[obj].data.body = 'Value N/A'

            print("[DEBUG] - display_menu: but in gui_object")
            for obj in bpy.data.objects:
                if 'SettingsPanelControl.' in obj.name or 'SettingsPanelFunction.' in obj.name:
                    obj.location = loc
                    loc[2] += obj.dimensions[2]

            # for but in self.gui_obj_custom:
            #     if 'Button.ApplyFunc' in but or 'Button.IncreaseValue' in but:
            #         parent = bpy.data.objects[but].parent
            #         parent.location = loc
            #         loc[2] += parent.dimensions[2]


        objToShow = ['SettingsPanel', 'TextBox.001', 'TextBox.002', 'TextBox.003',
                     'TextBox.003', 'TextBox.004', 'TextBox.005',  'TextBox.006',
                     'TextBox.018', 'TextBox.019',
                     'Button.000', 'Button.001', 'Button.002', 'Button.003',
                     'Button.004', 'Button.005', 'Button.006', 'Button.007',
                     'Button.008', 'Button.009', 'Button.010', 'Button.011',
                     'Button.012', 'Button.013', 'Button.014', 'Button.015',
                     'Button.016', 'Button.017', 'Button.018', 'Button.019',
                     'Button.020', 'Button.021', 'Button.022', 'Button.023']
        for obj in objToShow:
            bpy.data.objects[obj].hide = hide

        for obj in bpy.data.objects:
            if 'SettingsPanelControl' in obj.name or 'SettingsPanelFunction' in obj.name:
                obj.hide = hide
                for child in obj.children:
                    child.hide = hide
        # for but in self.gui_obj_custom:
        #     parent = bpy.data.objects[but].parent
        #     parent.hide = hide
        #     for child in parent.children:
        #         child.hide = hide


    def display_colorWheel(self):
        if 'Material_Diffuse_' in self.properties[self.prop_index]:
            bpy.data.objects['ColorPalette'].hide = False
            bpy.data.objects['ColorPaletteCursor'].hide = False
        else:
            bpy.data.objects['ColorPalette'].hide = True
            bpy.data.objects['ColorPaletteCursor'].hide = True

    def display_objName(self, hide):  ## -self
        if hide:
            newObjects = []
            for obj in bpy.data.objects:
                if obj.parent is None and not obj.name in self.gui_obj:  ## -self
                    print (obj.name)
                    text = bpy.data.objects['TextBox.000'].copy()
                    text.data = bpy.data.objects['TextBox.000'].data.copy()
                    text.name = "Text_" + obj.name
                    bpy.context.scene.objects.link(text)

                    text.data.body = obj.name
                    text.scale = (0.5, 0.5, 1)
                    text.layers = obj.layers
                    text.parent = bpy.data.objects['Origin']
                    text.location = obj.location

                    y = text.location[1] - bpy.data.objects['TUI.R'].location[1]
                    x = text.location[0] - bpy.data.objects['TUI.R'].location[0]
                    text.rotation_euler[2] = -math.pi / 2 + math.atan2(y, x)

                    text.show_x_ray = True
                    text.hide = False
                    text.select = True

        else:
            for child in bpy.data.objects['Origin'].children:
                bpy.data.scenes[0].objects.unlink(child)
                bpy.data.objects.remove(child)
            print("DELETE")

    def getKeyframeModeAction(self, isRight):
        global actions
        index_action = -1

        if isRight:
            obj, bone = self.objToControll, self.boneToControll
        else:
            obj, bone = self.objToControll_l, self.boneToControll_l

        for index, a in enumerate(actions):
            if a.name == 'Action' + obj + bone + ".KEYMODE":
                index_action = index
                break

        if index_action == -1:
            act = Action('Action' + obj + bone + ".KEYMODE", obj, bone, [])
            actions.append(act)
            return actions.index(act)
        else:
            return index_action

    def updatePropertiesList(self):
        self.prop_index = 0
        self.properties = []

        if self.objToControll =="":
            self.properties.append("None")  # -> .ghost_step
        else:
            if self.boneToControll!="":
                self.properties.append("KeyFrame") # -> .ghost_step

            else:
                if len(bpy.data.objects[self.objToControll].material_slots) == 0:
                    mat = bpy.data.materials.new(name=self.objToControll + '_Material')
                    bpy.data.objects[self.objToControll].data.materials.append(mat)

                ## For loop to insert materials prop
                for index in range(0, len(bpy.data.objects[self.objToControll].material_slots)):
                    self.properties.append("Material_Diffuse_" + str(index))

                ## For loop to insert alpha prop
                for index in range(0, len(bpy.data.objects[self.objToControll].material_slots)):
                    bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[index].name].use_transparency = True
                    self.properties.append("Material_Alpha_" + str(index))

                ## For loop to insert shapekeys prop
                if bpy.data.objects[self.objToControll].data.shape_keys != None:
                    # bpy.data.objects['Cube.002'].data.shape_keys.key_blocks[1].value = 1
                    for index in range(1, len(bpy.data.objects[
                                                  self.objToControll].data.shape_keys.key_blocks)):  ## Basis Shape key is not in properties list
                        self.properties.append("ShapeKey_" + str(index))

    def create_local_repr(self, dupliState):
        print("DEBUG [create_local_repr] - CREATE LOCAL REPR hide:", dupliState)

        if dupliState:
            selected_objects = []
            layers = (True, False, False, False, False,
                      False, False, False, False, False,
                      False, False, False, False, False,
                      False, False, False, False, False)

            if self.objToControll !="" and not '_Local.Repr' in self.objToControll:
                objToAdd = bpy.data.objects[self.objToControll]
                if objToAdd.parent is not None:
                    if objToAdd.parent.type == "ARMATURE":
                        objToAdd = objToAdd.parent
                selected_objects.append(objToAdd)

            if self.objToControll_l!="" and not '_Local.Repr' in self.objToControll_l and self.objToControll!=self.objToControll_l:
                objToAdd = bpy.data.objects[self.objToControll_l]
                if objToAdd.parent is not None:
                    if objToAdd.parent.type == "ARMATURE":
                        objToAdd = objToAdd.parent

                if len(selected_objects)>0:
                    if selected_objects[0].name != objToAdd.name:
                        selected_objects.append(objToAdd)
                else:
                    selected_objects.append(objToAdd)

            for selObj in selected_objects:
                print("DEBUG [create_local_repr] - selected_object", selObj.name)

            for (index, dupli_obj) in enumerate(selected_objects):
                print ("DEBUG [create_local_repr] - dupli_obj:", dupli_obj.name)
                if not dupli_obj.name + "_Local.Repr" in bpy.data.objects:
                    if dupli_obj.type == 'ARMATURE':
                        print ("DEBUG [create_local_repr] - dupli_obj is an Armature:")
                        children = []
                        for child in dupli_obj.children:
                            newObj = child.copy()
                            newObj.data = child.data.copy()
                            newObj.name = child.name + "_Local.Repr"
                            children.append(newObj)

                        arm = dupli_obj.copy()
                        arm.data = dupli_obj.data.copy()
                        arm.name = dupli_obj.name + "_Local.Repr"

                        for ob in children:
                            ob.parent = arm
                            ob.modifiers["Armature"].object = arm
                            bpy.context.scene.objects.link(ob)
                            ob.layers = layers

                        bpy.context.scene.objects.link(arm)
                        arm.layers = layers

                        # TODO: reset pbone.location to (0,0,0)
                        if index==0:
                            arm.location = bpy.data.objects['SettingsPanel'].location + Vector((0.3,-0.4,-0.7))
                        else:
                            arm.location = bpy.data.objects['SettingsPanel'].location + Vector((-0.3,-0.4,-0.7))

                        print ("DEBUG [create_local_repr] - OBJ CREATED:", arm.name)

                    if dupli_obj.type == 'MESH':
                        print ("DEBUG [create_local_repr] - dupli_obj is a Mesh:")
                        ob = dupli_obj.copy()
                        ob.data = dupli_obj.data.copy()
                        ob.name = dupli_obj.name + "_Local.Repr"
                        bpy.context.scene.objects.link(ob)
                        ob.layers = layers
                        if index==0:
                            ob.location = bpy.data.objects['SettingsPanel'].location + Vector((0.3,-0.4,-0.7))
                        else:
                            ob.location = bpy.data.objects['SettingsPanel'].location + Vector((-0.3,-0.4,-0.7))

                        print ("DEBUG [create_local_repr] - OBJ CREATED:", ob.name)

        else:
            print ("DEBUG [create_local_repr] - Destroy the object:")
            for obj in bpy.data.objects:
                if '_Local.Repr' in obj.name:
                    if len(obj.name) - obj.name.index('_Local.Repr') == 11: #The string _Local.Repr is a the end of the object's name
                        if obj.type=='ARMATURE':
                            obj.select = True
                            bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.data.scenes[0].objects.unlink(bpy.data.objects[obj.name])
                        bpy.data.objects.remove(bpy.data.objects[obj.name])

    def drawFCurve(self, fcurve, selectionState):

        if selectionState:
            isFirst = True

            data_path = self.properties[self.prop_index].split('-')[0]
            axes = int(self.properties[self.prop_index].split('-')[1])
            print ("DEBUG [drawFCurve] - data_path, axes = ", data_path, axes)

            curvedata = bpy.data.curves.new('Bezier', type='CURVE')
            curvedata.dimensions = '3D'
            curvedata.resolution_u = 12
            curvedata.show_normal_face = False
            objCurve = bpy.data.objects.new(self.properties[self.prop_index] + "_F-Curve", curvedata)
            objCurve.location = (0, 0.9, 1.5)
            spline = curvedata.splines.new('BEZIER')
            bpy.context.scene.objects.link(objCurve)
            objCurve.layers = (True, False, False, False, False,
                               False, False, False, False, False,
                               False, False, False, False, False,
                               False, False, False, False, False)


            for c in fcurve:
                for point in range(0, len(c.keyframe_points)):
                    if c.array_index == axes and data_path in c.data_path:
                        if isFirst:
                            isFirst = False
                        else:
                            spline.bezier_points.add(1)

                        if c.keyframe_points[point].handle_left_type != "AUTO_CLAMPED":
                            objCurve.data.splines[0].bezier_points[point].handle_left_type = c.keyframe_points[point].handle_left_type
                        objCurve.data.splines[0].bezier_points[point].handle_left = (c.keyframe_points[point].handle_left[0] / 100, 0, c.keyframe_points[point].handle_left[1])

                        objCurve.data.splines[0].bezier_points[point].co = (c.keyframe_points[point].co[0] / 100, 0, c.keyframe_points[point].co[1])

                        if c.keyframe_points[point].handle_right_type != "AUTO_CLAMPED":
                            objCurve.data.splines[0].bezier_points[point].handle_right_type = c.keyframe_points[point].handle_right_type
                        objCurve.data.splines[0].bezier_points[point].handle_right = (c.keyframe_points[point].handle_right[0] / 100, 0, c.keyframe_points[point].handle_right[1])

            objCurve.select = True
            bpy.context.scene.objects.active = objCurve
            bpy.ops.object.mode_set(mode='EDIT')

        else:
            bpy.ops.object.mode_set(mode='OBJECT')
            for obj in bpy.data.objects:
                if '_F-Curve' in obj.name:
                    if len(obj.name) - obj.name.index(
                            '_F-Curve') == 8:  # The string _Local.Repr is a the end of the object's name
                        bpy.data.scenes[0].objects.unlink(bpy.data.objects[obj.name])
                        bpy.data.objects.remove(bpy.data.objects[obj.name])

    def updateFrameTypeList(self, fcurve):
        self.prop_index = 0
        self.properties = []

        for c in fcurve:
            item = c.data_path + "-" + str(c.array_index)
            if not item in self.properties:
                self.properties.append(item)

    def applyFcurve(self, fcurve):

        data_path = self.properties[self.prop_index].split('-')[0]
        axes = int(self.properties[self.prop_index].split('-')[1])
        objCurve = bpy.data.objects[self.properties[self.prop_index] + "_F-Curve"]

        c = None

        for fc in fcurve:
            if fc.array_index == axes and fc.data_path == data_path:
                c = fc
                break

        print("DEBUG [applyFcurve] - ", fc.array_index, fc.data_path)

        for index, p in enumerate(objCurve.data.splines.active.bezier_points):
            print(p.handle_left, p.co, p.handle_right)

            c.keyframe_points[index].handle_left[0] = objCurve.data.splines[0].bezier_points[index].handle_left[0] * 100
            c.keyframe_points[index].handle_left[1] = objCurve.data.splines[0].bezier_points[index].handle_left[2]

            c.keyframe_points[index].handle_right[0] = objCurve.data.splines[0].bezier_points[index].handle_right[0] * 100
            c.keyframe_points[index].handle_right[1] = objCurve.data.splines[0].bezier_points[index].handle_right[2]

            c.keyframe_points[index].co[0] = objCurve.data.splines[0].bezier_points[index].co[0] * 100
            c.keyframe_points[index].co[1] = objCurve.data.splines[0].bezier_points[index].co[2]

        print("DEBUG [applyFcurve] - {DONE}")

    def applyConstraint(self, isRight):
        if isRight:
            type = self.axes[self.curr_axes_r].split('_')[0]
            axes = self.axes[self.curr_axes_r].split('_')[1]
            obj = self.objToControll
            bone = self.boneToControll
            init_loc = self.initial_loc
            init_rot = self.initial_rot

        else:
            type = self.axes[self.curr_axes_l].split('_')[0]
            axes = self.axes[self.curr_axes_l].split('_')[1]
            obj = self.objToControll_l
            bone = self.boneToControll_l
            init_loc = self.initial_loc_l
            init_rot = self.initial_rot_l

        if type == 'LOC':
            if bone!="":
                bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'XYZ'
                bpy.data.objects[obj].pose.bones[bone].rotation_euler = init_rot
                bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'QUATERNION'

            else:
                bpy.data.objects[obj].rotation_mode = 'XYZ'
                bpy.data.objects[obj].rotation_euler = init_rot
                bpy.data.objects[obj].rotation_mode = 'QUATERNION'

            if axes == 'X':
                if bone != "":
                    bpy.data.objects[obj].pose.bones[bone].location[1] = init_loc[1]
                    bpy.data.objects[obj].pose.bones[bone].location[2] = init_loc[2]
                else:
                    bpy.data.objects[obj].location[1] = init_loc[1]
                    bpy.data.objects[obj].location[2] = init_loc[2]

            if axes == 'Y':
                if bone != "":
                    bpy.data.objects[obj].pose.bones[bone].location[0] = init_loc[0]
                    bpy.data.objects[obj].pose.bones[bone].location[2] = init_loc[2]
                else:
                    bpy.data.objects[obj].location[0] = init_loc[0]
                    bpy.data.objects[obj].location[2] = init_loc[2]

            if axes == 'Z':
                if bone != "":
                    bpy.data.objects[obj].pose.bones[bone].location[0] = init_loc[0]
                    bpy.data.objects[obj].pose.bones[bone].location[1] = init_loc[1]
                else:
                    bpy.data.objects[obj].location[0] = init_loc[0]
                    bpy.data.objects[obj].location[1] = init_loc[1]

        if type == 'ROT':
            if bone!="":
                bpy.data.objects[obj].pose.bones[bone].location = init_loc
            else:
                bpy.data.objects[obj].location = init_loc

            if axes == 'X':
                if bone!="":
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[1] = init_rot[1]
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[2] = init_rot[2]
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'QUATERNION'
                else:
                    bpy.data.objects[obj].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].rotation_euler[1] = init_rot[1]
                    bpy.data.objects[obj].rotation_euler[2] = init_rot[2]
                    bpy.data.objects[obj].rotation_mode = 'QUATERNION'

            if axes == 'Y':
                if bone!="":
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[0] = init_rot[0]
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[2] = init_rot[2]
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'QUATERNION'
                else:
                    bpy.data.objects[obj].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].rotation_euler[0] = init_rot[0]
                    bpy.data.objects[obj].rotation_euler[2] = init_rot[2]
                    bpy.data.objects[obj].rotation_mode = 'QUATERNION'

            if axes == 'Z':
                if bone!="":
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[0] = init_rot[0]
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[1] = init_rot[1]
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'QUATERNION'
                else:
                    bpy.data.objects[obj].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].rotation_euler[0] = init_rot[0]
                    bpy.data.objects[obj].rotation_euler[1] = init_rot[1]
                    bpy.data.objects[obj].rotation_mode = 'QUATERNION'

    def incrementTransformation(self, up):
        if up:
            amount = 0.02
        else:
            amount = -0.02

        type = ""
        axes = ""
        if self.curr_axes_r != 0:
            type = self.axes[self.curr_axes_r].split('_')[0]
            axes = self.axes[self.curr_axes_r].split('_')[1]
            obj = self.objToControll
            bone = self.boneToControll


        if self.curr_axes_l != 0:
            type = self.axes[self.curr_axes_l].split('_')[0]
            axes = self.axes[self.curr_axes_l].split('_')[1]
            obj = self.objToControll_l
            bone = self.boneToControll_l


        if type == 'LOC':
            if axes == 'X':
                if bone != "":
                    bpy.data.objects[obj].pose.bones[bone].location[0] += amount
                else:
                    bpy.data.objects[obj].location[0] += amount

            if axes == 'Y':
                if bone != "":
                    bpy.data.objects[obj].pose.bones[bone].location[1] += amount
                else:
                    bpy.data.objects[obj].location[1]+= amount

            if axes == 'Z':
                if bone != "":
                    bpy.data.objects[obj].pose.bones[bone].location[2] += amount
                else:
                    bpy.data.objects[obj].location[2] += amount

        if type == 'ROT':
            amount = amount*50
            if axes == 'X':
                if bone!="":
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[0] += amount
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'QUATERNION'
                else:
                    bpy.data.objects[obj].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].rotation_euler[0] += amount
                    bpy.data.objects[obj].rotation_mode = 'QUATERNION'

            if axes == 'Y':
                if bone!="":
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[1] +=amount
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'QUATERNION'
                else:
                    bpy.data.objects[obj].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].rotation_euler[1] +=amount
                    bpy.data.objects[obj].rotation_mode = 'QUATERNION'

            if axes == 'Z':
                if bone!="":
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].pose.bones[bone].rotation_euler[2]+=amount
                    bpy.data.objects[obj].pose.bones[bone].rotation_mode = 'QUATERNION'
                else:
                    bpy.data.objects[obj].rotation_mode = 'XYZ'
                    bpy.data.objects[obj].rotation_euler[2] +=amount
                    bpy.data.objects[obj].rotation_mode = 'QUATERNION'


        print (type, axes)

    def getOperatorFormIndex(self, index):
        if index==0:
            return 'DIFFERENCE'
        if index==1:
            return 'UNION'
        if index==2:
            return 'INTERSECT'

    def getOperatorStringFormIndex(self, index):
        if index==0:
            return 'Differenza'
        if index==1:
            return 'Unione'
        if index==2:
            return 'Intersezione'

    def createArmature(self):

        # create armature rig data
        arm = bpy.data.armatures.new("Armature")
        # create armature object containing rig
        armObj = bpy.data.objects.new("Armature_" + self.objToControll, arm)
        bpy.context.scene.objects.link(armObj)
        armObj.layers = (True, False, False, False, False,
                      False, False, False, False, False,
                      False, False, False, False, False,
                      False, False, False, False, False)
        armObj.location = bpy.data.objects[self.objToControll].location
        armObj.show_x_ray = True

        armObj.select = True
        bpy.context.scene.objects.active = armObj

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.context.scene.cursor_location = armObj.location
        bpy.ops.armature.bone_primitive_add()

        armObj.data.edit_bones[-1].select_head = False
        armObj.data.edit_bones[-1].select_tail = False
        armObj.data.edit_bones[-1].select = False

        bpy.ops.object.mode_set(mode='OBJECT')
        return armObj

    def addBone(self):

        global pointIndex_r
        armObj = bpy.data.objects[self.objToControll]
        if pointIndex_r[0]!=-1:
            bpy.context.scene.cursor_location = armObj.location + armObj.data.edit_bones[pointIndex_r[0]].tail
        else:
            bpy.context.scene.cursor_location = armObj.location + armObj.data.edit_bones[-1].tail

        bpy.ops.armature.bone_primitive_add()

        armObj.data.edit_bones[-1].tail[2] -= 0.5
        armObj.data.edit_bones[-1].select_head = False
        armObj.data.edit_bones[-1].select_tail = False
        armObj.data.edit_bones[-1].select = False

        if pointIndex_r[0] != -1:
            armObj.data.edit_bones[-1].parent = armObj.data.edit_bones[pointIndex_r[0]]
            armObj.data.edit_bones[-1].use_connect = True

            if pointIndex_r[1] == -1:
                armObj.data.edit_bones[pointIndex_r[0]].select_head = True
            if pointIndex_r[1] == 0:
                armObj.data.edit_bones[pointIndex_r[0]].select = True
            if pointIndex_r[1] == 1:
                armObj.data.edit_bones[pointIndex_r[0]].select_tail = True

    def addMirroredBone(self, boneName):
        global pointIndex_r
        armObj = bpy.data.objects[self.objToControll]

        bpy.context.scene.cursor_location = armObj.location + armObj.data.edit_bones[pointIndex_r[0]].head
        bpy.ops.armature.bone_primitive_add()
        armObj.data.edit_bones[-1].name = boneName
        armObj.data.edit_bones[-1].select_head = False
        armObj.data.edit_bones[-1].select_tail = False
        armObj.data.edit_bones[-1].select = False

        print ("[DEBUG] - addMirroredBone: setting parent = ", armObj.data.edit_bones[pointIndex_r[0]].parent.name)
        if armObj.data.edit_bones[pointIndex_r[0]].parent.name + '_MIRRORED' in armObj.data.edit_bones:
            armObj.data.edit_bones[-1].parent = armObj.data.edit_bones[armObj.data.edit_bones[pointIndex_r[0]].parent.name + '_MIRRORED']
        else:
            armObj.data.edit_bones[-1].parent = armObj.data.edit_bones[pointIndex_r[0]].parent

        armObj.data.edit_bones[-1].use_connect = armObj.data.edit_bones[pointIndex_r[0]].use_connect

        armObj.data.edit_bones[-1].tail = armObj.data.edit_bones[pointIndex_r[0]].tail
        if self.mirror_axes[0]:
            armObj.data.edit_bones[-1].tail[0] = -armObj.data.edit_bones[pointIndex_r[0]].tail[0]
        if self.mirror_axes[1]:
            armObj.data.edit_bones[-1].tail[1] = -armObj.data.edit_bones[pointIndex_r[0]].tail[1]
        if self.mirror_axes[2]:
            armObj.data.edit_bones[-1].tail[2] = -armObj.data.edit_bones[pointIndex_r[0]].tail[2]

        if pointIndex_r[1] == -1:
            armObj.data.edit_bones[pointIndex_r[0]].select_head = True
            #armObj.data.edit_bones[-1].select_head = True
        if pointIndex_r[1] == 0:
            armObj.data.edit_bones[pointIndex_r[0]].select = True
            #armObj.data.edit_bones[-1].select= True
        if pointIndex_r[1] == 1:
            armObj.data.edit_bones[pointIndex_r[0]].select_tail = True
            #armObj.data.edit_bones[-1].select_tail = True

        print("[DEBUG] - AddMirroredBone: {DONE}")

    def getUpdatedVertices(self, objSource):
        obj = bpy.data.objects[objSource]
        mesh = obj.to_mesh(bpy.context.scene, True, 'PREVIEW')  # apply modifiers with preview settings
        mesh.transform(obj.matrix_world)  # apply loc/rot/scale
        result = mesh.vertices
        bpy.data.meshes.remove(mesh)  # remove 'posed' mesh
        return result

    def createVertices(self):

        obj = bpy.data.objects[self.objToControll]
        mesh = bpy.data.meshes.new(self.objToControll + "_VERTICES_MESH")
        verts = []

        sourceVertices = self.getUpdatedVertices(self.objToControll)

        for i in range(0, len(sourceVertices)):
            #verts.append(obj.matrix_world * sourceVertices[i].co)
            verts.append(sourceVertices[i].co)

        faces = []
        mesh.from_pydata(verts, [], faces)
        mesh.update(calc_edges=False)
        newObj = bpy.data.objects.new(self.objToControll + "_VERTICES", mesh)
        bpy.context.scene.objects.link(newObj)
        newObj.layers = (True, False, False, False, False,
                         False, False, False, False, False,
                         False, False, False, False, False,
                         False, False, False, False, False)

    def checkForKeywords(self, string):
        newString = string

        # if "bpy.context.object" in string:
        #     if isRight:
        #         string = string.replace("bpy.context.object", 'bpy.data.objects["' + self.objToControll + '"]')
        #     else:
        #         string = string.replace("bpy.context.object", 'bpy.data.objects["' + self.objToControll_l + '"]')

        print("[DEBUG] - checkForKeywords: string", string)

        if "SELECTED_OBJECT" in string:
            string = string.replace("SELECTED_OBJECT", '"'+ self.objToControll + '"')

        if "SELECTED_BONE" in string:
            string = string.replace("SELECTED_BONE", '"'+ self.boneToControll + '"')

        return string


    def updateControl_controller(self, incBool, controller):

        print("DEBUG [updateControl] - ", controller)
        try:
            print (bpy.types.Scene.controller_map[controller])
            stringToEval = self.checkForKeywords(bpy.types.Scene.controller_map[controller])
            var = eval(stringToEval)
        except:
            print("Command not configured")
            return

        if isinstance(var, bool):
            string = stringToEval + "= not " + stringToEval
            print (string)
            exec (string)

        elif isinstance(var, int):
            if incBool:
                string = stringToEval + "+= 1"
            else:
                string = stringToEval + "-= 1"
            print (string)
            exec (string)

        elif isinstance(var, float):
            if incBool:
                string = stringToEval + " += 0.1"
            else:
                string = stringToEval + " -= 0.1"
            print(string)
            exec (string)

        elif isinstance(var, str):

            # Get the name of the enumerate prop
            list = []
            string = stringToEval
            indices = [i for i, ltr in enumerate(string) if ltr == "."]
            # Subdivede the name of the prop form the path
            path_prop = string[:indices[-1]]  #
            prop = string[indices[-1] + 1:]  # Remove the "." char from the name pof the property
            print (path_prop, prop)

            #Get the RNA properties of the prop
            var = eval(path_prop)
            for i in var.bl_rna.properties[prop].enum_items:
                print(i.identifier)
                list.append(i.identifier)

            # get the index of the current prop value
            current_prop = eval(stringToEval)
            current_prop_index = list.index(current_prop)
            print (current_prop_index)

            # Change the index
            #current_prop_index += 1
            #if current_prop_index == len(list):
            #    current_prop_index = 0
            current_prop_index = self.updateCurrentListIndex(len(list), current_prop_index, incBool)

            string = stringToEval + " = '" + list[current_prop_index] + "'"
            print(string)
            exec (string)
            # bpy.data.objects['TextBox_Value'].data.body = str(var)

        elif isinstance(var, object):
            #TODO: check if is a sub class of object like bpy.types.CopyLocationConstraint

            # Get alternatives
            list = []
            for obj in bpy.data.objects:
                if not obj.name in self.gui_obj and not obj.name in bpy.types.Scene.gui:
                    list.append(obj.name)

            current_prop = eval(stringToEval)
            current_prop_index = -1
            if current_prop != None:
                current_prop_index = list.index(current_prop.name)
                print (current_prop_index)

            current_prop_index = self.updateCurrentListIndex(len(list),current_prop_index,incBool)

            string = stringToEval + " = bpy.data.objects['" + list[current_prop_index] + "']"
            print(string)
            exec (string)

        for obj in bpy.types.Scene.value_textBox_map[bpy.types.Scene.controller_map[controller]]:
            try:
                var = eval(stringToEval)
                bpy.data.objects[obj].data.body = str(var)
            except:
                bpy.data.objects[obj].data.body = 'Value N/A'
        print("DEBUG [updateControl] - {Finished}")

    def updateControl_gui(self, incBool, controller):
        print("DEBUG [updateControl_gui] - ", controller)
        print (bpy.types.Scene.gui_map[controller])

        stringToEval = self.checkForKeywords(bpy.types.Scene.gui_map[controller])
        var = eval(stringToEval)

        if isinstance(var, bool):
            string = stringToEval + "= not " + stringToEval
            print (string)
            exec (string)

        elif isinstance(var, int):
            print("is a int")
            if incBool:
                string = stringToEval + "+= 1"
            else:
                string = stringToEval + "-= 1"
            print (string)
            exec (string)

        elif isinstance(var, float):
            print("is a float")
            if incBool:
                string = stringToEval + " += 0.1"
            else:
                string = stringToEval + " -= 0.1"
            print(string)

            print (string)
            exec (string)

        elif isinstance(var, str):
            # Get the name of the enumerate prop
            list = []
            string = stringToEval
            indices = [i for i, ltr in enumerate(string) if ltr == "."]
            # Subdivede the name of the prop form the path
            path_prop = string[:indices[-1]]  #
            prop = string[indices[-1] + 1:]  # Remove the "." char from the name pof the property
            print (path_prop, prop)

            #Get the RNA properties of the prop
            var = eval(path_prop)
            for i in var.bl_rna.properties[prop].enum_items:
                print(i.identifier)
                list.append(i.identifier)

            # get the index of the current prop value
            current_prop = eval(stringToEval)
            current_prop_index = list.index(current_prop)
            print (current_prop_index)

            # Change the index
            #current_prop_index += 1
            #if current_prop_index == len(list):
            #    current_prop_index = 0
            current_prop_index = self.updateCurrentListIndex(len(list), current_prop_index, incBool)

            string = stringToEval + " = '" + list[current_prop_index] + "'"
            print(string)
            exec (string)
            # bpy.data.objects['TextBox_Value'].data.body = str(var)

        elif isinstance(var, object):
            #TODO: check if is a sub class of object like bpy.types.CopyLocationConstraint

            # Get alternatives
            list = []
            for obj in bpy.data.objects:
                if not obj.name in self.gui_obj and not obj.name in bpy.types.Scene.gui:
                    list.append(obj.name)

            current_prop = eval(stringToEval)
            current_prop_index = -1
            if current_prop != None:
                current_prop_index = list.index(current_prop.name)
                print (current_prop_index)

            current_prop_index = self.updateCurrentListIndex(len(list),current_prop_index,incBool)

            string = stringToEval + " = bpy.data.objects['" + list[current_prop_index] + "']"
            print(string)
            exec (string)

        for obj in bpy.types.Scene.value_textBox_map[bpy.types.Scene.gui_map[controller]]:
            try:
                var = eval(stringToEval)
                bpy.data.objects[obj].data.body = str(var)
            except:
                bpy.data.objects[obj].data.body = 'Value N/A'

        print("DEBUG [updateControl_gui] - {Finished}")

    def updateCurrentListIndex(self, size, index, incBool):
        if incBool:
            index += 1
            if index >= size:
                index = 0
        else:
            index-=1
            if index < 0:
                index = size-1
        return index


    def deleteVertices(self):
        new_obj = bpy.data.objects[self.objToControll + "_VERTICES"]
        bpy.data.scenes[0].objects.unlink(new_obj)
        bpy.data.objects.remove(new_obj)

    def updateButtonStatus(self, mode):
        bpy.data.textures['Texture-Perform-Button'].image = bpy.data.images['Button(Action).png']
        bpy.data.textures['Texture-Keyframe-Button'].image = bpy.data.images['Button(Keyframe).png']
        bpy.data.textures['Texture-F-curve-Button'].image = bpy.data.images['Button(FCurve).png']
        bpy.data.textures['Texture-EditAction-Button'].image = bpy.data.images['Button(Edit-action).png']
        bpy.data.textures['Texture-Rigging-Button'].image = bpy.data.images['Button(Rigging).png']
        bpy.data.textures['Texture-Skinning-Button'].image = bpy.data.images['Button(Skinning).png']
        bpy.data.textures['Texture-Constraints-Button'].image = bpy.data.images['Button(Constraints).png']


        if mode == "ACTION":
            bpy.data.textures['Texture-Perform-Button'].image = bpy.data.images['Button(Action)_ON.png']
        elif mode == "KEYFRAME":
            bpy.data.textures['Texture-Keyframe-Button'].image = bpy.data.images['Button(Keyframe)_ON.png']
        elif mode == "FCURVE":
            bpy.data.textures['Texture-F-curve-Button'].image = bpy.data.images['Button(FCurve)_ON.png']
        elif mode == "EDIT_ACTION":
            bpy.data.textures['Texture-EditAction-Button'].image = bpy.data.images['Button(Edit-action)_ON.png']
        elif mode == "RIGGING":
            bpy.data.textures['Texture-Rigging-Button'].image = bpy.data.images['Button(Rigging)_ON.png']
        elif mode == "SKINNING":
            bpy.data.textures['Texture-Skinning-Button'].image = bpy.data.images['Button(Skinning)_ON.png']
        elif mode == "CONSTRAINTS":
            bpy.data.textures['Texture-Constraints-Button'].image = bpy.data.images['Button(Constraints)_ON.png']

    # ---------------------------------------- #
    # Main Loop
    # ---------------------------------------- #
    def loop(self, context):
        """
        Get fresh tracking data
        """
        try:
            data = self._hmd.update()
            self._eye_orientation_raw[0] = data[0]
            self._eye_orientation_raw[1] = data[2]
            self._eye_position_raw[0] = data[1]
            self._eye_position_raw[1] = data[3]


            ## NEW CODE
            if self.AppMode == "TANGIBLE_VR":
                self.setTracker()
                #

            elif self.AppMode == "BLENDER_VR":
                # MODE_2: VIVE_CONTROLLER
                self.setController(self.ctrl_index_r)
                # ctrl_state contains the value of the button
                idx, ctrl_state = openvr.IVRSystem().getControllerState(self.ctrl_index_r)
                idx_l, ctrl_state_l = openvr.IVRSystem().getControllerState(self.ctrl_index_l)

                ctrl = bpy.data.objects['Controller.R']
                ctrl_l = bpy.data.objects['Controller.L']
                tui = bpy.data.objects['TUI.R']
                tui_l = bpy.data.objects['TUI.L']

                pointer = bpy.data.objects['SelectedObj']
                camera = bpy.data.objects['Camera']

                timeSlider = bpy.data.objects['TimelineSlider']

                ########## Right_Controller_States ##########

                if self.state == State.IDLE:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll
                    tui.hide = True

                    # DECISIONAL
                    if (ctrl_state.ulButtonPressed == 4):
                        print("IDLE -> DECISIONAL")
                        self.changeSelection(self.objToControll, self.boneToControll, False)
                        drawAction(self.objToControll, self.boneToControll, False, True)
                        self.state = State.DECISIONAL

                    # INTERACTION_LOCAL
                    if (ctrl_state.ulButtonPressed == 8589934592 and self.objToControll != ""):
                        print("IDLE -> INTERACTION LOCAL")
                        self.state = State.INTERACTION_LOCAL
                        self.curr_axes_r = 0

                        if self.boneToControll != "":
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].matrix.to_quaternion()
                            self.diff_loc = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].matrix.to_translation() - ctrl.location
                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].location)
                            bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'QUATERNION'

                        else:
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll].rotation_quaternion
                            self.diff_loc = bpy.data.objects[self.objToControll].location - ctrl.location
                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].location)
                            bpy.data.objects[self.objToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].rotation_mode = 'QUATERNION'

                    # PLAY/RECORD
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x,y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                        if y < 0:
                            print("PLAY BUTTON")
                            self.state = State.START_ANIMATION

                        if x > 0 and y > 0:
                            global recordFlag
                            if not recordFlag:
                                self.state = State.START_RECORD
                            else:
                                self.state = State.END_RECORD

                        if x <0 and  y > 0:
                            print ("DELETE ACTIONS")
                            self.state = State.DELETE

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER
                        #self.state = State.CUSTOM_CONTROL_ENTER

                if self.state == State.CUSTOM_CONTROL_ENTER:
                    if ctrl_state.ulButtonPressed != 2:
                        bpy.data.textures['Texture.R'].image = bpy.data.images['Hand-R.png']
                        bpy.data.textures['Texture.L'].image = bpy.data.images['Hand-L.png']
                        self.state = State.CUSTOM_CONTROL
                        self.state_l = StateLeft.CUSTOM_CONTROL

                if self.state == State.CUSTOM_CONTROL:
                    # Trigger
                    if ctrl_state.ulButtonPressed == 8589934592:
                        pass

                    # Trackpad
                    if ctrl_state.ulButtonPressed == 4294967296:
                        print ("exec Trackpad.R_UR OnKeyDown:", bpy.data.scenes["Scene"].my_tool.trackpadR_UR_down)
                        exec (bpy.data.scenes["Scene"].my_tool.gripR_down)
                        self.state = State.CUSTOM_CONTROL_TRACKPAD_RELEASED

                    # Menu Button
                    if ctrl_state.ulButtonPressed == 2:
                        pass

                    # Gripper
                    if (ctrl_state.ulButtonPressed == 4):
                        print("exec Gripper.R OnKeyDown:", bpy.data.scenes["Scene"].my_tool.gripR_down)
                        exec (bpy.data.scenes["Scene"].my_tool.gripR_down)
                        self.state = State.CUSTOM_CONTROL_GRIPPER_RELEASED

                if self.state == State.DECISIONAL:

                    print("Decisional")
                    bpy.data.objects["Text.R"].data.body = "Selection\n " + self.objToControll + "-" + self.boneToControll
                    tui.hide = False
                    pointer.hide = False

                    # Compute the nearest object
                    try:
                        self.objToControll, self.boneToControll = self.getClosestItem(pointer,True)
                    except:
                        print("Error during selection")
                        playerSound().start()
                    global currObject
                    global currBone
                    currObject = self.objToControll
                    currBone = self.boneToControll
                    print("Current obj:", self.objToControll, self.boneToControll)

                    if ctrl_state.ulButtonPressed != 4:

                        #print("touch button released")
                        self.changeSelection(self.objToControll, self.boneToControll, True)
                        print("DEBUG [DECISIONAL] - Starting to change Action text ")
                        drawAction(self.objToControll, self.boneToControll, True, True)
                        drawAction(self.objToControll_l, self.boneToControll_l, True, False)
                        print("DEBUG [DECISIONAL] - Finish to change Action text ")
                        pointer.hide = True

                        # Virtual Camera management
                        if self.objToControll!="" and bpy.data.objects[self.objToControll].type == 'CAMERA':
                            bpy.data.objects['Screen.R'].hide = False
                        else:
                            bpy.data.objects['Screen.R'].hide = True

                        global mode
                        if mode == "ACTION":
                            print ("DECISIONAL -> IDLE")
                            global local_repr_ON
                            if local_repr_ON:
                                print("DEBUG [DECISIONAL] - Calling create_local_repre")
                                self.create_local_repr(local_repr_ON)
                            self.state = State.IDLE

                        if mode == "KEYFRAME":
                            # Create an action to contain keyframe defined in KEYMODE if not exist
                            self.action_r_index = self.getKeyframeModeAction(True)
                            # Updates keyframe visualization
                            print("UPDATING KEYFRAME")
                            updateKeyframeVisualization()
                            print ("DECISIONAL -> IDLE (KEY MODE)")
                            if local_repr_ON:
                                print("DEBUG [DECISIONAL] - Calling create_local_repre")
                                self.create_local_repr(local_repr_ON)
                            self.state = State.IDLE_KEYMODE

                        if mode == "TUNNING_PERF":
                            tui.hide = True
                            self.updatePropertiesList()
                            bpy.data.objects["Text.L"].data.body = "Property:\n" + self.properties[self.prop_index]
                            #updatePropKeyframeVisualization()
                            drawActionProp(self.objToControll, self.boneToControll, True)
                            self.display_colorWheel()
                            self.state = State.IDLE_TUNING_PERF

                        if mode == "TUNNING_KEY":
                            tui.hide = True
                            self.updatePropertiesList()
                            bpy.data.objects["Text.L"].data.body = "Property:\n" + self.properties[self.prop_index]
                            updatePropKeyframeVisualization()
                            self.display_colorWheel()
                            self.state = State.IDLE_TUNING_KEY

                        if mode == "CONSTRAINTS":
                            tui.hide = True
                            print ("DECISIONAL -> IDLE (IK)")
                            self.state = State.IDLE_ARM_CONSTR

                if self.state == State.INTERACTION_LOCAL:
                    bpy.data.objects["Text.R"].data.body = "Interaction\n" + self.objToControll + "-" + self.boneToControll + "\n" + self.axes[self.curr_axes_r]
                    tui.hide = True
                    pointer.hide = True

                    ## Controll object scale
                    if self.objToControll == self.objToControll_l and self.boneToControll == self.boneToControll_l and ctrl_state_l.ulButtonPressed == 8589934592:
                        if self.boneToControll!="":
                            self.initial_scale = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale)
                        else:
                            self.initial_scale = copy.deepcopy(bpy.data.objects[self.objToControll].scale)

                        self.diff_distance = self.computeTargetObjDistance("TUI.L", "", True)

                        self.state = State.SCALING
                        self.state_l = StateLeft.SCALING

                    else:
                        if self.boneToControll != "":
                            ## The object to move is a bone
                            bone = bpy.data.objects[self.objToControll]
                            pbone = bone.pose.bones[self.boneToControll]
                            scale = copy.deepcopy(pbone.scale)
                            translationMatrix = Matrix(((0.0, 0.0, 0.0, self.diff_loc[0]),
                                                        (0.0, 0.0, 0.0, self.diff_loc[1]),
                                                        (0.0, 0.0, 0.0, self.diff_loc[2]),
                                                        (0.0, 0.0, 0.0, 1.0)))
                            diff_rot_matr = self.diff_rot.to_matrix()
                            pbone.matrix = (ctrl.matrix_world + translationMatrix) * diff_rot_matr.to_4x4()
                            pbone.scale = scale

                            self.applyConstraint(True)

                            global local_repr_ON
                            if local_repr_ON and '_Local.Repr' in self.objToControll:
                                #Copy location and rotation to the target bone
                                pboneTarget = bpy.data.objects[self.objToControll.split('_Local.Repr')[0]].pose.bones[self.boneToControll]
                                pboneTarget.rotation_quaternion = copy.deepcopy(pbone.rotation_quaternion)
                                pboneTarget.location = copy.deepcopy(pbone.location)

                        else:
                            ## The object to move is a mesh
                            bpy.data.objects[self.objToControll].rotation_quaternion = ctrl.rotation_quaternion * self.diff_rot
                            bpy.data.objects[self.objToControll].location = ctrl.location + self.diff_loc

                            self.applyConstraint(True)

                            global local_repr_ON
                            if local_repr_ON and '_Local.Repr' in self.objToControll:
                                objTarget = bpy.data.objects[self.objToControll.split('_Local.Repr')[0]]
                                objTarget.rotation_quaternion = bpy.data.objects[self.objToControll].rotation_quaternion


                    if (ctrl_state.ulButtonPressed==8589934596):
                        print("INTERACTION_LOCAL -> CHANGE_AXIS")
                        self.state = State.CHANGE_AXES

                    if (ctrl_state.ulButtonPressed != 8589934592 and ctrl_state.ulButtonPressed != 8589934596):
                        # print("grillet released")
                        global mode
                        if mode == "ACTION":
                            self.state = State.IDLE
                            print ("INTERACTION_LOCAL -> IDLE")
                        if mode == "KEYFRAME":
                            self.state = State.IDLE_KEYMODE
                            print ("INTERACTION_LOCAL -> IDLE (KEY MODE)")
                        if mode == "TUNNING_PERF":
                            self.state = State.IDLE_TUNING_PERF
                            print ("INTERACTION_LOCAL -> IDLE (TUNNING PERF)")
                        if mode == "TUNING_KEY":
                            self.state = State.IDLE_TUNING_KEY
                            print ("INTERACTION_LOCAL -> IDLE (TUNNING KEY)")
                        if mode == "CONSTRAINTS":
                            self.state = State.IDLE_ARM_CONSTR
                            print ("INTERACTION_LOCAL -> IDLE (ARM IK)")

                if self.state == State.CHANGE_AXES:
                    if (ctrl_state.ulButtonPressed==8589934592):
                        self.curr_axes_r+=1
                        if self.curr_axes_r>=len(self.axes):
                            self.curr_axes_r=0
                        self.curr_axes_l = 0
                        print(self.curr_axes_r)
                        print("CHANGE_AXIS -> INTERACTION_LOCAL")
                        self.state = State.INTERACTION_LOCAL

                    if (ctrl_state.ulButtonPressed==0):
                        # print("grillet released")
                        global mode
                        if mode == "ACTION":
                            self.state = State.IDLE
                            print ("CHANGE_AXIS -> IDLE")
                        if mode == "KEYFRAME":
                            self.state = State.IDLE_KEYMODE
                            print ("CHANGE_AXIS -> IDLE (KEY MODE)")

                if self.state == State.START_RECORD:
                    if ctrl_state.ulButtonPressed!=4294967296:
                        global playingAnimation
                        if not playingAnimation:
                            global recordFlag
                            recordFlag = True
                            recorder(0,self.AppMode).start()
                            playerSound().start()
                            self.state = State.IDLE
                        else:
                            print ("The system is already playing an animation")

                if self.state == State.END_RECORD:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        global recordFlag
                        recordFlag = False
                        playerSound().start()
                        self.state = State.IDLE

                if self.state == State.START_ANIMATION:
                    print ("START_ANIMATION")
                    if ctrl_state.ulButtonPressed != 4294967296:
                        global playingAnimation

                        if not playingAnimation:
                            global recordFlag
                            if not recordFlag:
                                playingAnimation = True
                                playerSound().start()
                                animator(self.AppMode).start()
                                bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R3.png']
                            else:
                                print("The system is already recording")

                        self.state = State.PLAY_ANIMATION

                if self.state == State.DELETE:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        curr_action_r = []
                        curr_action_l = []
                        global  actions

                        ## Selects the actions of the objects selected
                        for a in actions:
                            if a.obj == self.objToControll and a.bone == self.boneToControll:
                                curr_action_r.append(a)
                            if a.obj == self.objToControll_l and a.bone == self.boneToControll_l:
                                curr_action_l.append(a)

                        ## Removes the last action inserted
                        if len(curr_action_r)>0:
                            actions.remove(curr_action_r.pop())
                        if len(curr_action_l)>0:
                            actions.remove(curr_action_l.pop())

                        # Destroy Action representation in the timeline
                        drawAction(self.objToControll, self.boneToControll, False, True)
                        drawAction(self.objToControll_l, self.boneToControll_l, False, False)

                        ## Clear animation data of the objects to calculate new curve interpolation
                        deleteAction(self.objToControll, self.boneToControll)
                        deleteAction(self.objToControll_l, self.boneToControll_l)

                        ## Re-inserts frames of the remaining actions
                        for act in curr_action_r:
                            insertFrame(act.frames)
                        for act in curr_action_l:
                            insertFrame(act.frames)

                        print ("DEBUG [DELETE] - #actions:", len(actions))
                        ## Re-draws remaining actions
                        drawAction(self.objToControll, self.boneToControll, True, True)
                        drawAction(self.objToControll_l, self.boneToControll_l, True, False)

                        self.state = State.IDLE

                if self.state == State.PLAY_ANIMATION:
                    print ("PLAYING ANIMATION")
                    global playingAnimation
                    if not playingAnimation:
                        if bpy.data.objects['SettingsPanel'].hide:
                            global mode
                            if mode == "ACTION":
                                self.state = State.IDLE
                            if mode == "TUNNING_PERF":
                                self.state = State.IDLE_TUNING_PERF

                        else:
                            self.state = State.SETTING
                    else:
                        if ctrl_state.ulButtonPressed == 4294967296:
                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                            if y < 0:
                                self.state = State.STOP_ANIMATION

                if self.state == State.STOP_ANIMATION:
                    print ("STOP STATE")
                    if ctrl_state.ulButtonPressed != 4294967296:
                        global playingAnimation
                        playingAnimation = False
                        playerSound().start()
                        self.state = State.PLAY_ANIMATION
                        print ("STOP -> PLAY ANIMATION")

                if self.state == State.NAVIGATION_ENTER:
                    tui.hide = True
                    pointer.hide = True
                    bpy.data.objects["Text.R"].data.body = "Navigation\n "
                    bpy.data.objects["Text.L"].data.body = "Navigation\n "
                    if ctrl_state.ulButtonPressed != 2:
                        bpy.data.textures['Texture.R'].image = bpy.data.images['Nav-R.png']
                        bpy.data.textures['Texture.L'].image = bpy.data.images['Nav-L.png']
                        self.state = State.NAVIGATION
                        self.state_l = StateLeft.NAVIGATION

                if self.state == State.NAVIGATION_EXIT:
                    if ctrl_state.ulButtonPressed != 2:
                        print("NAVIGATION -> IDLE")
                        if not bpy.data.objects['SettingsPanel'].hide:
                            bpy.data.textures['Texture.R'].image = bpy.data.images['Sett-R.png']
                            bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll
                            bpy.data.objects["Text.L"].data.body = "Idle\n" + self.objToControll_l + "-" + self.boneToControll_l

                            self.state = State.SETTING
                            self.state_l = StateLeft.SETTING
                        else:
                            global mode # 'ACTION', 'KEYFRAME', 'CURVE', 'TUNING', 'EDIT_ACTION'
                            if mode == "ACTION":
                                print("NAVIGATION -> IDLE")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']
                                self.state = State.IDLE
                                self.state_l = StateLeft.IDLE

                            if mode == "KEYFRAME":
                                print ("NAVIGATION  -> IDLE (KEY MODE)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['Key-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']
                                self.state = State.IDLE_KEYMODE
                                self.state_l = StateLeft.IDLE_KEYMODE

                            if mode == "CURVE_PERF":
                                print ("NAVIGATION -> IDLE (CURVE MODE PERF)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['PathPerf-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']
                                self.state = State.IDLE_CURVEMODE_PERF
                                self.state_l = StateLeft.IDLE_CURVEMODE

                            if mode == "CURVE_KEY":
                                print ("NAVIGATION -> IDLE (CURVE MODE KEY)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['PathKey-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']
                                self.state = State.IDLE_CURVEMODE_KEY
                                self.state_l = StateLeft.IDLE_CURVEMODE

                            if mode == "TUNNING_PERF":
                                print ("NAVIGATION -> IDLE (TUNING MODE PERF)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']
                                self.state = State.IDLE_TUNING_PERF
                                self.state_l = StateLeft.IDLE_TUNING

                            if mode == "TUNNING_KEY":
                                print ("NAVIGATION -> IDLE (TUNING MODE PERF)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['Key-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']
                                self.state = State.IDLE_TUNING_KEY
                                self.state_l = StateLeft.IDLE_TUNING

                            if mode == "EDIT_ACTION":
                                print ("NAVIGATION -> IDLE (EDIT_ACTION MODE)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['EditAct.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['EditAct.png']
                                self.state = State.IDLE_EDIT_ACTION
                                self.state_l = StateLeft.IDLE_EDIT_ACTION

                            if mode == "FCURVE":
                                print ("NAVIGATION -> IDLE (FCURVE MODE)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['Hand-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Hand-L.png']
                                self.state = State.IDLE_F_CURVEMODE
                                self.state_l = StateLeft.IDLE_F_CURVEMODE

                            if mode == "RIGGING":
                                print ("NAVIGATION -> IDLE (RIGGING)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['RiggingR.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['RiggingL.png']
                                self.state = State.IDLE_RIGGING
                                self.state_l = StateLeft.IDLE_RIGGING

                            if mode == "SKINNING":
                                print ("NAVIGATION -> IDLE (SKINNING)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['SkinningR.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Hand-L.png']
                                self.state = State.IDLE_SKINNING
                                self.state_l = StateLeft.IDLE_SKINNING

                            if mode == "CONSTRAINTS":
                                print ("NAVIGATION-> IDLE (IK)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['IK.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Hand-L.png']
                                self.state = State.IDLE_ARM_CONSTR
                                self.state_l = StateLeft.IDLE_ARM_CONSTR

                if self.state == State.NAVIGATION:
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x,y = ctrl_state.rAxis[0].x,ctrl_state.rAxis[0].y
                        if (x > -0.3 and x < 0.3 and y < -0.8):
                            print("ZOOM_OUT")
                            camObjDist = bpy.data.objects["Origin"].location - camera.location
                            if self.objToControll!="":
                                camObjDist = bpy.data.objects[self.objToControll].location - camera.location
                            camera.location -= camObjDist

                            scale_factor = camera.scale[0]
                            scale_factor = scale_factor * 2
                            camera.scale = Vector((scale_factor,scale_factor,scale_factor))
                            bpy.data.objects["Text.R"].scale = Vector((scale_factor,scale_factor,scale_factor))
                            bpy.data.objects["Text.L"].scale = Vector((scale_factor, scale_factor, scale_factor))
                            self.zoom = scale_factor
                            self.state = State.ZOOM_IN

                        if (x > -0.3 and x < 0.3 and y > 0.8):
                            print("ZOOM_IN")
                            camObjDist = bpy.data.objects["Origin"].location - camera.location
                            if self.objToControll!="":
                                camObjDist = bpy.data.objects[self.objToControll].location - camera.location
                            camObjDist = camObjDist/2
                            camera.location += camObjDist

                            scale_factor = camera.scale[0]
                            scale_factor = scale_factor / 2
                            camera.scale = Vector((scale_factor, scale_factor, scale_factor))
                            bpy.data.objects["Text.R"].scale = Vector((scale_factor, scale_factor, scale_factor))
                            bpy.data.objects["Text.L"].scale = Vector((scale_factor, scale_factor, scale_factor))
                            self.zoom = scale_factor
                            self.state = State.ZOOM_OUT

                    ## Teleporting
                    #if (ctrl_state.ulButtonPressed == 8589934592):
                    #    dirMaxIndex, offset = self.computeCameraTranslationOffset()
                    #    camera.location[dirMaxIndex] += offset
                    #    self.state = State.CAMERA_MOVE_STEP

                    if (ctrl_state.ulButtonPressed == 8589934592):
                        print('Orientamento della camera: ', camera.rotation_quaternion)
                        self.diff_rot = ctrl.rotation_quaternion.inverted() * camera.rotation_quaternion
                        print('Diff:                      ', self.diff_rot)
                        #self.diff_loc = camera.location - ctrl.location
                        self.diff_trans_matrix = bpy.data.objects['Camera'].matrix_world * bpy.data.objects['Origin'].matrix_world

                        self.rotFlag = False
                        self.state = State.CAMERA_ROT_CONT

                    if(ctrl_state.ulButtonPressed == 4):
                        self.diff_loc = copy.deepcopy(ctrl.location)
                        self.state = State.CAMERA_MOVE_CONT

                    if (ctrl_state.ulButtonPressed == 2 ):
                        self.state = State.NAVIGATION_EXIT

                if (self.state == State.ZOOM_IN):
                    if(ctrl_state.ulButtonPressed!=4294967296):
                        self.state = State.NAVIGATION

                if (self.state == State.ZOOM_OUT):
                    if (ctrl_state.ulButtonPressed != 4294967296):
                        self.state = State.NAVIGATION

                if (self.state == State.CAMERA_MOVE_CONT):
                    camera.location = camera.location + (self.diff_loc - ctrl.location)

                    if (ctrl_state.ulButtonPressed != 4):
                        self.state = State.NAVIGATION

                if (self.state == State.CAMERA_ROT_CONT):

                    if (ctrl_state.ulButtonPressed != 8589934592):
                        self.rotFlag = True
                        self.state = State.NAVIGATION

                if self.state == State.SETTING:
                    if ctrl_state.ulButtonPressed == 8589934592:
                        self.state = State.ON_BUTTON_PRESSED

                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                    # Gripper
                    if (ctrl_state.ulButtonPressed == 4):
                        string = bpy.types.Scene.controller_map['GRIPPER.R_Down']
                        print("exec Gripper.R OnKeyDown:", string)
                        exec (string)
                        self.state = State.CUSTOM_CONTROL_GRIPPER_RELEASED

                    # Trackpad
                    if ctrl_state.ulButtonPressed == 4294967296:
                        self.state = State.CUSTOM_CONTROL_TRACKPAD_RELEASED

                if self.state == State.CUSTOM_CONTROL_GRIPPER_RELEASED:
                    string = bpy.types.Scene.controller_map['GRIPPER.R_Press']
                    print("exec Gripper.R OnKeyPress:", string)
                    exec (string)
                    if (ctrl_state.ulButtonPressed != 4):
                        string = bpy.types.Scene.controller_map['GRIPPER.R_Up']
                        print("exec Gripper.R OnKeyUp", string)
                        exec(string)
                        self.state = State.SETTING

                if self.state == State.CUSTOM_CONTROL_TRACKPAD_RELEASED:
                    print("DEBUG -  [CUSTOM_CONTROL_TRACKPAD_RELEASED] - 1")
                    x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                    if x > 0 and y > 0:
                        self.updateControl_controller(True, "TRACKPAD_UR.R_Press")
                    if x < 0 and y > 0:
                        self.updateControl_controller(False, "TRACKPAD_UL.R_Press")
                    if x > 0 and y < 0:
                        self.updateControl_controller(True, "TRACKPAD_BR.R_Press")
                    if x < 0 and y < 0:
                        self.updateControl_controller(False, "TRACKPAD_BL.R_Press")

                    print("DEBUG -  [CUSTOM_CONTROL_TRACKPAD_RELEASED] - 2")

                    if ctrl_state.ulButtonPressed != 4294967296:
                        print("DEBUG -  [CUSTOM_CONTROL_TRACKPAD_RELEASED] - 3")
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                        if x > 0 and y > 0:
                            self.updateControl_controller(True, "TRACKPAD_UR.R_Up")
                        if x < 0 and y > 0:
                            self.updateControl_controller(False, "TRACKPAD_UL.R_Up")
                        if x > 0 and y < 0:
                            self.updateControl_controller(True, "TRACKPAD_BR.R_Up")
                        if x < 0 and y < 0:
                            self.updateControl_controller(False, "TRACKPAD_BL.R_Up")
                        print("DEBUG -  [CUSTOM_CONTROL_TRACKPAD_RELEASED] - 4")
                        self.state = State.SETTING

                if self.state == State.MOVE_TIMELINE_CURSOR_ENTER:
                    self.offsetTimeSlider = ctrl.location[0] - timeSlider.location[0]
                    self.state = State.MOVE_TIMELINE_CURSOR

                if self.state == State.MOVE_TIMELINE_CURSOR:
                    if (ctrl.location[0] - self.offsetTimeSlider) >= 0 and (ctrl.location[0] - self.offsetTimeSlider) <= (bpy.data.scenes[0].frame_end / 100):
                        timeSlider.location[0] = ctrl.location[0] - self.offsetTimeSlider
                        bpy.context.scene.frame_current = bpy.data.objects['TimelineSlider'].location[0] * 100
                        bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                    if ctrl_state.ulButtonPressed != 8589934592:
                        self.state = State.SETTING

                if self.state == State.ON_BUTTON_PRESSED:
                    button = self.getButtonPressed(True)
                    if not "Button" in button:
                        self.state = State.MOVE_TIMELINE_CURSOR_ENTER

                    else:
                        if ctrl_state.ulButtonPressed != 8589934592:
                            print ("Button pressed")
                            button = self.getButtonPressed(True)
                            print (button)

                            # Play button
                            if button == 'Button.000':
                                global playingAnimation
                                if not playingAnimation:
                                    playingAnimation = True
                                    playerSound().start()
                                    animator(self.AppMode).start()
                                    bpy.data.textures['Texture.Button(Play)'].image = bpy.data.images['Button(Play)_ON.png']
                                    self.state = State.PLAY_ANIMATION

                            if button == 'Button.015':
                                bpy.ops.ed.undo()
                                print ("UNDO")

                            if button == 'Button.016':
                                bpy.ops.ed.redo()
                                print ("REDO")

                            # Rec/Play speed Button-
                            if button == 'Button.001':
                                global speedPlayRec
                                speedPlayRec = speedPlayRec/2
                                bpy.data.objects["TextBox.001"].data.body = "Record/Playback speed: " + str(speedPlayRec)
                                print ("Current Speed:",speedPlayRec )

                            # Rec/Play speed Button+
                            if button == 'Button.002':
                                global speedPlayRec
                                speedPlayRec = speedPlayRec*2
                                bpy.data.objects["TextBox.001"].data.body = "Record/Playback speed: " + str(speedPlayRec)
                                print ("Current Speed:", speedPlayRec)

                            # LOC Button
                            if button == 'Button.005':
                                global prop_ON
                                if prop_ON:
                                    prop_ON = False
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop).png']

                                global  recordMode
                                recordMode[0] = not recordMode[0]

                                recordModeString = ""
                                if recordMode[0]:
                                    recordModeString += "LOC"
                                    bpy.data.textures['TextureButton(Loc)'].image = bpy.data.images['Button(Loc)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Loc)'].image = bpy.data.images['Button(Loc).png']
                                if recordMode[1]:
                                    recordModeString += " ROT"
                                if recordMode[2]:
                                    recordModeString += " SCALE"
                                    #bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordModeString

                            # ROT Button
                            if button == 'Button.006':
                                global prop_ON
                                if prop_ON:
                                    prop_ON = False
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop).png']

                                global recordMode
                                recordMode[1] = not recordMode[1]

                                recordModeString = ""
                                if recordMode[0]:
                                    recordModeString += "LOC"
                                if recordMode[1]:
                                    recordModeString += " ROT"
                                    bpy.data.textures['TextureButton(Rot)'].image = bpy.data.images['Button(Rot)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Rot)'].image = bpy.data.images['Button(Rot).png']
                                if recordMode[2]:
                                    recordModeString += " SCALE"

                                    #bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordModeString

                                    '''
                                    global recordMode
                                    recordMode = "ROT"
                                    bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordMode
                                    '''

                            # SCALE button
                            if button == 'Button.007':
                                global prop_ON
                                if prop_ON:
                                    prop_ON = False
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop).png']

                                global recordMode
                                recordMode[2] = not recordMode[2]

                                recordModeString = ""
                                if recordMode[0]:
                                    recordModeString += "LOC"
                                if recordMode[1]:
                                    recordModeString += " ROT"
                                if recordMode[2]:
                                    recordModeString += " SCALE"
                                    bpy.data.textures['TextureButton(Scale)'].image = bpy.data.images['Button(Scale)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Scale)'].image = bpy.data.images['Button(Scale).png']

                                #bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordModeString
                                '''
                                global recordMode
                                recordMode = "LOC/ROT"
                                bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordMode
                                '''

                            # Sampling Rate Button-
                            if button == 'Button.008':
                                global samplingRate
                                if samplingRate > 1:
                                    samplingRate -= 1
                                bpy.data.objects["TextBox.004"].data.body = "Sampling Rate: " + str(samplingRate) + " fps"

                            #Sampling Rate Button+
                            if button == 'Button.009':
                                global samplingRate
                                if samplingRate <24:
                                    samplingRate += 1
                                bpy.data.objects["TextBox.004"].data.body = "Sampling Rate: " + str(samplingRate) + " fps"

                            #Performance
                            if button == "Button.010":
                                global perf_mode_ON
                                perf_mode_ON = True
                                global mode
                                mode = "ACTION"
                                self.updateButtonStatus(mode)
                                '''
                                bpy.data.textures['Texture-Perform-Button'].image = bpy.data.images['Button(Action)_ON.png']
                                bpy.data.textures['Texture-Keyframe-Button'].image = bpy.data.images['Button(Keyframe).png']
                                bpy.data.textures['Texture-F-curve-Button'].image = bpy.data.images['Button(FCurve).png']
                                bpy.data.textures['Texture-EditAction-Button'].image = bpy.data.images['Button(Edit-action).png']
                                bpy.data.textures['Texture-Rigging-Button'].image = bpy.data.images['Button(Rigging).png']
                                bpy.data.textures['Texture-Skinning-Button'].image = bpy.data.images['Button(Skinning).png']
                                '''

                            # Keyframe
                            if button == "Button.011":
                                global perf_mode_ON
                                perf_mode_ON = False
                                global mode
                                mode = "KEYFRAME"
                                self.updateButtonStatus(mode)
                                '''
                                bpy.data.textures['Texture-Perform-Button'].image = bpy.data.images['Button(Action).png']
                                bpy.data.textures['Texture-Keyframe-Button'].image = bpy.data.images['Button(Keyframe)_ON.png']
                                bpy.data.textures['Texture-F-curve-Button'].image = bpy.data.images['Button(FCurve).png']
                                bpy.data.textures['Texture-EditAction-Button'].image = bpy.data.images['Button(Edit-action).png']
                                bpy.data.textures['Texture-Rigging-Button'].image = bpy.data.images['Button(Rigging).png']
                                bpy.data.textures['Texture-Skinning-Button'].image = bpy.data.images['Button(Skinning).png']
                                '''

                            # Path
                            if button == "Button.012":
                                #global mode
                                #mode = "CURVE"
                                global path_ON
                                path_ON = not path_ON
                                if path_ON:
                                    bpy.data.textures['Texture-Path-Button'].image = bpy.data.images['Button(Path)_ON.png']

                                else:
                                    bpy.data.textures['Texture-Path-Button'].image = bpy.data.images['Button(Path).png']
                                global perf_mode_ON
                                global mode
                                if perf_mode_ON:
                                    mode = "ACTION"
                                else:
                                    mode = "KEYFRAME"

                            # Properties
                            if button == 'Button.003':
                                # global mode
                                # mode = "TUNING"
                                global prop_ON
                                prop_ON = not prop_ON

                                if prop_ON:
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop)_ON.png']
                                    global recordMode
                                    recordMode = [False, False, False]
                                    bpy.data.textures['TextureButton(Loc)'].image = bpy.data.images['Button(Loc).png']
                                    bpy.data.textures['TextureButton(Rot)'].image = bpy.data.images['Button(Rot).png']
                                    bpy.data.textures['TextureButton(Scale)'].image = bpy.data.images['Button(Scale).png']
                                else:
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop).png']

                                global perf_mode_ON
                                global mode
                                if perf_mode_ON:
                                    mode = "ACTION"
                                else:
                                    mode = "KEYFRAME"

                            # Local Representation
                            if button == "Button.013":
                                global local_repr_ON
                                local_repr_ON = not local_repr_ON
                                self.create_local_repr(local_repr_ON)
                                if local_repr_ON:
                                    bpy.data.textures['TextureButton(LocalRepr)'].image = bpy.data.images['Button(LocalRep)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(LocalRepr)'].image = bpy.data.images['Button(LocalRep).png']

                            # F-Curve
                            if button == "Button.014":
                                global mode
                                mode = "FCURVE"
                                self.updateButtonStatus(mode)
                                '''
                                bpy.data.textures['Texture-Perform-Button'].image = bpy.data.images['Button(Action).png']
                                bpy.data.textures['Texture-Keyframe-Button'].image = bpy.data.images['Button(Keyframe).png']
                                bpy.data.textures['Texture-F-curve-Button'].image = bpy.data.images['Button(FCurve)_ON.png']
                                bpy.data.textures['Texture-EditAction-Button'].image = bpy.data.images['Button(Edit-action).png']
                                bpy.data.textures['Texture-Rigging-Button'].image = bpy.data.images['Button(Rigging).png']
                                bpy.data.textures['Texture-Skinning-Button'].image = bpy.data.images['Button(Skinning).png']
                                '''

                            # Edit action
                            if button == 'Button.004':
                                global mode
                                mode = "EDIT_ACTION"
                                self.updateButtonStatus(mode)
                                '''
                                bpy.data.textures['Texture-Perform-Button'].image = bpy.data.images['Button(Action).png']
                                bpy.data.textures['Texture-Keyframe-Button'].image = bpy.data.images['Button(Keyframe).png']
                                bpy.data.textures['Texture-F-curve-Button'].image = bpy.data.images['Button(FCurve).png']
                                bpy.data.textures['Texture-EditAction-Button'].image = bpy.data.images['Button(Edit-action)_ON.png']
                                bpy.data.textures['Texture-Rigging-Button'].image = bpy.data.images['Button(Rigging).png']
                                bpy.data.textures['Texture-Skinning-Button'].image = bpy.data.images['Button(Skinning).png']
                                '''

                            #Rigginig
                            if button == 'Button.018':
                                print("Rigging")
                                global mode
                                mode = "RIGGING"
                                self.updateButtonStatus(mode)
                                '''
                                bpy.data.textures['Texture-Perform-Button'].image = bpy.data.images['Button(Action).png']
                                bpy.data.textures['Texture-Keyframe-Button'].image = bpy.data.images['Button(Keyframe).png']
                                bpy.data.textures['Texture-F-curve-Button'].image = bpy.data.images['Button(FCurve).png']
                                bpy.data.textures['Texture-EditAction-Button'].image = bpy.data.images['Button(Edit-action).png']
                                bpy.data.textures['Texture-Rigging-Button'].image = bpy.data.images['Button(Rigging)_ON.png']
                                bpy.data.textures['Texture-Skinning-Button'].image = bpy.data.images['Button(Skinning).png']
                                '''

                            #Skinning
                            if button == 'Button.017':
                                print("Skinning")
                                global mode
                                mode = "SKINNING"
                                self.updateButtonStatus(mode)
                                '''
                                bpy.data.textures['Texture-Perform-Button'].image = bpy.data.images['Button(Action).png']
                                bpy.data.textures['Texture-Keyframe-Button'].image = bpy.data.images['Button(Keyframe).png']
                                bpy.data.textures['Texture-F-curve-Button'].image = bpy.data.images['Button(FCurve).png']
                                bpy.data.textures['Texture-EditAction-Button'].image = bpy.data.images['Button(Edit-action).png']
                                bpy.data.textures['Texture-Rigging-Button'].image = bpy.data.images['Button(Rigging).png']
                                bpy.data.textures['Texture-Skinning-Button'].image = bpy.data.images['Button(Skinning)_ON.png']
                                '''

                            # Constraints
                            if button == 'Button.019':
                                print('Constraints')
                                global mode
                                mode = "CONSTRAINTS"
                                self.updateButtonStatus(mode)

                            # X Button
                            if button == 'Button.020':
                                self.mirror_axes[0] = not self.mirror_axes[0]
                                if self.mirror_axes[0]:
                                    bpy.data.textures['TextureButton(X)'].image = bpy.data.images['Button(X)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(X)'].image = bpy.data.images['Button(X).png']

                            # Y Button
                            if button == 'Button.021':
                                self.mirror_axes[1] = not self.mirror_axes[1]
                                if self.mirror_axes[1]:
                                    bpy.data.textures['TextureButton(Y)'].image = bpy.data.images['Button(Y)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Y)'].image = bpy.data.images['Button(Y).png']

                            # Z Button
                            if button == 'Button.022':
                                self.mirror_axes[2] = not self.mirror_axes[2]

                                if self.mirror_axes[2]:
                                    bpy.data.textures['TextureButton(Z)'].image = bpy.data.images['Button(Z)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Z)'].image = bpy.data.images['Button(Z).png']

                            # Bone/Armature selection
                            if button == 'Button.023':
                                self.arm_selection = not self.arm_selection

                                if self.arm_selection:
                                    bpy.data.textures['Texture-ArmSel-Button'].image = bpy.data.images['Button(ArmSel)_ON.png']
                                else:
                                    bpy.data.textures['Texture-ArmSel-Button'].image = bpy.data.images['Button(ArmSel).png']

                            # Custom button
                            if 'Button.ApplyFunc' in button:
                                # TODO: check for keyword
                                string = bpy.types.Scene.gui_map[button]
                                print(string)
                                exec(string)

                            # Custom button
                            if 'Button.IncreaseValue' in button:
                                self.updateControl_gui(True, button)

                            if 'Button.DecreaseValue' in button:
                                self.updateControl_gui(False, button)

                            self.state = State.SETTING

                if self.state == State.IDLE_EDIT_ACTION:
                    # Set text for the controller feedback
                    if self.action_r_index!=-1 and not actions is None:
                        bpy.data.objects["Text.R"].data.body = "Idle\n" + actions[self.action_r_index].name
                    else:
                        bpy.data.objects["Text.R"].data.body = "Idle\n"


                    # DECISIONAL
                    if (ctrl_state.ulButtonPressed == 4):
                        print("IDLE (EDIT_ACTION) -> DECISIONAL")
                        self.state = State.DECISIONAL_EDIT_ACTION

                    # MULTIPLY/DIVIDE/MOVE actions
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y

                        if (x < 0 and y < 0):
                            print("Action x 2")
                            self.state = State.MULTIPLY_ACTION

                        if (x > 0 and y < 0):
                            print("Action / 2")
                            self.state = State.DIVIDE_ACTION

                        if (x < 0 and y > 0):
                            print ("MOVE LEFT")
                            self.state = State.MOVE_LEFT

                        if (x > 0 and y > 0):
                            print ("MOVE RIGHT")
                            self.state = State.MOVE_RIGHT

                    # SETTING
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                if self.state == State.DECISIONAL_EDIT_ACTION:
                    # Compute the nearest action
                    self.action_r_index = self.getClosestAction(True)

                    if ctrl_state.ulButtonPressed != 4:
                        print ("DEBUG [DECISIONAL_EDIT_ACTION] - index:", self.action_r_index)
                        self.state = State.IDLE_EDIT_ACTION
                        print ("DECISIONAL -> IDLE (EDIT_ACTION_MODE)")

                if self.state == State.MULTIPLY_ACTION:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        print ("DEBUG [MULTIPLY_ACTION] - action x2")
                        if self.action_r_index !=-1:
                            recursive_delete_children()
                            self.multiplyKeyframe(2, True)

                        '''
                        global mode
                        if mode == "KEYFRAME":
                            updateKeyframeVisualization()
                        '''
                        self.state = State.IDLE_EDIT_ACTION

                if self.state == State.DIVIDE_ACTION:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        print ("[DEBUG] - DIVIDE_ACTION /2")
                        if self.action_r_index !=-1:
                            recursive_delete_children()
                            self.multiplyKeyframe(0.5, True)

                        '''
                        if mode == "KEYFRAME":
                            updateKeyframeVisualization()                        
                        '''
                        self.state = State.IDLE_EDIT_ACTION

                if self.state == State.MOVE_RIGHT:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        print ("DEBUG [MOVE_RIGHT] - move right")
                        if self.action_r_index !=-1:
                            recursive_delete_children()
                            self.moveAction(24, True)

                        '''    
                        global mode
                        if mode == "KEYFRAME":
                            updateKeyframeVisualization()
                        '''
                        self.state = State.IDLE_EDIT_ACTION

                if self.state == State.MOVE_LEFT:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        print ("DEBUG [MOVE_LEFT] - move left")
                        if self.action_r_index != -1:
                            recursive_delete_children()
                            self.moveAction(-24, True)

                        '''
                        global mode
                        if mode == "KEYFRAME":
                            updateKeyframeVisualization()
                        '''
                        self.state = State.IDLE_EDIT_ACTION

                if self.state == State.NEXT_FRAME:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        global curr_frames_r
                        global curr_frames_l
                        frameDist = bpy.data.scenes[0].frame_end
                        nextFrame = bpy.data.scenes[0].frame_end

                        for f in curr_frames_r:
                            dist = f.frame - bpy.context.scene.frame_current
                            if 0 < dist < frameDist:
                                frameDist = dist
                                nextFrame = f.frame

                        for f in curr_frames_l:
                            dist = f.frame - bpy.context.scene.frame_current
                            if 0 < dist < frameDist:
                                frameDist = dist
                                nextFrame = f.frame

                        bpy.context.scene.frame_current = nextFrame
                        timeSlider.location[0] = bpy.context.scene.frame_current / 100
                        bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        global prop_ON
                        if prop_ON:
                            self.state = State.IDLE_TUNING_KEY
                        else:
                            self.state = State.IDLE_KEYMODE

                if self.state == State.PREV_FRAME:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        global curr_frames_r
                        global curr_frames_l
                        frameDist = bpy.data.scenes[0].frame_end
                        nextFrame = bpy.data.scenes[0].frame_start

                        for f in curr_frames_r:
                            dist = bpy.context.scene.frame_current - f.frame
                            if 0 < dist < frameDist:
                                frameDist = dist
                                nextFrame = f.frame

                        for f in curr_frames_l:
                            dist = bpy.context.scene.frame_current - f.frame
                            if 0 < dist < frameDist:
                                frameDist = dist
                                nextFrame = f.frame

                                # bpy.data.scenes[0].frame_start
                                # bpy.data.scenes[0].frame_end

                        bpy.context.scene.frame_current = nextFrame
                        timeSlider.location[0] = bpy.context.scene.frame_current / 100
                        bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        global prop_ON
                        if prop_ON:
                            self.state = State.IDLE_TUNING_KEY
                        else:
                            self.state = State.IDLE_KEYMODE

                if self.state == State.IDLE_KEYMODE:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll

                    tui.hide = True

                    # DECISIONAL
                    if (ctrl_state.ulButtonPressed == 4):
                        print("IDLE (KEYFRAME MODE) -> DECISIONAL")
                        print ("DECISIONAL ENTER: ", self.objToControll, self.boneToControll)
                        self.changeSelection(self.objToControll, self.boneToControll, False)
                        bpy.data.objects["Action_Text.R"].hide = True
                        self.state = State.DECISIONAL

                    # INTERACTION_LOCAL
                    if (ctrl_state.ulButtonPressed == 8589934592 and self.objToControll != ""):
                        print("IDLE (KEYFRAME MODE) -> INTERACTION LOCAL")
                        self.state = State.INTERACTION_LOCAL
                        self.curr_axes_r = 0

                        if self.boneToControll != "":
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * \
                                            bpy.data.objects[self.objToControll].pose.bones[
                                                self.boneToControll].matrix.to_quaternion()
                            self.diff_loc = bpy.data.objects[self.objToControll].pose.bones[
                                                self.boneToControll].matrix.to_translation() - ctrl.location

                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].location)
                            bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'QUATERNION'

                        else:
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[
                                self.objToControll].rotation_quaternion
                            self.diff_loc = bpy.data.objects[self.objToControll].location - ctrl.location
                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].location)
                            bpy.data.objects[self.objToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].rotation_mode = 'QUATERNION'

                    # FIRST/LAST/INSERT/DELETE FRAME
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                        if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                            print("LAST")
                            self.state = State.NEXT_FRAME
                            #bpy.context.scene.frame_current = bpy.data.scenes[0].frame_end
                            #timeSlider.location[0] = bpy.context.scene.frame_current/100

                        if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                            print("FIRST")
                            self.state = State.PREV_FRAME
                            #bpy.context.scene.frame_current = bpy.data.scenes[0].frame_start
                            #timeSlider.location[0] = bpy.context.scene.frame_current/100

                        if (x > 0 and y > 0):
                            print("Insert KEYFRAME")
                            self.state = State.INSERT_KEYFRAME

                        if (x < 0 and y > 0):
                            print("Delete KEYFRAME")
                            self.state = State.DELETE_KEYFRAME

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                if self.state == State.INSERT_KEYFRAME:
                    if ctrl_state.ulButtonPressed != 4294967296:

                        if self.objToControll!="":
                            if self.boneToControll != "":
                                loc = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].location)
                                rot = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_quaternion)
                                scale = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale)
                            else:
                                loc = copy.deepcopy(bpy.data.objects[self.objToControll].location)
                                rot = copy.deepcopy(bpy.data.objects[self.objToControll].rotation_quaternion)
                                scale = copy.deepcopy(bpy.data.objects[self.objToControll].scale)

                            #print ("DEBUG [INSERT_KEYFRAME] - LOC ROT taken")
                            global recordMode
                            f = Keyframe(bpy.context.scene.frame_current, rot, loc, scale, self.objToControll, self.boneToControll, recordMode)
                            insertFrame([f])
                            actions[self.action_r_index].frames += [f]

                            if self.arm_selection and self.boneToControll != "":
                                for bone in bpy.data.objects[self.objToControll].pose.bones:
                                    loc = copy.deepcopy(bone.location)
                                    rot = copy.deepcopy(bone.rotation_quaternion)
                                    scale = copy.deepcopy(bone.scale)
                                    f = Keyframe(bpy.context.scene.frame_current, rot, loc, scale, self.objToControll, bone.name, recordMode)
                                    insertFrame([f])
                                    actions[self.action_r_index].frames += [f]

                            #print ("DEBUG [INSERT_KEYFRAME] - Frame Inserted")
                            drawActions_Overview(currObject, currBone)
                            #print ("DEBUG [INSERT_KEYFRAME] - After drawActions_Overview()")
                            updateKeyframeVisualization()
                            #print ("DEBUG [INSERT_KEYFRAME] - After updateKeyframeVisualization()")

                        #print ("DEBUG [INSERT_KEYFRAME] - Obj, Bone: ", self.objToControll, self.boneToControll, self.objToControll_l, self.boneToControll_l)
                        if self.objToControll_l != "":
                            #print ("DEBUG [INSERT_KEYFRAME] - Inside a not desidred case 1")

                            if self.boneToControll_l != "":
                                loc = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].location)
                                rot = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].rotation_quaternion)
                                scale = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].scale)
                            else:
                                loc = copy.deepcopy(bpy.data.objects[self.objToControll_l].location)
                                rot = copy.deepcopy(bpy.data.objects[self.objToControll_l].rotation_quaternion)
                                scale = copy.deepcopy(bpy.data.objects[self.objToControll_l].scale)
                            #print ("DEBUG [INSERT_KEYFRAME] - Inside a not desidred case 2")
                            global recordMode
                            f = Keyframe(bpy.context.scene.frame_current, rot, loc, scale, self.objToControll_l, self.boneToControll_l, recordMode)
                            insertFrame([f])
                            actions[self.action_l_index].frames += [f]
                            #print ("DEBUG [INSERT_KEYFRAME] - Inside a not desidred case 3")
                            if self.arm_selection and self.boneToControll_l != "":
                                for bone in bpy.data.objects[self.objToControll_l].pose.bones:
                                    loc = copy.deepcopy(bone.location)
                                    rot = copy.deepcopy(bone.rotation_quaternion)
                                    scale = copy.deepcopy(bone.scale)
                                    f = Keyframe(bpy.context.scene.frame_current, rot, loc, scale, self.objToControll_l, bone.name, recordMode)
                                    insertFrame([f])
                                    actions[self.action_l_index].frames += [f]
                            #print ("DEBUG [INSERT_KEYFRAME] - Inside a not desidred case 4")
                            drawActions_Overview(currObject_l, currBone_l)
                            #print ("DEBUG [INSERT_KEYFRAME] - Inside a not desidred case 5")
                            updateKeyframeVisualization()
                            #print ("DEBUG [INSERT_KEYFRAME] - Inside a not desidred case 6")
                        #print("DEBUG [INSERT_KEYFRAME] - {FINISHED}")
                        self.state = State.IDLE_KEYMODE

                if self.state == State.DELETE_KEYFRAME:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        if self.objToControll !="":
                            removeKeyFrame(bpy.context.scene.frame_current, self.objToControll, self.boneToControll)
                            print("DEBUG [DELETE_KEYFRAME] - 1")
                            drawActions_Overview(currObject, currBone)
                            print("DEBUG [DELETE_KEYFRAME] - 2")
                            updateKeyframeVisualization()
                            print("DEBUG [DELETE_KEYFRAME] - 3")

                            print ("DEBUG [DELETE_KEYFRAME] - Actions")
                            for a in actions:
                                print (a.name)
                                for f in a.frames:
                                    print(f.frame)

                        if self.objToControll_l!="":
                            removeKeyFrame(bpy.context.scene.frame_current, self.objToControll_l, self.boneToControll_l)
                            drawActions_Overview(currObject_l, currBone_l)
                            updateKeyframeVisualization()

                        self.state = State.IDLE_KEYMODE

                if self.state == State.SCALING:
                    currDist = self.computeTargetObjDistance("TUI.L", "", True)
                    offset = (currDist - self.diff_distance)/10
                    if self.boneToControll!="":
                        bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale = self.initial_scale
                        bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale[0] += offset
                        bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale[1] += offset
                        bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale[2] += offset

                        global local_repr_ON
                        if local_repr_ON and '_Local.Repr' in self.objToControll:
                            # Copy scale to the target bone
                            pboneTarget = bpy.data.objects[self.objToControll.split('_Local.Repr')[0]].pose.bones[self.boneToControll]
                            pboneTarget.scale = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale

                    else:
                        bpy.data.objects[self.objToControll].scale = self.initial_scale
                        bpy.data.objects[self.objToControll].scale[0] += offset
                        bpy.data.objects[self.objToControll].scale[1] += offset
                        bpy.data.objects[self.objToControll].scale[2] += offset

                        global local_repr_ON
                        if local_repr_ON and '_Local.Repr' in self.objToControll:
                            objTarget = bpy.data.objects[self.objToControll.split('_Local.Repr')[0]]
                            objTarget.scale = bpy.data.objects[self.objToControll].scale


                    #Exit from Scaling state
                    if (ctrl_state.ulButtonPressed != 8589934592):
                        if (ctrl_state_l.ulButtonPressed != 8589934592):
                            global mode
                            if mode == "ACTION":
                                self.state = State.IDLE
                                self.state_l = StateLeft.IDLE
                                print ("SCALING -> IDLE")
                            if mode == "KEYFRAME":
                                self.state = State.IDLE_KEYMODE
                                self.state_l = StateLeft.IDLE_KEYMODE
                                print ("SCALING -> IDLE (KEY MODE)")

                if self.state == State.IDLE_CURVEMODE_PERF:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll
                    tui.hide = True

                    # DECISIONAL
                    if ctrl_state.ulButtonPressed == 4:
                        print("IDLE (CURVE MODE) -> DECISIONAL")
                        global pointIndex_r
                        if self.objToControll + self.boneToControll + "_PATH_OBJ" in bpy.data.objects and pointIndex_r != -1:
                            bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].data.splines.active.points[pointIndex_r].select = False
                        self.state = State.DECISIONAL_CURVEMODE

                    # INTERACTION_LOCAL
                    if ctrl_state.ulButtonPressed == 8589934592 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                        ## Point grabbing
                        global pointIndex_r
                        if pointIndex_r !=-1:
                            objCurve = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]
                            self.offesetCurvePoint_r[0] = objCurve.data.splines.active.points[pointIndex_r].co[0] - tui.location[0]
                            self.offesetCurvePoint_r[1] = objCurve.data.splines.active.points[pointIndex_r].co[1] - tui.location[1]
                            self.offesetCurvePoint_r[2] = objCurve.data.splines.active.points[pointIndex_r].co[2] - tui.location[2]
                            print ("DEBUG [IDLE_CURVEMODE] - offesetCurvePoint_r:", self.offesetCurvePoint_r)
                            self.state = State.INTERACTION_CURVEMODE
                            print("IDLE_CURVEMODE -> INTERACTION_CURVEMODE")

                    # NEXT_EVAL_TIME/PREV_EVAL_TIME/CREATE_PATH/ADD_POINT_CURVE
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y

                        if (y < 0 and self.objToControll != ""):
                            if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                                print("ADD POINT TO THE CURVE")
                                self.state = State.ADD_POINT_CURVE
                            else:
                                print("CREATE PATH CURVE")
                                self.state = State.CREATE_CURVE

                        if (x > 0 and y > 0 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves):
                            global recordFlag
                            if not recordFlag:
                                self.state = State.START_RECORD_PROP
                            else:
                                self.state = State.END_RECORD_PROP

                        if (x < 0 and y > 0 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves):
                            print ("DELETE ACTION")

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                if self.state == State.IDLE_CURVEMODE_KEY:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll
                    tui.hide = True

                    # DECISIONAL
                    if ctrl_state.ulButtonPressed == 4:
                        print("IDLE (CURVE MODE) -> DECISIONAL")
                        global pointIndex_r
                        if self.objToControll + self.boneToControll + "_PATH_OBJ" in bpy.data.objects and pointIndex_r != -1:
                            bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].data.splines.active.points[pointIndex_r].select = False
                        self.state = State.DECISIONAL_CURVEMODE

                    # INTERACTION_LOCAL
                    if ctrl_state.ulButtonPressed == 8589934592 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                        ## Point grabbing
                        global pointIndex_r
                        if pointIndex_r !=-1:
                            objCurve = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]
                            self.offesetCurvePoint_r[0] = objCurve.data.splines.active.points[pointIndex_r].co[0] - tui.location[0]
                            self.offesetCurvePoint_r[1] = objCurve.data.splines.active.points[pointIndex_r].co[1] - tui.location[1]
                            self.offesetCurvePoint_r[2] = objCurve.data.splines.active.points[pointIndex_r].co[2] - tui.location[2]
                            print ("DEBUG [IDLE_CURVEMODE] - offesetCurvePoint_r:", self.offesetCurvePoint_r)
                            self.state = State.INTERACTION_CURVEMODE
                            print("IDLE_CURVEMODE -> INTERACTION_CURVEMODE")

                    # NEXT_EVAL_TIME/PREV_EVAL_TIME/CREATE_PATH/ADD_POINT_CURVE
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y

                        if (y < 0 and self.objToControll != ""):
                            if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                                print("ADD POINT TO THE CURVE")
                                self.state = State.ADD_POINT_CURVE
                            else:
                                print("CREATE PATH CURVE")
                                self.state = State.CREATE_CURVE

                        if (x > 0 and y > 0 and self.objToControll != ""):
                            print("INSERT KEYFRAME")
                            self.state = State.INSERT_EVAL_KEYFRAME

                        if (x < 0 and y > 0):
                            print("DELETE KEYFRAME")
                            self.state = State.DELETE_EVAL_KEYFRAME

                        '''
                        
                        if (x > 0 and y < 0 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves):
                            if bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].eval_time < bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].path_duration:
                                bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].eval_time+=1
                                print("NEXT_EVAL_TIME")

                        if (x < 0 and y < 0 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves):
                            if bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].eval_time > 0:
                                bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].eval_time-=1
                                print("PREV_EVAL_TIME")

                        if (x > 0 and y > 0 and self.objToControll != ""):
                            if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                                print("ADD POINT TO THE CURVE")
                                self.state = State.ADD_POINT_CURVE
                            else:
                                print("CREATE PATH CURVE")
                                self.state = State.CREATE_CURVE

                        if (x < 0 and y > 0 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves):
                            global recordFlag
                            if not recordFlag:
                                self.state = State.START_RECORD_PROP
                            else:
                                self.state = State.END_RECORD_PROP
                        '''

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                if self.state == State.CREATE_CURVE:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        if not self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                            # Create curve object
                            cu = bpy.data.curves.new(self.objToControll + self.boneToControll + "_PATH", "CURVE")
                            ob = bpy.data.objects.new(self.objToControll + self.boneToControll + "_PATH_OBJ", cu)
                            bpy.context.scene.objects.link(ob)
                            #scn = bpy.context.scene
                            #scn.objects.link(ob)
                            #scn.objects.active = ob
                            if self.boneToControll!="":
                                origin = bpy.data.objects[self.objToControll].location + bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].head
                            else:
                                origin = bpy.data.objects[self.objToControll].location

                            # Set curve
                            cu.dimensions = "3D"
                            spline = cu.splines.new('NURBS')
                            points = [(origin[0], origin[1], origin[2], 1),
                                      (origin[0]+1, origin[1], origin[2], 1),
                                      (origin[0]+2, origin[1], origin[2], 1),
                                      (origin[0]+3, origin[1], origin[2], 1)]
                            npoints = len(points)
                            spline.points.add(npoints - 1)
                            for (n, pt) in enumerate(points):
                                spline.points[n].co = pt

                            bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].splines.active.use_endpoint_u = True

                            ## Add constraint to the object
                            object = bpy.data.objects[self.objToControll]
                            pathOb = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]
                            pathOb.layers = object.layers
                            pathOb.rotation_mode = 'QUATERNION'

                            if self.boneToControll!="":
                                bpy.data.objects[self.objToControll].location = (0,0,0)
                                bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].location = (0, 0, 0)
                                #bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_quaternion = (1, 0, 0, 0)
                                cns = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].constraints.new('FOLLOW_PATH')

                            else:
                                object.location = (0, 0, 0)
                                object.rotation_quaternion = (1, 0, 0, 0)
                                cns = object.constraints.new('FOLLOW_PATH')

                            cns.target = pathOb
                            cns.use_curve_follow = False

                            print ("DEBUG [CREATE_CURVE] - Path created")

                            ## Enter in Edit Mode for Curve Handler Editing
                            bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].select = True
                            bpy.context.scene.objects.active = ob
                            bpy.ops.object.mode_set(mode='EDIT')

                        else:
                            bpy.ops.object.mode_set(mode='OBJECT')
                            bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].select = True
                            bpy.context.scene.objects.active = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]
                            bpy.ops.object.mode_set(mode='EDIT')

                        global perf_mode_ON
                        if perf_mode_ON:
                            self.state = State.IDLE_CURVEMODE_PERF
                        else:
                            self.state = State.IDLE_CURVEMODE_KEY

                if self.state == State.ADD_POINT_CURVE:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                            spline = bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].splines.active
                            objCurve = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]
                            # New point coordinates computed as difference of the two last points
                            newPoint = copy.deepcopy(objCurve.data.splines.active.points[-1].co - objCurve.data.splines.active.points[-2].co)
                            spline.points.add(1)
                            spline.points[-1].co = spline.points[-2].co + newPoint
                            print("Point added")

                            global perf_mode_ON
                            if perf_mode_ON:
                                self.state = State.IDLE_CURVEMODE_PERF
                            else:
                                self.state = State.IDLE_CURVEMODE_KEY

                if self.state == State.DECISIONAL_CURVEMODE:
                    bpy.data.objects["Text.R"].data.body = "Selection\n" + self.objToControll + "-" + self.boneToControll
                    # Compute the nearest object
                    global pointIndex_r
                    try:
                        pointIndex_r = self.getClosestPoint(True)
                    except:
                        print("Error during selection")

                    if ctrl_state.ulButtonPressed != 4:
                        # print("touch button released")
                        #Select the new point

                        if pointIndex_r != -1:
                            bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].data.splines.active.points[pointIndex_r].select = True

                        global perf_mode_ON
                        if perf_mode_ON:
                            self.state = State.IDLE_CURVEMODE_PERF
                        else:
                            self.state = State.IDLE_CURVEMODE_KEY

                if self.state == State.INTERACTION_CURVEMODE:
                    print ("INTERACTION")
                    global pointIndex_r
                    objCurve = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]

                    bpy.data.objects["Text.R"].data.body = "Interaction\n" + self.objToControll + "-" + self.boneToControll + "\n" + "points[" + str(pointIndex_r)+ "]"


                    print ("DEBUG [INTERACTION_CURVEMODE] - offesetCurvePoint_r:", self.offesetCurvePoint_r)
                    co = (tui.location[0] + self.offesetCurvePoint_r[0],
                          tui.location[1] + self.offesetCurvePoint_r[1],
                          tui.location[2] + self.offesetCurvePoint_r[2],
                          1)
                    '''
                    co = (tui.location[0] - objCurve.location[0],
                          tui.location[1] - objCurve.location[1],
                          tui.location[2] - objCurve.location[2],
                          1)
                    '''
                    objCurve.data.splines.active.points[pointIndex_r].co = co
                    if (ctrl_state.ulButtonPressed != 8589934592):
                        global perf_mode_ON
                        if perf_mode_ON:
                            self.state = State.IDLE_CURVEMODE_PERF
                        else:
                            self.state = State.IDLE_CURVEMODE_KEY

                if self.state == State.INSERT_EVAL_KEYFRAME:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                            bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].keyframe_insert(data_path='eval_time')
                            prop = Property(bpy.context.scene.frame_current, self.objToControll, self.boneToControll, 'eval_time')
                            i = -1
                            for index, p in enumerate(property_frame):
                                if p.frame == prop.frame and p.obj == prop.obj and p.bone == prop.bone and p.data_path == prop.data_path:
                                    i = index
                                    break
                            if i == -1:
                                property_frame.append(prop)

                            for prop in property_frame:
                                print (prop.frame, prop.data_path)

                            updatePropKeyframeVisualization()

                            global perf_mode_ON
                            if perf_mode_ON:
                                self.state = State.IDLE_CURVEMODE_PERF
                            else:
                                self.state = State.IDLE_CURVEMODE_KEY

                if self.state == State.DELETE_EVAL_KEYFRAME:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                            prop = Property(bpy.context.scene.frame_current, self.objToControll, self.boneToControll, 'eval_time')

                            i = -1
                            for index, p in enumerate(property_frame):
                                if p.frame == prop.frame and p.obj == prop.obj and p.bone == prop.bone and p.data_path == prop.data_path:
                                    i = index
                                    break
                            if i != -1:
                                property_frame.remove(property_frame[i])
                                bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].keyframe_delete(data_path='eval_time')

                        print("DEBUG [DELETE_PROP_KEYFRAME] - property frame content:")
                        for property in property_frame:
                            print (property.frame, property.data_path)
                        print("DEBUG [DELETE_PROP_KEYFRAME] - len property:", len(property_frame))

                        updatePropKeyframeVisualization()
                        global perf_mode_ON
                        if perf_mode_ON:
                            self.state = State.IDLE_CURVEMODE_PERF
                        else:
                            self.state = State.IDLE_CURVEMODE_KEY

                if self.state == State.IDLE_TUNING_PERF:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll

                    # DECISIONAL
                    if (ctrl_state.ulButtonPressed == 4):
                        print("IDLE_TUNING -> DECISIONAL")
                        self.changeSelection(self.objToControll, self.boneToControll, False)
                        drawActionProp(self.objToControll, self.boneToControll, False)
                        self.state = State.DECISIONAL

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                    # INTERACTION
                    if (ctrl_state.ulButtonPressed == 8589934592 and self.objToControll != ""):
                        print("IDLE -> INTERACTION LOCAL")
                        self.state = State.INTERACTION_LOCAL
                        self.curr_axes_r = 0

                        if self.boneToControll != "":
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * \
                                            bpy.data.objects[self.objToControll].pose.bones[
                                                self.boneToControll].matrix.to_quaternion()
                            self.diff_loc = bpy.data.objects[self.objToControll].pose.bones[
                                                self.boneToControll].matrix.to_translation() - ctrl.location
                            self.initial_loc = copy.deepcopy(
                                bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].location)
                            bpy.data.objects[self.objToControll].pose.bones[
                                self.boneToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(
                                bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].pose.bones[
                                self.boneToControll].rotation_mode = 'QUATERNION'

                        else:
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[
                                self.objToControll].rotation_quaternion
                            self.diff_loc = bpy.data.objects[self.objToControll].location - ctrl.location
                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].location)
                            bpy.data.objects[self.objToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].rotation_mode = 'QUATERNION'

                    # TRACKPAD
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                        if y < 0:
                            print("PLAY BUTTON")
                            self.state = State.START_ANIMATION

                        if x > 0 and y > 0:
                            global recordFlag
                            if not recordFlag:
                                self.state = State.START_RECORD_PROP
                            else:
                                self.state = State.END_RECORD_PROP

                        if x < 0 and y > 0:
                            print ("DELETE ACTIONS")
                            # TODO: Delete actions to implement
                            # self.state_l = StateLeft.DELETE

                    '''
                    if 'Material_Diffuse_' in self.properties[self.prop_index]:
                        # Change Hue and Saturation for the Diffuse Color
                        if ctrl_state.ulButtonPressed == 8589934592:
                            self.state = State.MOVE_COLOR_CURSOR_ENTER

                        # Change Value for the Diffuse Color
                        if ctrl_state.ulButtonPressed == 4294967296:
                            slot = int(self.properties[self.prop_index].split('Material_Diffuse_')[1])
                            mat = bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name]

                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                            if (x > 0 and y < 0 and mat.diffuse_color.v < 1):
                                mat.diffuse_color.v += 0.02

                            if (x < 0 and y < 0 and mat.diffuse_color.v  > 0):
                                mat.diffuse_color.v -= 0.02

                            # PLAY/RECORD
                            if(y > 0):
                                global recordFlag
                                if not recordFlag:
                                    self.state = State.START_RECORD_PROP
                                else:
                                    self.state = State.END_RECORD_PROP

                    if 'ShapeKey_' in self.properties[self.prop_index]:
                        # Change value of the Shapekey
                        if ctrl_state.ulButtonPressed == 4294967296:
                            slot = int(self.properties[self.prop_index].split('ShapeKey_')[1])
                            key = bpy.data.objects[self.objToControll].data.shape_keys.key_blocks[slot]

                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                            if (x > 0 and y < 0 and key.value < key.slider_max):
                                key.value += 0.02

                            if (x < 0 and y < 0 and key.value> key.slider_min):
                                key.value -= 0.02

                            # PLAY/RECORD
                            if (y > 0):
                                global recordFlag
                                if not recordFlag:
                                    self.state = State.START_RECORD_PROP
                                else:
                                    self.state = State.END_RECORD_PROP

                    if 'Material_Alpha_' in self.properties[self.prop_index]:
                        # Change alpha trasparency for the material diffuse
                        if ctrl_state.ulButtonPressed == 4294967296:
                            slot = int(self.properties[self.prop_index].split('Material_Alpha_')[1])
                            mat = bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name]

                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                            if (x > 0 and y < 0 and mat.alpha < 1):
                                mat.alpha += 0.02

                            if (x < 0 and y < 0 and mat.alpha > 0):
                                mat.alpha -= 0.02

                            # PLAY/RECORD
                            if (y > 0):
                                global recordFlag
                                if not recordFlag:
                                    self.state = State.START_RECORD_PROP
                                else:
                                    self.state = State.END_RECORD_PROP

                    if 'KeyFrame' in self.properties[self.prop_index]:
                        # Change alpha trasparency for the material diffuse
                        if ctrl_state.ulButtonPressed == 4294967296:
                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y

                            if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                                print("NEXT FRAME")
                                bpy.context.scene.frame_current += 1
                                timeSlider.location[0] += 0.01
                                bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(
                                    bpy.context.scene.frame_current)

                            if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                                print("PREV FRAME")
                                bpy.context.scene.frame_current -= 1
                                timeSlider.location[0] -= 0.01
                                bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(
                                    bpy.context.scene.frame_current)
                    '''

                if self.state == State.IDLE_TUNING_KEY:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll

                    # DECISIONAL
                    if (ctrl_state.ulButtonPressed == 4):
                        print("IDLE_TUNING -> DECISIONAL")
                        self.changeSelection(self.objToControll, self.boneToControll, False)
                        self.state = State.DECISIONAL

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                    # INTERACTION
                    if (ctrl_state.ulButtonPressed == 8589934592 and self.objToControll != ""):
                        print("IDLE -> INTERACTION LOCAL")
                        self.state = State.INTERACTION_LOCAL
                        self.curr_axes_r = 0

                        if self.boneToControll != "":
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].matrix.to_quaternion()
                            self.diff_loc = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].matrix.to_translation() - ctrl.location
                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].location)
                            bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'QUATERNION'

                        else:
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll].rotation_quaternion
                            self.diff_loc = bpy.data.objects[self.objToControll].location - ctrl.location
                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].location)
                            bpy.data.objects[self.objToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].rotation_mode = 'QUATERNION'

                    # TRACKPAD
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                        # Spostare al controller destro in keyframe mode
                        if (x > 0 and y > 0 and self.objToControll != ""):
                            print("INSERT KEYFRAME")
                            self.state = State.INSERT_PROP_KEYFRAME

                        if (x < 0 and y > 0 and self.objToControll != ""):
                            print("DELETE KEYFRAME")
                            self.state = State.DELETE_PROP_KEYFRAME


                        if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                            print("FIRST")
                            self.state = State.PREV_FRAME

                        if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                            print("LAST")
                            self.state = State.NEXT_FRAME


                    '''
                    if 'Material_Diffuse_' in self.properties[self.prop_index]:
                        # Change Hue and Saturation for the Diffuse Color
                        if ctrl_state.ulButtonPressed == 8589934592:
                            self.state = State.MOVE_COLOR_CURSOR_ENTER

                        # Change Value for the Diffuse Color
                        if ctrl_state.ulButtonPressed == 4294967296:
                            slot = int(self.properties[self.prop_index].split('Material_Diffuse_')[1])
                            mat = bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name]

                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                            if (x > 0 and y < 0 and mat.diffuse_color.v < 1):
                                mat.diffuse_color.v += 0.02

                            if (x < 0 and y < 0 and mat.diffuse_color.v  > 0):
                                mat.diffuse_color.v -= 0.02

                            # PLAY/RECORD
                            if(y > 0):
                                global recordFlag
                                if not recordFlag:
                                    self.state = State.START_RECORD_PROP
                                else:
                                    self.state = State.END_RECORD_PROP

                    if 'ShapeKey_' in self.properties[self.prop_index]:
                        # Change value of the Shapekey
                        if ctrl_state.ulButtonPressed == 4294967296:
                            slot = int(self.properties[self.prop_index].split('ShapeKey_')[1])
                            key = bpy.data.objects[self.objToControll].data.shape_keys.key_blocks[slot]

                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                            if (x > 0 and y < 0 and key.value < key.slider_max):
                                key.value += 0.02

                            if (x < 0 and y < 0 and key.value> key.slider_min):
                                key.value -= 0.02

                            # PLAY/RECORD
                            if (y > 0):
                                global recordFlag
                                if not recordFlag:
                                    self.state = State.START_RECORD_PROP
                                else:
                                    self.state = State.END_RECORD_PROP

                    if 'Material_Alpha_' in self.properties[self.prop_index]:
                        # Change alpha trasparency for the material diffuse
                        if ctrl_state.ulButtonPressed == 4294967296:
                            slot = int(self.properties[self.prop_index].split('Material_Alpha_')[1])
                            mat = bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name]

                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                            if (x > 0 and y < 0 and mat.alpha < 1):
                                mat.alpha += 0.02

                            if (x < 0 and y < 0 and mat.alpha > 0):
                                mat.alpha -= 0.02

                            # PLAY/RECORD
                            if (y > 0):
                                global recordFlag
                                if not recordFlag:
                                    self.state = State.START_RECORD_PROP
                                else:
                                    self.state = State.END_RECORD_PROP

                    if 'KeyFrame' in self.properties[self.prop_index]:
                        # Change alpha trasparency for the material diffuse
                        if ctrl_state.ulButtonPressed == 4294967296:
                            x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y

                            if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                                print("NEXT FRAME")
                                bpy.context.scene.frame_current += 1
                                timeSlider.location[0] += 0.01
                                bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(
                                    bpy.context.scene.frame_current)

                            if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                                print("PREV FRAME")
                                bpy.context.scene.frame_current -= 1
                                timeSlider.location[0] -= 0.01
                                bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(
                                    bpy.context.scene.frame_current)
                    '''

                if self.state == State.INSERT_PROP_KEYFRAME:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        global property_frame

                        if 'Material_Diffuse_' in self.properties[self.prop_index]:
                            slot = int(self.properties[self.prop_index].split('Material_Diffuse_')[1])
                            bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name].keyframe_insert(data_path='diffuse_color')
                            prop = Property(bpy.context.scene.frame_current,self.objToControll, self.boneToControll,self.properties[self.prop_index])

                        if 'ShapeKey_' in self.properties[self.prop_index]:
                            slot = int(self.properties[self.prop_index].split('ShapeKey_')[1])
                            bpy.data.objects[self.objToControll].data.shape_keys.key_blocks[slot].keyframe_insert(data_path='value')
                            prop = Property(bpy.context.scene.frame_current, self.objToControll, self.boneToControll, self.properties[self.prop_index])

                        if 'Material_Alpha_' in self.properties[self.prop_index]:
                            slot = int(self.properties[self.prop_index].split('Material_Alpha_')[1])
                            bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name].keyframe_insert(data_path='alpha')
                            prop = Property(bpy.context.scene.frame_current, self.objToControll, self.boneToControll,self.properties[self.prop_index])

                        i = -1
                        for index,p in enumerate(property_frame):
                            if p.frame == prop.frame and p.obj == prop.obj and p.bone == prop.bone and p.data_path == prop.data_path:
                                i=index
                                break
                        if i == -1:
                            property_frame.append(prop)

                        print("DEBUG [INSERT_PROP_KEYFRAME] - property frame content:")
                        for prop in property_frame:
                            print (prop.frame, prop.data_path)
                        print("DEBUG [INSERT_PROP_KEYFRAME] - - - - - - - - - - - - -")

                        updatePropKeyframeVisualization()
                        self.state = State.IDLE_TUNING_KEY

                if self.state == State.DELETE_PROP_KEYFRAME:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        global property_frame
                        prop = Property(bpy.context.scene.frame_current, self.objToControll, self.boneToControll, self.properties[self.prop_index])

                        i = -1
                        for index, p in enumerate(property_frame):
                            if p.frame == prop.frame and p.obj == prop.obj and p.bone == prop.bone and p.data_path == prop.data_path:
                                i = index
                                break
                        if i != -1:
                            property_frame.remove(property_frame[i])

                            if 'Material_Diffuse_' in self.properties[self.prop_index]:
                                slot = int(self.properties[self.prop_index].split('Material_Diffuse_')[1])
                                bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name].keyframe_delete(data_path='diffuse_color')

                            if 'ShapeKey_' in self.properties[self.prop_index]:
                                slot = int(self.properties[self.prop_index].split('ShapeKey_')[1])
                                bpy.data.objects[self.objToControll].data.shape_keys.key_blocks[slot].keyframe_delete(data_path='value')

                            if 'Material_Alpha_' in self.properties[self.prop_index]:
                                slot = int(self.properties[self.prop_index].split('Material_Alpha_')[1])
                                bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name].keyframe_delete(data_path='alpha')


                        print("DEBUG [DELETE_PROP_KEYFRAME] - property frame content:")
                        for property in property_frame:
                            print (property.frame, property.data_path)
                        print("DEBUG [DELETE_PROP_KEYFRAME] - len property:", len(property_frame))

                        updatePropKeyframeVisualization()
                        self.state = State.IDLE_TUNING_KEY

                if self.state == State.START_RECORD_PROP:
                    if ctrl_state.ulButtonPressed!=4294967296:
                        global mode
                        global playingAnimation
                        if not playingAnimation:
                            global recordFlag
                            recordFlag = True
                            if mode == "CURVE_PERF":
                                recorder_prop(self.properties, self.prop_index, True).start()
                                self.state = State.IDLE_CURVEMODE_PERF
                            else:
                                recorder_prop(self.properties, self.prop_index, False).start()
                                self.state = State.IDLE_TUNING_PERF

                            playerSound().start()

                        else:
                            print ("The system is already playing an animation")

                if self.state == State.END_RECORD_PROP:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        global recordFlag
                        recordFlag = False
                        playerSound().start()
                        global mode
                        if mode == "CURVE_PERF":
                            self.state = State.IDLE_CURVEMODE_PERF
                        if mode == "TUNNING_PERF":
                            self.state = State.IDLE_TUNING_PERF

                if self.state == State.IDLE_F_CURVEMODE:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll

                    # DECISIONAL
                    if ctrl_state.ulButtonPressed == 4 and len(self.properties)> 0 and self.prop_index!=-1:
                        print("IDLE (F-CURVE MODE) -> DECISIONAL")
                        global pointIndex_r

                        if self.properties[self.prop_index] + "_F-Curve" in bpy.data.objects and pointIndex_r[0] != -1:
                            bpy.data.objects[self.properties[self.prop_index] + "_F-Curve"].data.splines.active.bezier_points[pointIndex_r[0]].select_left_handle = False
                            bpy.data.objects[self.properties[self.prop_index] + "_F-Curve"].data.splines.active.bezier_points[pointIndex_r[0]].select_right_handle = False
                            bpy.data.objects[self.properties[self.prop_index] + "_F-Curve"].data.splines.active.bezier_points[pointIndex_r[0]].select_control_point = False

                        self.state = State.DECISIONAL_F_CURVEMODE

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                    # INTERACTION_LOCAL
                    if ctrl_state.ulButtonPressed == 8589934592 and self.properties[self.prop_index] + "_F-Curve" in bpy.data.objects:
                        ## Point grabbing
                        global pointIndex_r
                        if pointIndex_r[0] != -1:
                            objCurve = bpy.data.objects[self.properties[self.prop_index] + "_F-Curve"]

                            if pointIndex_r[1] == -1:
                                self.offesetCurvePoint_r = objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_left - tui.location
                            if pointIndex_r[1] == 0:
                                self.offesetCurvePoint_r = objCurve.data.splines.active.bezier_points[pointIndex_r[0]].co - tui.location
                                self.offesetCurveHandle_r[0] = objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_left - tui.location
                                self.offesetCurveHandle_r[1] = objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_right - tui.location
                            if pointIndex_r[1] == 1:
                                self.offesetCurvePoint_r = objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_right - tui.location

                            print ("DEBUG [IDLE_CURVEMODE] - offesetCurvePoint_r:", self.offesetCurvePoint_r)
                            self.state = State.INTERACTION_F_CURVEMODE
                            print("IDLE_CURVEMODE -> INTERACTION_CURVEMODE")

                if self.state == State.DECISIONAL_F_CURVEMODE:
                    # Compute the nearest object
                    bpy.data.objects["Text.R"].data.body = "Selection\n" + self.objToControll + "-" + self.boneToControll

                    global pointIndex_r
                    try:
                        pointIndex_r = self.getClosestBezierPoint(True, self.properties[self.prop_index] + "_F-Curve")
                    except:
                        print("Error during selection")

                    print("DEBUG [DECISIONAL_F_CURVEMODE] - pointIndex_r:", pointIndex_r)
                    if ctrl_state.ulButtonPressed != 4:
                        objCurve = bpy.data.objects[self.properties[self.prop_index] + "_F-Curve"]

                        if pointIndex_r[0] != -1:
                            if pointIndex_r[1] == -1:
                                objCurve.data.splines.active.bezier_points[pointIndex_r[0]].select_left_handle = True
                            if pointIndex_r[1] == 0:
                                objCurve.data.splines.active.bezier_points[pointIndex_r[0]].select_control_point = True
                            if pointIndex_r[1] == 1:
                                objCurve.data.splines.active.bezier_points[pointIndex_r[0]].select_right_handle = True

                        self.state = State.IDLE_F_CURVEMODE

                if self.state == State.INTERACTION_F_CURVEMODE:
                    print ("INTERACTION")
                    global pointIndex_r
                    objCurve = bpy.data.objects[self.properties[self.prop_index] + "_F-Curve"]


                    print ("DEBUG [INTERACTION_CURVEMODE] - offesetCurvePoint_r:", self.offesetCurvePoint_r)

                    co = copy.deepcopy(tui.location + self.offesetCurvePoint_r)
                    co[1] = 0

                    if pointIndex_r[0] != -1:
                        if pointIndex_r[1] == -1:
                            objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_left = co
                            bpy.data.objects["Text.R"].data.body = "Interaction\n" + \
                                                                   self.objToControll + "-" + self.boneToControll + "\n" + \
                                                                   "handle left - points[" + str(pointIndex_r[0]) + "]"
                        if pointIndex_r[1] == 0:
                            objCurve.data.splines.active.bezier_points[pointIndex_r[0]].co = co
                            objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_left = (tui.location + self.offesetCurveHandle_r[0])
                            objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_left[1] = 0
                            objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_right = (tui.location + self.offesetCurveHandle_r[1])
                            objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_right[1] = 0
                            bpy.data.objects["Text.R"].data.body = "Interaction\n" + self.objToControll + "-" + self.boneToControll + "\n" + "points[" + str(pointIndex_r[0]) + "]"
                        if pointIndex_r[1] == 1:
                            objCurve.data.splines.active.bezier_points[pointIndex_r[0]].handle_right = co
                            bpy.data.objects["Text.R"].data.body = "Interaction\n" + \
                                                                   self.objToControll + "-" + self.boneToControll + "\n" + \
                                                                   "handle right - points[" + str(pointIndex_r[0]) + "]"


                    print ("DEBUG [INTERACTION_CURVEMODE] - control point setted:")

                    if (ctrl_state.ulButtonPressed != 8589934592):
                        if self.objToControll != "":
                            if self.boneToControll != "":
                                curves, bones = getBoneCurves(self.objToControll, self.boneToControll)
                                fcurves = curves[bones.index(self.boneToControll)]
                            else:
                                fcurves = bpy.data.objects[self.objToControll].animation_data.action.fcurves

                            print ("DEBUG [INTERACTION_CURVEMODE] - applyFcurve")
                            self.applyFcurve(fcurves)
                            print ("DEBUG [INTERACTION_CURVEMODE] - getKeyframeModeAction(")
                            self.action_r_index = self.getKeyframeModeAction(True)

                            frames = getFrameFromCurve(fcurves, self.objToControll, self.boneToControll)
                            actions[self.action_r_index].frames = frames

                            print("DEBUG")
                            for a in actions:
                                print (a.name)
                            print(" - - - - - - - ")
                            for f in actions[self.action_r_index].frames:
                                print(f.frame, f.frameType, f.obj, f.loc, f.rot)
                            print(" ------------- ")

                        self.state = State.IDLE_F_CURVEMODE

                if self.state == State.IDLE_RIGGING:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll
                    tui.hide = True

                    # DECISIONAL
                    if (ctrl_state.ulButtonPressed == 4):
                        print("IDLE -> DECISIONAL")
                        global pointIndex_r

                        if pointIndex_r[0] != -1:
                            bpy.data.objects[self.objToControll].data.edit_bones[pointIndex_r[0]].select_head = False
                            bpy.data.objects[self.objToControll].data.edit_bones[pointIndex_r[0]].select_tail = False
                            bpy.data.objects[self.objToControll].data.edit_bones[pointIndex_r[0]].select = False

                        self.state = State.DECISIONAL_RIGGING

                    # INTERACTION_LOCAL
                    if (ctrl_state.ulButtonPressed == 8589934592 and self.objToControll != ""):
                        print("IDLE -> INTERACTION LOCAL")
                        ## Point grabbing
                        global pointIndex_r
                        if pointIndex_r[0] != -1:

                            objArm = bpy.data.objects[self.objToControll]

                            # Controlling head
                            if pointIndex_r[1] == -1:
                                self.diff_loc = objArm.data.edit_bones[pointIndex_r[0]].head - tui.location

                            # Controlling center
                            if pointIndex_r[1] == 0:
                                self.diff_loc = objArm.data.edit_bones[pointIndex_r[0]].center - tui.location
                                self.offesetCurveHandle_r[0] = objArm.data.edit_bones[pointIndex_r[0]].head - tui.location
                                self.offesetCurveHandle_r[1] = objArm.data.edit_bones[pointIndex_r[0]].tail - tui.location

                            #Controlling tail
                            if pointIndex_r[1] == 1:
                                self.diff_loc = objArm.data.edit_bones[pointIndex_r[0]].tail - tui.location

                            self.state = State.INTERACTION_RIGGING
                            print("IDLE_CURVEMODE -> INTERACTION_CURVEMODE")

                    # TRACKPAD COMMANDS
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x,y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y

                        if y > 0 and x > 0:
                            print ("Controlling selected bone's roll")
                            bpy.data.objects[self.objToControll].data.show_axes = True
                            self.state = State.INCREASE_BONE_ROLL
                        if y > 0 and x < 0:
                            print ("Controlling selected bone's roll")
                            bpy.data.objects[self.objToControll].data.show_axes = True
                            self.state = State.DECREASE_BONE_ROLL
                        if y < 0 and x > 0:
                            print ("Add bones")
                            self.state = State.ADD_BONE
                        if y < 0 and x < 0:
                            print ("Remove Bone")
                            self.state = State.REMOVE_BONE

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                if self.state == State.DECISIONAL_RIGGING:
                    # Compute the nearest object
                    bpy.data.objects["Text.R"].data.body = "Selection\n" + self.objToControll + "-" + self.boneToControll

                    global pointIndex_r
                    try:
                        # pointIndex_r[0] =  Bone index
                        # pointIndex_r[1] =  -1 -> head
                        # pointIndex_r[1] =  0 -> center
                        # pointIndex_r[1] =  1 -> tail,
                        pointIndex_r = self.getClosestBonePart(True, self.objToControll)
                    except:
                        print("Error during selection")

                    print("DEBUG [DECISIONAL_RIGGING] - pointIndex_r:", pointIndex_r)

                    if ctrl_state.ulButtonPressed != 4:
                        objArm = bpy.data.objects[self.objToControll]

                        # if mirroring is enabled
                        if self.mirror_axes[0] or self.mirror_axes[1] or self.mirror_axes[2]:

                            print ("1",  objArm.data.edit_bones[pointIndex_r[0]].name)
                            if "_MIRRORED" in objArm.data.edit_bones[pointIndex_r[0]].name:
                                self.properties = objArm.data.edit_bones[pointIndex_r[0]].name.split("_MIRROR")[0]
                                print ("The selected bone is a mirrored bone - ", self.properties)

                            elif objArm.data.edit_bones[pointIndex_r[0]].name + "_MIRRORED" in objArm.data.edit_bones:
                                self.properties = objArm.data.edit_bones[pointIndex_r[0]].name + "_MIRRORED"
                                print ("The selected bone is the original and mirrored exist", self.properties)
                            else:
                                self.addMirroredBone(objArm.data.edit_bones[pointIndex_r[0]].name + "_MIRRORED")
                                self.properties = objArm.data.edit_bones[pointIndex_r[0]].name + "_MIRRORED"
                                print ("The selected bone is the original and mirrored is created", self.properties)

                        if pointIndex_r[0] != -1:
                            if pointIndex_r[1] == -1:
                                objArm.data.edit_bones[pointIndex_r[0]].select_head = True
                            if pointIndex_r[1] == 0:
                                objArm.data.edit_bones[pointIndex_r[0]].select = True
                            if pointIndex_r[1] == 1:
                                objArm.data.edit_bones[pointIndex_r[0]].select_tail = True

                        self.state = State.IDLE_RIGGING

                if self.state == State.INTERACTION_RIGGING:
                    global pointIndex_r
                    objArm = bpy.data.objects[self.objToControll]

                    bpy.data.objects["Text.R"].data.body = "Interaction\n" + self.objToControll + "-" + self.boneToControll + "\n" + "bones[" + str(pointIndex_r) + "]"

                    if pointIndex_r[1]==-1:
                        objArm.data.edit_bones[pointIndex_r[0]].head = tui.location + self.diff_loc
                        if self.mirror_axes[0] or self.mirror_axes[1] or self.mirror_axes[2]:
                            objArm.data.edit_bones[self.properties].head = tui.location + self.diff_loc
                            if self.mirror_axes[0]:
                                objArm.data.edit_bones[self.properties].head[0] = -objArm.data.edit_bones[pointIndex_r[0]].head[0]
                            if self.mirror_axes[1]:
                                objArm.data.edit_bones[self.properties].head[1] = -objArm.data.edit_bones[pointIndex_r[0]].head[1]
                            if self.mirror_axes[2]:
                                objArm.data.edit_bones[self.properties].head[2] = -objArm.data.edit_bones[pointIndex_r[0]].head[2]

                    elif pointIndex_r[1]==0:
                        objArm.data.edit_bones[pointIndex_r[0]].head = tui.location + self.offesetCurveHandle_r[0]
                        objArm.data.edit_bones[pointIndex_r[0]].tail = tui.location + self.offesetCurveHandle_r[1]

                    elif pointIndex_r[1] == 1:
                        objArm.data.edit_bones[pointIndex_r[0]].tail = tui.location + self.diff_loc
                        if self.mirror_axes[0] or self.mirror_axes[1] or self.mirror_axes[2]:
                            objArm.data.edit_bones[self.properties].tail = tui.location + self.diff_loc
                            if self.mirror_axes[0]:
                                objArm.data.edit_bones[self.properties].tail[0] = -objArm.data.edit_bones[pointIndex_r[0]].tail[0]
                            if self.mirror_axes[1]:
                                objArm.data.edit_bones[self.properties].tail[1] = -objArm.data.edit_bones[pointIndex_r[0]].tail[1]
                            if self.mirror_axes[2]:
                                objArm.data.edit_bones[self.properties].tail[2] = -objArm.data.edit_bones[pointIndex_r[0]].tail[2]

                    if (ctrl_state.ulButtonPressed != 8589934592):
                        self.state = State.IDLE_RIGGING

                # if self.state == State.INTERACTION_RIGGING:
                #     global pointIndex_r
                #     objArm = bpy.data.objects[self.objToControll]
                #
                #     bpy.data.objects["Text.R"].data.body = "Interaction\n" + self.objToControll + "-" + self.boneToControll + "\n" + "bones[" + str(pointIndex_r) + "]"
                #
                #     if pointIndex_r[1]==-1:
                #         objArm.data.edit_bones[pointIndex_r[0]].head = tui.location + self.diff_loc
                #     if pointIndex_r[1]==0:
                #         objArm.data.edit_bones[pointIndex_r[0]].head = tui.location + self.offesetCurveHandle_r[0]
                #         objArm.data.edit_bones[pointIndex_r[0]].tail = tui.location + self.offesetCurveHandle_r[1]
                #     if pointIndex_r[1] == 1:
                #         objArm.data.edit_bones[pointIndex_r[0]].tail = tui.location + self.diff_loc
                #
                #     if (ctrl_state.ulButtonPressed != 8589934592):
                #         self.state = State.IDLE_RIGGING

                if self.state == State.ADD_BONE:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        self.addBone()
                        self.state = State.IDLE_RIGGING

                if self.state == State.REMOVE_BONE:
                    if ctrl_state.ulButtonPressed != 4294967296:
                        print(self.boneToControll)
                        armature = bpy.data.objects[self.objToControll].data
                        bone = armature.edit_bones[self.boneToControll]
                        armature.edit_bones.remove(bone)
                        bpy.ops.object.mode_set(mode='OBJECT')
                        bpy.ops.object.mode_set(mode='EDIT')
                        global pointIndex_r
                        pointIndex_r = (-1,-1)
                        self.boneToControll = ""
                        print("FINISHED")
                        self.state = State.IDLE_RIGGING

                if self.state == State.INCREASE_BONE_ROLL:
                    global pointIndex_r
                    bpy.data.objects[self.objToControll].data.edit_bones[pointIndex_r[0]].roll += 0.05
                    if ctrl_state.ulButtonPressed != 4294967296:
                        bpy.data.objects[self.objToControll].data.show_axes = False
                        self.state = State.IDLE_RIGGING

                if self.state == State.DECREASE_BONE_ROLL:
                    global pointIndex_r
                    bpy.data.objects[self.objToControll].data.edit_bones[pointIndex_r[0]].roll -= 0.05
                    if ctrl_state.ulButtonPressed != 4294967296:
                        bpy.data.objects[self.objToControll].data.show_axes = False
                        self.state = State.IDLE_RIGGING

                if self.state == State.IDLE_SKINNING:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll + "\nWeight:" + "{0:.2f}".format(self.prop_index)
                    # TRACKPAD COMMANDS
                    if ctrl_state.ulButtonPressed == 4294967296:
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                        if x > 0 and y < 0:
                            print ("Controlling brush dim")
                            self.state = State.INCREASE_BRUSH_DIM
                        if x < 0 and y < 0:
                            print ("Controlling brush dim")
                            self.state = State.DECREASE_BRUSH_DIM
                        if x > 0 and y > 0:
                            print ("Controlling weight")
                            self.state = State.INCREASE_BRUSH_WEIGHT
                        if x < 0 and y > 0:
                            print ("Controlling weight")
                            self.state = State.DECREASE_BRUSH_WEIGHT

                    # INTERACTION
                    if ctrl_state.ulButtonPressed == 8589934592:
                        print("IDLE -> INTERACTION LOCAL")
                        self.createVertices()

                        self.state = State.INTERACTION_SKINNING

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                    # DECISIONAL
                    if ctrl_state.ulButtonPressed == 4 and len(bpy.data.objects[self.objToControll].vertex_groups) > 0:
                        self.state = State.CHANGE_VERTEX_GROUP

                if self.state == State.CHANGE_VERTEX_GROUP:

                    # get the closest bone
                    newbone = self.getClosestBone(True, self.objToControll_l)
                    if ctrl_state.ulButtonPressed != 4:

                        # ------------------------ #
                        # PROXIMITY SELECTION MODE #
                        # ------------------------ #

                        # Verify if the bone has a vertex group assigned
                        index = -1
                        for i in range(0, len(bpy.data.objects[self.objToControll].vertex_groups)):
                            print(bpy.data.objects[self.objToControll].vertex_groups.active.name, "==" , newbone, "?")
                            if bpy.data.objects[self.objToControll].vertex_groups[i].name == newbone:
                                index = i

                        print ("index:",index, "bonename:", newbone)

                        if index!= -1 and newbone!="":
                            #deselect previous selected bone
                            if self.boneToControll_l != "":
                                bpy.data.objects[self.objToControll_l].data.bones[self.boneToControll_l].select = False

                            # select the new bone
                            self.boneToControll_l = newbone
                            bpy.data.objects[self.objToControll_l].data.bones[self.boneToControll_l].select = True

                            # set as active the corresponding vertex group
                            bpy.data.objects[self.objToControll].vertex_groups.active_index = index

                            # if the bone is in a ik chain sets self.prop_index
                            boneConstrained = bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l]
                            ikc = None
                            #  looks for the first IK constraints
                            if len(boneConstrained.constraints) > 0:
                                for i in range(0, len(boneConstrained.constraints)):
                                    if boneConstrained.constraints[i].type == 'IK':
                                        ikc = boneConstrained.constraints[i]
                                        break

                            # Updates Chain Length field
                            if ikc != None:
                                self.prop_index = ikc.chain_count

                        self.state = State.IDLE_SKINNING

                    '''
                    # ------------------------ #
                    # SCROLLING SELECTION MODE #
                    # ------------------------ #
                        
                    if ctrl_state.ulButtonPressed != 4:
                        if bpy.data.objects[self.objToControll].vertex_groups.active_index < len(bpy.data.objects[self.objToControll].vertex_groups):
                            bpy.data.objects[self.objToControll].vertex_groups.active_index += 1
                        else:
                            bpy.data.objects[self.objToControll].vertex_groups.active_index = 0

                        if self.boneToControll_l!= "":
                            bpy.data.objects[self.objToControll_l].data.bones[self.boneToControll_l].select = False

                        #get the new bone name
                        self.boneToControll_l = bpy.data.objects[self.objToControll].vertex_groups.active.name
                        

                        if self.boneToControll_l in bpy.data.objects[self.objToControll_l].data.bones:

                            bpy.data.objects[self.objToControll_l].data.bones[self.boneToControll_l].select = True

                            # if the bone is in a ik chain sets self.prop_index
                            boneConstrained = bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l]
                            ikc = None
                            #  looks for the first IK constraints
                            if len(boneConstrained.constraints) > 0:
                                for i in range(0, len(boneConstrained.constraints)):
                                    if boneConstrained.constraints[i].type == 'IK':
                                        ikc = boneConstrained.constraints[i]
                                        break

                            # Updates Chain Length field
                            if ikc != None:
                                self.prop_index = ikc.chain_count
                            else:
                                pass
                                #self.prop_index = 0

                        # In the aramature there is not a bone called as the vertex group item
                        else:
                            self.boneToControll_l = ""
                            self.prop_index=0

                        self.state = State.IDLE_SKINNING
                        '''

                if self.state == State.INTERACTION_SKINNING:

                    vertexToAdd = []
                    obj = bpy.data.objects[self.objToControll]
                    brush = bpy.data.objects["Brush"]

                    updatedvertices = self.getUpdatedVertices(self.objToControll)

                    for i in range(0, len(updatedvertices)):
                        #loc = obj.matrix_world * updatedvertices[i].co
                        loc = updatedvertices[i].co

                        curr_distance = (math.sqrt(
                            pow((brush.location[0] - loc[0]), 2) + pow((brush.location[1] - loc[1]), 2) + pow(
                                (brush.location[2] - loc[2]), 2)))
                        if (curr_distance < brush.scale[0]):
                            vertexToAdd.append(i)
                    obj.vertex_groups.active.add(vertexToAdd, self.prop_index, 'REPLACE')
                    obj.data.update()

                    if ctrl_state.ulButtonPressed != 8589934592:
                        self.deleteVertices()
                        self.state = State.IDLE_SKINNING

                if self.state == State.INCREASE_BRUSH_DIM:
                    bpy.data.objects['Brush'].scale += Vector((0.005, 0.005, 0.005))
                    if ctrl_state.ulButtonPressed != 4294967296:
                        self.state = State.IDLE_SKINNING

                if self.state == State.DECREASE_BRUSH_DIM:
                    bpy.data.objects['Brush'].scale -= Vector((0.005, 0.005, 0.005))
                    if ctrl_state.ulButtonPressed != 4294967296:
                        self.state = State.IDLE_SKINNING

                if self.state == State.INCREASE_BRUSH_WEIGHT:
                    if(self.prop_index < 1):
                        self.prop_index+= 0.01
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll + "\nWeight:" + "{0:.2f}".format(self.prop_index)
                    if ctrl_state.ulButtonPressed != 4294967296:
                        self.state = State.IDLE_SKINNING

                if self.state == State.DECREASE_BRUSH_WEIGHT:
                    if (self.prop_index > 0):
                        self.prop_index -= 0.01
                    bpy.data.objects[
                        "Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll + "\nWeight:" + "{0:.2f}".format(self.prop_index)
                    if ctrl_state.ulButtonPressed != 4294967296:
                        self.state = State.IDLE_SKINNING

                if self.state == State.IDLE_ARM_CONSTR:
                    bpy.data.objects["Text.R"].data.body = "Idle\n" + self.objToControll + "-" + self.boneToControll + "\nIK Chain len.:" + "{0:.2f}".format(self.prop_index)

                    # TRACKPAD COMMANDS
                    if ctrl_state.ulButtonPressed == 4294967296 and self.boneToControll !="":
                        x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
                        if (x > 0 and y > 0):
                            self.state = State.INCREASE_CHAIN_LENGTH

                        if (x < 0 and y > 0):
                            self.state = State.DECREASE_CHAIN_LENGTH

                        if (x > 0 and y < 0):
                            self.state = State.SET_TARGET_IK

                        if (x < 0 and y < 0):
                            self.state = State.SET_POLE_IK

                    # NAVIGATION
                    if ctrl_state.ulButtonPressed == 2:
                        print("IDLE -> NAVIGATION")
                        self.state = State.NAVIGATION_ENTER

                    # INTERACTION
                    if ctrl_state.ulButtonPressed == 8589934592:
                        print("IDLE -> INTERACTION LOCAL")
                        self.state = State.INTERACTION_LOCAL
                        self.curr_axes_r = 0

                        if self.boneToControll != "":
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].matrix.to_quaternion()
                            self.diff_loc = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].matrix.to_translation() - ctrl.location
                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].location)
                            bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'QUATERNION'

                        else:
                            self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll].rotation_quaternion
                            self.diff_loc = bpy.data.objects[self.objToControll].location - ctrl.location
                            self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].location)
                            bpy.data.objects[self.objToControll].rotation_mode = 'XYZ'
                            self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].rotation_euler)
                            bpy.data.objects[self.objToControll].rotation_mode = 'QUATERNION'

                    # DECISIONAL
                    if (ctrl_state.ulButtonPressed == 4):
                        print("IDLE -> DECISIONAL")
                        self.changeSelection(self.objToControll, self.boneToControll, False)
                        self.state = State.DECISIONAL

                if self.state == State.INCREASE_CHAIN_LENGTH:
                    print("inc")
                    if ctrl_state.ulButtonPressed != 4294967296:
                        self.prop_index += 1
                        print (self.prop_index)

                        # Update field if IK constraint exist
                        if self.objToControll!="" and self.boneToControll!="":
                            boneConstrained = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll]
                            ikc = None
                            #  looks for the first IK constraints
                            if len(boneConstrained.constraints) > 0:
                                for i in range(0, len(boneConstrained.constraints)):
                                    if boneConstrained.constraints[i].type == 'IK':
                                        ikc = boneConstrained.constraints[i]
                                        break

                                # Updates Chain Length field
                                if ikc != None:
                                    ikc.chain_count = self.prop_index

                        self.state = State.IDLE_ARM_CONSTR

                if self.state == State.DECREASE_CHAIN_LENGTH:
                    print("dec")
                    if ctrl_state.ulButtonPressed != 4294967296:
                        if self.prop_index > 0:
                            self.prop_index -= 1
                            print (self.prop_index)

                        # Update field if IK constraint exist
                        if self.objToControll!="" and self.boneToControll!="":
                            boneConstrained = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll]
                            ikc = None
                            #  looks for the first IK constraints
                            if len(boneConstrained.constraints) > 0:
                                for i in range(0, len(boneConstrained.constraints)):
                                    if boneConstrained.constraints[i].type == 'IK':
                                        ikc = boneConstrained.constraints[i]
                                        break

                                # Updates Chain Length field
                                if ikc != None:
                                    ikc.chain_count = self.prop_index

                        self.state = State.IDLE_ARM_CONSTR

                if self.state == State.SET_TARGET_IK:
                    print ("SET_TARGET_IK")
                    bone_target = self.getClosestBone(True, self.objToControll)

                    if ctrl_state.ulButtonPressed != 4294967296:
                        print ("SET_TARGET_IK OPERATION")
                        if bone_target != "":
                            boneConstrained = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll]

                            ikc = None
                            #  looks for the first IK constraint
                            if len(boneConstrained.constraints) > 0:
                                for i in range(0, len(boneConstrained.constraints)):
                                    if boneConstrained.constraints[i].type == 'IK':
                                        ikc = boneConstrained.constraints[i]
                                        break

                            #Creates the constraint IK if it not exist
                            if ikc == None:
                                ikc = boneConstrained.constraints.new('IK')
                                ikc.chain_count = self.prop_index

                            # Updates target field
                            if self.boneToControll != bone_target:
                                ikc.target = bpy.data.objects[self.objToControll]
                                ikc.subtarget = bone_target

                        self.state = State.IDLE_ARM_CONSTR

                if self.state == State.SET_POLE_IK:
                    print ("SET_POLE_IK")
                    bone_target = self.getClosestBone(True, self.objToControll)
                    if ctrl_state.ulButtonPressed != 4294967296:
                        print ("SET_POLE_IK OPERATION")
                        if bone_target != "":
                            boneConstrained = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll]

                            ikc = None
                            #  looks for the first IK constraints
                            if len(boneConstrained.constraints) > 0:
                                for i in range(0, len(boneConstrained.constraints)):
                                    if boneConstrained.constraints[i].type == 'IK':
                                        ikc = boneConstrained.constraints[i]
                                        break

                                # Updates pole field
                                if ikc != None and self.boneToControll != bone_target:
                                    ikc.pole_target= bpy.data.objects[self.objToControll]
                                    ikc.pole_subtarget = bone_target

                        self.state = State.IDLE_ARM_CONSTR

                ########## Left_Controller_States ##########

                if self.state_l == StateLeft.IDLE:
                    bpy.data.objects["Text.L"].data.body = "Idle\n" + self.objToControll_l + "-" + self.boneToControll_l
                    tui_l.hide = True

                    ## TIMELINE NAVIGATION
                    if ctrl_state_l.ulButtonPressed == 4294967296:
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y
                        if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                            print("NEXT")
                            bpy.context.scene.frame_current += 1
                            timeSlider.location[0]+=0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                            print("PREV")
                            bpy.context.scene.frame_current -= 1
                            timeSlider.location[0] -= 0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        if (x>0 and y>0):
                            self.incrementTransformation(True)
                            print("Increment Prop")

                        if (x<0 and y>0):
                            self.incrementTransformation(False)
                            print ("Decrease Prop")

                    # DECISIONAL
                    if (ctrl_state_l.ulButtonPressed == 4):
                        print("IDLE -> DECISIONAL")
                        print ("DECISIONAL ENTER: ", self.objToControll_l, self.boneToControll_l)
                        self.changeSelection(self.objToControll_l, self.boneToControll_l, False)
                        drawAction(self.objToControll_l, self.boneToControll_l, False, False)
                        self.state_l = StateLeft.DECISIONAL

                    # INTERACTION_LOCAL
                    if (ctrl_state_l.ulButtonPressed == 8589934592 and self.objToControll_l != ""):
                        print("IDLE -> INTERACTION LOCAL")
                        self.state_l = StateLeft.INTERACTION_LOCAL
                        self.curr_axes_l = 0

                        if self.boneToControll_l != "":
                            self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].matrix.to_quaternion()
                            self.diff_loc_l = bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].matrix.to_translation() - ctrl_l.location
                            self.initial_loc_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].location)
                            bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].rotation_mode = 'XYZ'
                            self.initial_rot_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].rotation_euler)
                            bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].rotation_mode = 'QUATERNION'

                        else:
                            self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll_l].rotation_quaternion
                            self.diff_loc_l = bpy.data.objects[self.objToControll_l].location - ctrl_l.location
                            self.initial_loc_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].location)
                            bpy.data.objects[self.objToControll_l].rotation_mode = 'XYZ'
                            self.initial_rot_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].rotation_euler)
                            bpy.data.objects[self.objToControll_l].rotation_mode = 'QUATERNION'

                    # SETTING
                    if (ctrl_state_l.ulButtonPressed == 2):
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE -> SETTING_ENTER")
                            self.gui_obj_custom_buttons = []
                            for item in bpy.types.Scene.gui_map:
                                self.gui_obj_custom_buttons.append(item)
                            self.display_menu(False)

                            self.state_l = StateLeft.SETTING_ENTER

                if self.state_l == StateLeft.INTERACTION_LOCAL:
                    bpy.data.objects["Text.L"].data.body = "Interaction\n" + self.objToControll_l + "-" + self.boneToControll_l + "\n" + self.axes[self.curr_axes_l]
                    tui_l.hide = True
                    pointer.hide = True

                    if self.objToControll == self.objToControll_l \
                            and self.boneToControll == self.boneToControll_l \
                            and ctrl_state.ulButtonPressed == 8589934592\
                            and self.state != State.CAMERA_ROT_CONT \
                            and self.state != State.NAVIGATION:
                        self.state_l = StateLeft.SCALING
                        self.state = State.SCALING

                    else:
                        if self.boneToControll_l != "":
                            ## The object to move is a bone
                            bone = bpy.data.objects[self.objToControll_l]
                            pbone = bone.pose.bones[self.boneToControll_l]
                            scale = copy.deepcopy(pbone.scale)
                            translationMatrix = Matrix(((0.0, 0.0, 0.0, self.diff_loc_l[0]),
                                                        (0.0, 0.0, 0.0, self.diff_loc_l[1]),
                                                        (0.0, 0.0, 0.0, self.diff_loc_l[2]),
                                                        (0.0, 0.0, 0.0, 1.0)))
                            diff_rot_matr = self.diff_rot_l.to_matrix()
                            pbone.matrix = (ctrl_l.matrix_world + translationMatrix) * diff_rot_matr.to_4x4()
                            pbone.scale = scale

                            self.applyConstraint(False)

                            global local_repr_ON
                            if local_repr_ON and '_Local.Repr' in self.objToControll_l:
                                # Copy location and rotation to the target bone
                                pboneTarget = bpy.data.objects[self.objToControll_l.split('_Local.Repr')[0]].pose.bones[self.boneToControll_l]
                                pboneTarget.rotation_quaternion = copy.deepcopy(pbone.rotation_quaternion)
                                pboneTarget.location = copy.deepcopy(pbone.location)

                        else:
                            ## The object to move is a mesh
                            bpy.data.objects[self.objToControll_l].rotation_quaternion = ctrl_l.rotation_quaternion * self.diff_rot_l
                            bpy.data.objects[self.objToControll_l].location = ctrl_l.location + self.diff_loc_l

                            self.applyConstraint(False)

                            global local_repr_ON
                            if local_repr_ON and '_Local.Repr' in self.objToControll_l:
                                objTarget = bpy.data.objects[self.objToControll_l.split('_Local.Repr')[0]]
                                objTarget.rotation_quaternion = bpy.data.objects[self.objToControll_l].rotation_quaternion

                    if (ctrl_state_l.ulButtonPressed==8589934596):
                        print("INTERACTION_LOCAL -> CHANGE_AXIS")
                        global mode
                        if mode != "SKINNING":
                            self.state_l = StateLeft.CHANGE_AXES

                    if (ctrl_state_l.ulButtonPressed != 8589934592 and ctrl_state_l.ulButtonPressed != 8589934596):
                        global mode
                        if mode == "ACTION":
                            self.state_l = StateLeft.IDLE
                            print ("INTERACTION_LOCAL -> IDLE")
                        if mode == "KEYFRAME":
                            self.state_l = StateLeft.IDLE_KEYMODE
                            print ("INTERACTION_LOCAL -> IDLE (KEYFRAME MODE)")
                        if mode == "SKINNING":
                            self.state_l = StateLeft.IDLE_SKINNING
                            print ("INTERACTION_LOCAL -> IDLE (SKINNING MODE)")

                if self.state_l == StateLeft.CHANGE_AXES:
                    if (ctrl_state_l.ulButtonPressed==8589934592):
                        self.curr_axes_l+=1
                        if self.curr_axes_l>=len(self.axes):
                            self.curr_axes_l=0
                        self.curr_axes_r=0
                        print(self.curr_axes_l)
                        print("CHANGE_AXIS -> INTERACTION_LOCAL")
                        self.state_l = StateLeft.INTERACTION_LOCAL

                    if (ctrl_state_l.ulButtonPressed==0):
                        # print("grillet released")
                        global mode
                        if mode == "ACTION":
                            self.state_l = StateLeft.IDLE
                            print ("CHANGE_AXIS -> IDLE")
                        if mode == "KEYFRAME":
                            self.state_l = StateLeft.IDLE_KEYMODE
                            print ("CHANGE_AXIS -> IDLE (KEY MODE)")

                if self.state_l == StateLeft.SCALING:

                    # Exit from Scaling state
                    if (ctrl_state_l.ulButtonPressed != 8589934592):
                        if (ctrl_state.ulButtonPressed != 8589934592):
                            global mode
                            if mode == "ACTION":
                                self.state = State.IDLE
                                self.state_l = StateLeft.IDLE
                                print ("SCALING -> IDLE")
                            if mode == "KEYFRAME":
                                self.state = State.IDLE_KEYMODE
                                self.state_l = StateLeft.IDLE_KEYMODE
                                print ("SCALING -> IDLE (KEY MODE)")

                if self.state_l == StateLeft.DECISIONAL:
                    bpy.data.objects["Text.L"].data.body = "Selection\n" + self.objToControll_l + "-" + self.boneToControll_l
                    tui_l.hide = False
                    pointer.hide = False

                    # Compute the nearest object
                    self.objToControll_l, self.boneToControll_l = self.getClosestItem(pointer, False)
                    global currObject_l
                    global currBone_l
                    currObject_l = self.objToControll_l
                    currBone_l = self.boneToControll_l
                    print("Current obj:", self.objToControll_l, self.boneToControll_l)

                    if ctrl_state_l.ulButtonPressed != 4:

                        global mode
                        pointer.hide = True

                        # Current selection is not changed
                        if mode == "RIGGING":
                            print ("DECISIONAL -> IDLE (RIGGING)")
                            self.state_l = StateLeft.IDLE_RIGGING

                        else:
                            #print("touch button released")
                            self.changeSelection(self.objToControll_l, self.boneToControll_l, True)
                            drawAction(self.objToControll_l, self.boneToControll_l, True, False)
                            drawAction(self.objToControll, self.boneToControll, True, True)


                            if mode == "ACTION":
                                global local_repr_ON
                                if local_repr_ON:
                                    print("DEBUG [DECISIONAL] - Calling create_local_repre")
                                    self.create_local_repr(local_repr_ON)

                                self.state_l = StateLeft.IDLE
                                print ("DECISIONAL -> IDLE")

                            if mode == "KEYFRAME":
                                self.state_l = StateLeft.IDLE_KEYMODE
                                # Create an action to contain keyframe defined in KEYMODE if not exist
                                self.action_l_index = self.getKeyframeModeAction(False)

                                # Updates keyframe visualization
                                print("UPDATING KEYFRAME")
                                updateKeyframeVisualization()

                                global local_repr_ON
                                global local_repr_ON
                                if local_repr_ON:
                                    print("DEBUG [DECISIONAL] - Calling create_local_repre")
                                    self.create_local_repr(local_repr_ON)

                                print ("DECISIONAL -> IDLE (KEYFRAME MODE)")

                if self.state_l == StateLeft.NAVIGATION:
                    if (ctrl_state_l.ulButtonPressed == 4294967296):
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y
                        if y < 0:
                            self.state_l = StateLeft.SET_ORTHOGONAL_VIEW
                        if y > 0:
                            self.state_l = StateLeft.SET_PERSPECTIVE_VIEW

                if self.state_l == StateLeft.SET_ORTHOGONAL_VIEW:
                    print("Sono dentro")
                    if (ctrl_state_l.ulButtonPressed != 4294967296):
                        print("Sono dentro 2")
                        bpy.data.objects['Origin'].hide = True
                        self.state_l = StateLeft.NAVIGATION

                if self.state_l == StateLeft.SET_PERSPECTIVE_VIEW:
                    print("Sono dentro per")
                    if (ctrl_state_l.ulButtonPressed != 4294967296):
                        print("Sono dentro per 2")
                        bpy.data.objects['Origin'].hide = False
                        self.state_l = StateLeft.NAVIGATION

                if self.state_l == StateLeft.SETTING_ENTER:
                    #bpy.data.objects["Text.R"].data.body = "Setting\n " + self.objToControll + "-" + self.boneToControll
                    #bpy.data.objects["Text.L"].data.body = "Setting\n " + self.objToControll_l + "-" + self.boneToControll_l

                    if ctrl_state_l.ulButtonPressed != 2:
                        print("SETTING_ENTER-> SETTING")

                        bpy.data.textures['Texture.R'].image = bpy.data.images['Sett-R.png']
                        bpy.data.textures['Texture.L'].image = bpy.data.images['Sett-R.png']
                        drawActionPath(self.objToControll, self.boneToControll, False)
                        drawActionProp(self.objToControll, self.boneToControll, False)
                        bpy.data.objects['F-Curve-Grid'].hide = True

                        global mode
                        if mode == "CURVE":
                            # Deselct the path if exist
                            if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                                bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].select = False
                                bpy.ops.object.mode_set(mode='OBJECT')
                                bpy.context.scene.objects.active = bpy.data.objects[self.objToControll]

                            self.changeSelection(self.objToControll,self.boneToControll,True)
                            self.changeSelection(self.objToControll_l, self.boneToControll_l, True)

                        self.state_l = StateLeft.SETTING
                        self.state = State.SETTING

                if self.state_l == StateLeft.SETTING:
                    global playingAnimation
                    if not playingAnimation:
                        if ctrl_state_l.ulButtonPressed == 8589934592:
                            self.state_l = StateLeft.ON_BUTTON_PRESSED

                        # Menu Button (Setting Exit)
                        if ctrl_state_l.ulButtonPressed == 2:
                            print ("SETTING -> SETTING_EXIT")
                            self.state_l = StateLeft.SETTING_EXIT

                        # Gripper
                        if (ctrl_state_l.ulButtonPressed == 4):
                            string = bpy.types.Scene.controller_map['GRIPPER.L_Down']
                            print("exec Gripper.L OnKeyDown:", string)
                            exec (string)
                            self.state_l = StateLeft.CUSTOM_CONTROL_GRIPPER_RELEASED

                        # Trackpad
                        if ctrl_state_l.ulButtonPressed == 4294967296:
                            self.state_l = StateLeft.CUSTOM_CONTROL_TRACKPAD_RELEASED

                if self.state_l == StateLeft.CUSTOM_CONTROL_GRIPPER_RELEASED:
                    string = bpy.types.Scene.controller_map['GRIPPER.L_Press']
                    print("exec Gripper.L OnKeyPress:", string)
                    exec (string)
                    if (ctrl_state_l.ulButtonPressed != 4):
                        string = bpy.types.Scene.controller_map['GRIPPER.L_Up']
                        print("exec Gripper.L OnKeyUp", string)
                        exec (string)
                        self.state_l = StateLeft.SETTING

                if self.state_l == StateLeft.CUSTOM_CONTROL_TRACKPAD_RELEASED:
                    x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y
                    if x > 0 and y > 0:
                        self.updateControl_controller(True, "TRACKPAD_UR.L_Press")
                    if x < 0 and y > 0:
                        self.updateControl_controller(False, "TRACKPAD_UL.L_Press")
                    if x > 0 and y < 0:
                        self.updateControl_controller(True, "TRACKPAD_BR.L_Press")
                    if x < 0 and y < 0:
                        self.updateControl_controller(False, "TRACKPAD_BL.L_Press")

                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y
                        if x > 0 and y > 0:
                            self.updateControl_controller(True, "TRACKPAD_UR.L_Up")
                        if x < 0 and y > 0:
                            self.updateControl_controller(False, "TRACKPAD_UL.L_Up")
                        if x > 0 and y < 0:
                            self.updateControl_controller(True, "TRACKPAD_BR.L_Up")
                        if x < 0 and y < 0:
                            self.updateControl_controller(False, "TRACKPAD_BL.L_Up")

                        self.state_l = StateLeft.SETTING

                if self.state_l == StateLeft.SETTING_EXIT:
                    print ("SETTING EXIT")
                    self.display_menu(True)
                    #bpy.data.objects["Text.R"].data.body = "Setting\n " + self.objToControll + "-" + self.boneToControll
                    #bpy.data.objects["Text.L"].data.body = "Setting\n " + self.objToControll_l + "-" + self.boneToControll_l

                    if ctrl_state_l.ulButtonPressed != 2:
                        global mode
                        if mode == "ACTION":
                            global prop_ON
                            global path_ON

                            if prop_ON:
                                mode = "TUNNING_PERF"

                            elif path_ON:
                                mode = "CURVE_PERF"

                            else:
                                print("SETTING_EXIT-> IDLE (ACTION MODE)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']
                                recursive_delete_children()

                                print ("DEBUG - [SETTING_EXIT] actions:")
                                for a in actions:
                                    print (a.name, len(a.frames))

                                drawAction(self.objToControll,self.boneToControll, True, True)
                                drawAction(self.objToControll_l, self.boneToControll_l, True, False)
                                bpy.data.objects['ColorPalette'].hide = True
                                bpy.data.objects['ColorPaletteCursor'].hide = True
                                self.state_l = StateLeft.IDLE
                                self.state = State.IDLE

                                print ("DEBUG - [SETTING_EXIT] {DONE}")

                        if mode == "KEYFRAME":
                            global prop_ON
                            global path_ON
                            if prop_ON:
                                mode = "TUNNING_KEY"

                            elif path_ON:
                                mode = "CURVE_KEY"

                            else:
                                print("SETTING_EXIT-> IDLE (KEYFRAME MODE)")
                                bpy.data.textures['Texture.R'].image = bpy.data.images['Key-R.png']
                                bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']

                                self.action_r_index = self.getKeyframeModeAction(True)
                                self.action_l_index = self.getKeyframeModeAction(False)

                                updateKeyframeVisualization()

                                bpy.data.objects['ColorPalette'].hide = True
                                bpy.data.objects['ColorPaletteCursor'].hide = True
                                self.state = State.IDLE_KEYMODE
                                self.state_l = StateLeft.IDLE_KEYMODE

                        if mode == "CURVE_PERF":
                            print("SETTING_EXIT-> CURVE MODE")
                            bpy.data.textures['Texture.R'].image = bpy.data.images['PathPerf-R.png']
                            bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']

                            if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                                bpy.ops.object.mode_set(mode='OBJECT')
                                bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].select = True
                                bpy.context.scene.objects.active = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]
                                bpy.ops.object.mode_set(mode='EDIT')

                            #updatePropKeyframeVisualization()
                            drawActionPath(self.objToControll, self.boneToControll, True)

                            global pointIndex_r
                            global pointIndex_l
                            pointIndex_r = -1
                            pointIndex_l = -1

                            ## Delete DupliObj
                            global local_repr_ON
                            local_repr_ON = False
                            print("DEBUG [SETTING_EXIT] - Calling create_local_repre")
                            self.create_local_repr(False)
                            bpy.data.objects['ColorPalette'].hide = True
                            bpy.data.objects['ColorPaletteCursor'].hide = True

                            self.state = State.IDLE_CURVEMODE_PERF
                            self.state_l = StateLeft.IDLE_CURVEMODE

                        if mode == "CURVE_KEY":
                            print("SETTING_EXIT-> CURVE MODE(Key)")
                            bpy.data.textures['Texture.R'].image = bpy.data.images['PathKey-R.png']
                            bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']

                            if self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                                bpy.ops.object.mode_set(mode='OBJECT')
                                bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].select = True
                                bpy.context.scene.objects.active = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]
                                bpy.ops.object.mode_set(mode='EDIT')

                            updatePropKeyframeVisualization()
                            global pointIndex_r
                            global pointIndex_l
                            pointIndex_r = -1
                            pointIndex_l = -1

                            ## Delete DupliObj
                            global local_repr_ON
                            local_repr_ON = False
                            print("DEBUG [SETTING_EXIT] - Calling create_local_repre")
                            self.create_local_repr(False)
                            bpy.data.objects['ColorPalette'].hide = True
                            bpy.data.objects['ColorPaletteCursor'].hide = True

                            self.state = State.IDLE_CURVEMODE_KEY
                            self.state_l = StateLeft.IDLE_CURVEMODE

                        if mode == "TUNNING_PERF":
                            print("SETTING_EXIT-> TUNING MODE")
                            bpy.data.textures['Texture.R'].image = bpy.data.images['Perf-R.png']
                            bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']

                            ##### spostato da on Button_pressed #####
                            self.updatePropertiesList()
                            # bpy.data.objects["TextBox.005"].data.body = "Mode: PROPERTY"
                            bpy.data.objects["Text.L"].data.body = "Property:\n" + self.properties[self.prop_index]
                            self.display_colorWheel()
                            #########################################

                            #updatePropKeyframeVisualization()
                            drawActionProp(self.objToControll, self.boneToControll, True)


                            ## Delete DupliObj
                            global local_repr_ON
                            local_repr_ON = False
                            print("DEBUG [SETTING_EXIT] - Calling create_local_repre")
                            self.create_local_repr(False)

                            self.state = State.IDLE_TUNING_PERF
                            self.state_l = StateLeft.IDLE_TUNING

                        if mode == "TUNNING_KEY":
                            print("SETTING_EXIT-> TUNING MODE")
                            bpy.data.textures['Texture.R'].image = bpy.data.images['Key-R.png']
                            bpy.data.textures['Texture.L'].image = bpy.data.images['Ctrl-L.png']

                            ##### spostato da on Button_pressed #####
                            self.updatePropertiesList()
                            # bpy.data.objects["TextBox.005"].data.body = "Mode: PROPERTY"
                            bpy.data.objects["Text.L"].data.body = "Property:\n" + self.properties[
                                self.prop_index]
                            self.display_colorWheel()
                            #########################################


                            updatePropKeyframeVisualization()

                            ## Delete DupliObj
                            global local_repr_ON
                            local_repr_ON = False
                            print("DEBUG [SETTING_EXIT] - Calling create_local_repre")
                            self.create_local_repr(False)

                            self.state = State.IDLE_TUNING_KEY
                            self.state_l = StateLeft.IDLE_TUNING

                        if mode == "EDIT_ACTION":
                            print("SETTING_EXIT-> EDIT_ACTION")
                            bpy.data.textures['Texture.R'].image = bpy.data.images['EditAct.png'] # TODO: Aggiungere la texture EditAct.ong al file blender
                            bpy.data.textures['Texture.L'].image = bpy.data.images['EditAct.png'] # TODO: Aggiungere la texture EditAct.ong al file blender
                            self.action_r_index = -1
                            self.action_l_index = -1
                            recursive_delete_children()
                            drawAction(self.objToControll, self.boneToControll, True, True)
                            drawAction(self.objToControll_l, self.boneToControll_l, True, False)

                            ## Delete DupliObj
                            global local_repr_ON
                            print("DEBUG [SETTING_EXIT] - Calling create_local_repre")
                            local_repr_ON = False
                            self.create_local_repr(False)
                            bpy.data.objects['ColorPalette'].hide = True
                            bpy.data.objects['ColorPaletteCursor'].hide = True
                            self.state = State.IDLE_EDIT_ACTION
                            self.state_l = StateLeft.IDLE_EDIT_ACTION

                        if mode == "FCURVE":
                            print("SETTING_EXIT-> FCURVE")
                            bpy.data.textures['Texture.L'].image = bpy.data.images['Hand-L.png']
                            bpy.data.textures['Texture.R'].image = bpy.data.images['Hand-R.png']

                            if self.objToControll!="":
                                try:
                                    if self.boneToControll!="":
                                        curves, bones = getBoneCurves(self.objToControll, self.boneToControll)
                                        fcurves = curves[bones.index(self.boneToControll)]
                                    else:
                                        fcurves = bpy.data.objects[self.objToControll].animation_data.action.fcurves

                                    if not fcurves is None:
                                        print("DEBUG [SETTING_EXIT] - updateFrameTypeList")
                                        self.updateFrameTypeList(fcurves)
                                        print("DEBUG [SETTING_EXIT] - drawFCurve")
                                        self.drawFCurve(fcurves, True)

                                except:
                                    print("No animation_data found")

                                # Get the index of the action .KEYMODE
                                self.action_r_index = self.getKeyframeModeAction(True)
                                bpy.data.objects['F-Curve-Grid'].hide = False

                            global pointIndex_r
                            pointIndex_r = (-1,-1)

                            global local_repr_ON
                            local_repr_ON = False
                            self.create_local_repr(False)
                            bpy.data.objects['ColorPalette'].hide = True
                            bpy.data.objects['ColorPaletteCursor'].hide = True
                            recursive_delete_children()

                            print("DEBUG [SETTING_EXIT] - New state")
                            self.state = State.IDLE_F_CURVEMODE
                            self.state_l = StateLeft.IDLE_F_CURVEMODE

                        if mode == "RIGGING":
                            print("SETTING_EXIT-> RIGGING")
                            print (self.mirror_axes)
                            bpy.data.textures['Texture.R'].image = bpy.data.images['RiggingR.png']
                            bpy.data.textures['Texture.L'].image = bpy.data.images['RiggingL.png']
                            arm = None

                            print(self.objToControll)
                            if bpy.data.objects[self.objToControll].type == "ARMATURE":
                                if len(bpy.data.objects[self.objToControll].children) > 0:
                                #get the children of the armature to identify the controlled mesh
                                    self.objToControll_l = bpy.data.objects[self.objToControll].children[0].name
                                else:
                                    self.objToControll_l = ""

                                arm = bpy.data.objects[self.objToControll]

                            else:
                                bpy.data.objects[self.objToControll].select = False
                                self.objToControll_l = self.objToControll

                                if len(bpy.data.objects[self.objToControll].modifiers) > 0:
                                    for i in range (0,len(bpy.data.objects[self.objToControll].modifiers)):
                                        if bpy.data.objects[self.objToControll].modifiers[i].type=='ARMATURE':
                                            arm = bpy.data.objects[self.objToControll].modifiers[i].object
                                            break

                                if arm==None:
                                    arm = self.createArmature()

                            self.objToControll = arm.name
                            bpy.data.objects[self.objToControll].select = True
                            bpy.context.scene.objects.active = arm
                            bpy.ops.object.mode_set(mode='EDIT')


                            #Reset data structure
                            global pointIndex_r
                            pointIndex_r = (-1, -1)
                            global local_repr_ON
                            local_repr_ON = False
                            self.create_local_repr(False)
                            bpy.data.objects['ColorPalette'].hide = True
                            bpy.data.objects['ColorPaletteCursor'].hide = True
                            recursive_delete_children()
                            self.properties = ""

                            # Set new states
                            self.state = State.IDLE_RIGGING
                            self.state_l = StateLeft.IDLE_RIGGING

                        if mode == "SKINNING":
                            print("SETTING_EXIT-> SKINNING")
                            bpy.data.textures['Texture.R'].image = bpy.data.images['SkinningR.png']
                            bpy.data.textures['Texture.L'].image = bpy.data.images['Hand-L.png']

                            # prop_index = weights of the brush
                            self.prop_index = 1

                            # Reset data structure
                            global pointIndex_r
                            pointIndex_r = (-1, -1)
                            global local_repr_ON
                            local_repr_ON = False
                            self.create_local_repr(False)
                            bpy.data.objects['ColorPalette'].hide = True
                            bpy.data.objects['ColorPaletteCursor'].hide = True
                            recursive_delete_children()

                            if bpy.data.objects[self.objToControll].type == "ARMATURE":
                                #store the reference to the armature
                                self.objToControll_l = self.objToControll
                                self.boneToControll_l = self.boneToControll
                                #get the children of the armature to identify the controlled mesh
                                self.objToControll = bpy.data.objects[self.objToControll].children[0].name
                                print(self.objToControll)

                            elif bpy.data.objects[self.objToControll].type == "MESH":
                                for mod in bpy.data.objects[self.objToControll].modifiers:
                                    if mod.type == "ARMATURE":
                                        self.objToControll_l = mod.object.name
                                        self.boneToControll_l = mod.object.pose.bones[0].name

                                        bpy.data.objects[self.objToControll_l].select = True
                                        bpy.context.scene.objects.active = bpy.data.objects[self.objToControll_l]
                                        bpy.ops.object.mode_set(mode='POSE')
                                        for bone in bpy.data.objects[self.objToControll_l].data.bones:
                                            if bone.name == self.boneToControll_l:
                                                bone.select = True
                                            else:
                                                bone.select = False
                                        break

                            self.boneToControll = ""
                            bpy.data.objects[self.objToControll].select = True
                            bpy.context.scene.objects.active = bpy.data.objects[self.objToControll]
                            bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
                            # Make active the vertex group of the selected bones
                            bpy.data.objects[self.objToControll].vertex_groups.active_index = \
                                bpy.data.objects[self.objToControll].vertex_groups.find(self.boneToControll_l)
                            # Select the bone of the active vertex group
                            bpy.data.objects[self.objToControll_l].data.bones[self.boneToControll_l].select = True
                            bpy.data.objects['Brush'].hide = False

                            # Set new states
                            self.state = State.IDLE_SKINNING
                            self.state_l = StateLeft.IDLE_SKINNING

                        if mode == "CONSTRAINTS":
                            bpy.data.textures['Texture.R'].image = bpy.data.images['IK.png']
                            bpy.data.textures['Texture.L'].image = bpy.data.images['Hand-L.png']

                            # prop_index [0] = weights of the brush
                            # prop_index [1] = chian lenght of the IK
                            self.prop_index = 0

                            # Reset data structure
                            global pointIndex_r
                            pointIndex_r = (-1, -1)
                            global local_repr_ON
                            local_repr_ON = False
                            self.create_local_repr(False)
                            bpy.data.objects['ColorPalette'].hide = True
                            bpy.data.objects['ColorPaletteCursor'].hide = True
                            recursive_delete_children()

                            self.state = State.IDLE_ARM_CONSTR
                            self.state_l = StateLeft.IDLE_ARM_CONSTR

                if self.state_l == StateLeft.ON_BUTTON_PRESSED:
                    button = self.getButtonPressed(False)
                    if not "Button" in button:
                        pass
                    else:
                        if ctrl_state_l.ulButtonPressed != 8589934592:
                            print ("Button pressed")
                            button = self.getButtonPressed(False)
                            print (button)

                            # Play button
                            if button == 'Button.000':
                                #TODO: convert code below for the left controller
                                print("Not Implemented yet")
                                # global playingAnimation
                                # if not playingAnimation:
                                #     playingAnimation = True
                                #     playerSound().start()
                                #     animator(self.AppMode).start()
                                #     bpy.data.textures['Texture.Button(Play)'].image = bpy.data.images['Button(Play)_ON.png']
                                #     self.state = State.PLAY_ANIMATION

                            if button == 'Button.015':
                                bpy.ops.ed.undo()
                                print ("UNDO")

                            if button == 'Button.016':
                                bpy.ops.ed.redo()
                                print ("REDO")

                            # Rec/Play speed Button-
                            if button == 'Button.001':
                                global speedPlayRec
                                speedPlayRec = speedPlayRec/2
                                bpy.data.objects["TextBox.001"].data.body = "Record/Playback speed: " + str(speedPlayRec)
                                print ("Current Speed:",speedPlayRec )

                            # Rec/Play speed Button+
                            if button == 'Button.002':
                                global speedPlayRec
                                speedPlayRec = speedPlayRec*2
                                bpy.data.objects["TextBox.001"].data.body = "Record/Playback speed: " + str(speedPlayRec)
                                print ("Current Speed:", speedPlayRec)

                            # LOC Button
                            if button == 'Button.005':
                                global prop_ON
                                if prop_ON:
                                    prop_ON = False
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop).png']

                                global  recordMode
                                recordMode[0] = not recordMode[0]

                                recordModeString = ""
                                if recordMode[0]:
                                    recordModeString += "LOC"
                                    bpy.data.textures['TextureButton(Loc)'].image = bpy.data.images['Button(Loc)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Loc)'].image = bpy.data.images['Button(Loc).png']
                                if recordMode[1]:
                                    recordModeString += " ROT"
                                if recordMode[2]:
                                    recordModeString += " SCALE"
                                    #bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordModeString

                            # ROT Button
                            if button == 'Button.006':
                                global prop_ON
                                if prop_ON:
                                    prop_ON = False
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop).png']

                                global recordMode
                                recordMode[1] = not recordMode[1]

                                recordModeString = ""
                                if recordMode[0]:
                                    recordModeString += "LOC"
                                if recordMode[1]:
                                    recordModeString += " ROT"
                                    bpy.data.textures['TextureButton(Rot)'].image = bpy.data.images['Button(Rot)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Rot)'].image = bpy.data.images['Button(Rot).png']
                                if recordMode[2]:
                                    recordModeString += " SCALE"

                                    #bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordModeString

                                    '''
                                    global recordMode
                                    recordMode = "ROT"
                                    bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordMode
                                    '''

                            # SCALE button
                            if button == 'Button.007':
                                global prop_ON
                                if prop_ON:
                                    prop_ON = False
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop).png']

                                global recordMode
                                recordMode[2] = not recordMode[2]

                                recordModeString = ""
                                if recordMode[0]:
                                    recordModeString += "LOC"
                                if recordMode[1]:
                                    recordModeString += " ROT"
                                if recordMode[2]:
                                    recordModeString += " SCALE"
                                    bpy.data.textures['TextureButton(Scale)'].image = bpy.data.images['Button(Scale)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Scale)'].image = bpy.data.images['Button(Scale).png']

                                #bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordModeString
                                '''
                                global recordMode
                                recordMode = "LOC/ROT"
                                bpy.data.objects["TextBox.003"].data.body = "Record mode: " + recordMode
                                '''

                            # Sampling Rate Button-
                            if button == 'Button.008':
                                global samplingRate
                                if samplingRate > 1:
                                    samplingRate -= 1
                                bpy.data.objects["TextBox.004"].data.body = "Sampling Rate: " + str(samplingRate) + " fps"

                            #Sampling Rate Button+
                            if button == 'Button.009':
                                global samplingRate
                                if samplingRate <24:
                                    samplingRate += 1
                                bpy.data.objects["TextBox.004"].data.body = "Sampling Rate: " + str(samplingRate) + " fps"

                            #Performance
                            if button == "Button.010":
                                global perf_mode_ON
                                perf_mode_ON = True
                                global mode
                                mode = "ACTION"
                                self.updateButtonStatus(mode)

                            # Keyframe
                            if button == "Button.011":
                                global perf_mode_ON
                                perf_mode_ON = False
                                global mode
                                mode = "KEYFRAME"
                                self.updateButtonStatus(mode)

                            # Path
                            if button == "Button.012":
                                global path_ON
                                path_ON = not path_ON
                                if path_ON:
                                    bpy.data.textures['Texture-Path-Button'].image = bpy.data.images['Button(Path)_ON.png']

                                else:
                                    bpy.data.textures['Texture-Path-Button'].image = bpy.data.images['Button(Path).png']
                                global perf_mode_ON
                                global mode
                                if perf_mode_ON:
                                    mode = "ACTION"
                                else:
                                    mode = "KEYFRAME"

                            # Properties
                            if button == 'Button.003':
                                global prop_ON
                                prop_ON = not prop_ON

                                if prop_ON:
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop)_ON.png']
                                    global recordMode
                                    recordMode = [False, False, False]
                                    bpy.data.textures['TextureButton(Loc)'].image = bpy.data.images['Button(Loc).png']
                                    bpy.data.textures['TextureButton(Rot)'].image = bpy.data.images['Button(Rot).png']
                                    bpy.data.textures['TextureButton(Scale)'].image = bpy.data.images['Button(Scale).png']
                                else:
                                    bpy.data.textures['Texture-Prop-Button'].image = bpy.data.images['Button(Prop).png']

                                global perf_mode_ON
                                global mode
                                if perf_mode_ON:
                                    mode = "ACTION"
                                else:
                                    mode = "KEYFRAME"

                            # Local Representation
                            if button == "Button.013":
                                global local_repr_ON
                                local_repr_ON = not local_repr_ON
                                self.create_local_repr(local_repr_ON)
                                if local_repr_ON:
                                    bpy.data.textures['TextureButton(LocalRepr)'].image = bpy.data.images['Button(LocalRep)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(LocalRepr)'].image = bpy.data.images['Button(LocalRep).png']

                            # F-Curve
                            if button == "Button.014":
                                global mode
                                mode = "FCURVE"
                                self.updateButtonStatus(mode)

                            # Edit action
                            if button == 'Button.004':
                                global mode
                                mode = "EDIT_ACTION"
                                self.updateButtonStatus(mode)

                            #Rigginig
                            if button == 'Button.018':
                                print("Rigging")
                                global mode
                                mode = "RIGGING"
                                self.updateButtonStatus(mode)

                            #Skinning
                            if button == 'Button.017':
                                print("Skinning")
                                global mode
                                mode = "SKINNING"
                                self.updateButtonStatus(mode)

                            # Constraints
                            if button == 'Button.019':
                                print('Constraints')
                                global mode
                                mode = "CONSTRAINTS"
                                self.updateButtonStatus(mode)

                            # X Button
                            if button == 'Button.020':
                                self.mirror_axes[0] = not self.mirror_axes[0]
                                if self.mirror_axes[0]:
                                    bpy.data.textures['TextureButton(X)'].image = bpy.data.images['Button(X)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(X)'].image = bpy.data.images['Button(X).png']

                            # Y Button
                            if button == 'Button.021':
                                self.mirror_axes[1] = not self.mirror_axes[1]
                                if self.mirror_axes[1]:
                                    bpy.data.textures['TextureButton(Y)'].image = bpy.data.images['Button(Y)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Y)'].image = bpy.data.images['Button(Y).png']

                            # Z Button
                            if button == 'Button.022':
                                self.mirror_axes[2] = not self.mirror_axes[2]

                                if self.mirror_axes[2]:
                                    bpy.data.textures['TextureButton(Z)'].image = bpy.data.images['Button(Z)_ON.png']
                                else:
                                    bpy.data.textures['TextureButton(Z)'].image = bpy.data.images['Button(Z).png']

                            if button == 'Button.023':
                                self.arm_selection = not self.arm_selection

                                if self.arm_selection:
                                    bpy.data.textures['Texture-ArmSel-Button'].image = bpy.data.images['Button(ArmSel)_ON.png']
                                else:
                                    bpy.data.textures['Texture-ArmSel-Button'].image = bpy.data.images['Button(ArmSel).png']

                            self.state_l = StateLeft.SETTING

                if self.state_l == StateLeft.IDLE_EDIT_ACTION:
                    if self.action_l_index!=-1 and not actions is None:
                        bpy.data.objects["Text.L"].data.body = "Idle\n" + actions[self.action_l_index].name
                    else:
                        bpy.data.objects["Text.L"].data.body = "Idle\n"

                    # DECISIONAL
                    if ctrl_state_l.ulButtonPressed == 4:
                        print("IDLE (EDIT_ACTION) -> DECISIONAL")
                        self.state_l = StateLeft.DECISIONAL_EDIT_ACTION

                    # MULTIPLY/DIVIDE/MOVE actions
                    if ctrl_state_l.ulButtonPressed == 4294967296:
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y

                        if (x < 0 and y < 0):
                            print("Action x 2")
                            self.state_l = StateLeft.MULTIPLY_ACTION

                        if (x > 0 and y < 0):
                            print("Action / 2")
                            self.state_l = StateLeft.DIVIDE_ACTION

                        if (x < 0 and y > 0):
                            self.state_l = StateLeft.MOVE_LEFT
                            print ("MOVE LEFT")

                        if (x > 0 and y > 0):
                            self.state_l = StateLeft.MOVE_RIGHT
                            print ("MOVE RIGHT")

                    # SETTING
                    if (ctrl_state_l.ulButtonPressed == 2):
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE -> SETTING_ENTER")
                            self.display_menu(False)
                            self.state_l = StateLeft.SETTING_ENTER

                if self.state_l == StateLeft.DECISIONAL_EDIT_ACTION:
                    # Compute the nearest action
                    self.action_l_index = self.getClosestAction(False)

                    if ctrl_state_l.ulButtonPressed != 4:
                        print ("DEBUG [DECISIONAL_EDIT_ACTION] - index:", self.action_l_index)
                        self.state_l = StateLeft.IDLE_EDIT_ACTION
                        print ("DECISIONAL -> IDLE (EDIT_ACTION_MODE)")

                if self.state_l == StateLeft.MULTIPLY_ACTION:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        print ("DEBUG [MULTIPLY_ACTION] - action x2")
                        if self.action_l_index !=-1:
                            recursive_delete_children()
                            self.multiplyKeyframe(2,False)

                        '''
                        global mode
                        if mode == "KEYFRAME":
                            updateKeyframeVisualization()
                        '''
                        self.state_l = StateLeft.IDLE_EDIT_ACTION

                if self.state_l == StateLeft.DIVIDE_ACTION:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        print ("[DEBUG] - DIVIDE_ACTION /2")
                        if self.action_l_index!=-1:
                            recursive_delete_children()
                            self.multiplyKeyframe(0.5, False)

                        '''
                        if mode == "KEYFRAME":
                            updateKeyframeVisualization()                        
                        '''
                        self.state_l = StateLeft.IDLE_EDIT_ACTION

                if self.state_l == StateLeft.MOVE_RIGHT:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        global actions
                        print ("DEBUG [MOVE_RIGHT] - move right actions[",self.action_l_index,"]:", actions[self.action_l_index].name)
                        if self.action_l_index!=-1:
                            recursive_delete_children()
                            self.moveAction(24, False)

                        '''    
                        global mode
                        if mode == "KEYFRAME":
                            updateKeyframeVisualization()
                        '''
                        self.state_l = StateLeft.IDLE_EDIT_ACTION

                if self.state_l == StateLeft.MOVE_LEFT:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        print ("DEBUG [MOVE_LEFT] - move left")
                        if self.action_l_index != -1:
                            recursive_delete_children()
                            self.moveAction(-24, False)

                        '''
                        global mode
                        if mode == "KEYFRAME":
                            updateKeyframeVisualization()
                        '''
                        self.state_l = StateLeft.IDLE_EDIT_ACTION

                if self.state_l == StateLeft.HELP:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        self.display_objName(bpy.data.objects['_Help.001'].hide)
                        for obj in ['_Help.001','_Help.002','_Help.003','_Help.004',
                                       '_Help.005','_Help.006','_Help.007','_Help.008',
                                       '_Help.009','_Help.010','_Help.011','_Help.012']:
                            bpy.data.objects[obj].hide = not bpy.data.objects[obj].hide

                        self.state_l = StateLeft.IDLE

                if self.state_l == StateLeft.IDLE_KEYMODE:
                    bpy.data.objects["Text.L"].data.body = "Idle\n" + self.objToControll_l + "-" + self.boneToControll_l
                    tui_l.hide = True

                    # DECISIONAL
                    if (ctrl_state_l.ulButtonPressed == 4):
                        print("IDLE -> DECISIONAL")
                        print ("DECISIONAL ENTER: ", self.objToControll_l, self.boneToControll_l)
                        self.changeSelection(self.objToControll_l, self.boneToControll_l, False)
                        bpy.data.objects["Action_Text.L"].hide = True
                        self.state_l = StateLeft.DECISIONAL

                    # INTERACTION_LOCAL
                    if (ctrl_state_l.ulButtonPressed == 8589934592 and self.objToControll_l != ""):
                        print("IDLE -> INTERACTION LOCAL")
                        self.state_l = StateLeft.INTERACTION_LOCAL
                        self.curr_axes_l = 0

                        if self.boneToControll_l != "":
                            self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * \
                                              bpy.data.objects[self.objToControll_l].pose.bones[
                                                  self.boneToControll_l].matrix.to_quaternion()
                            self.diff_loc_l = bpy.data.objects[self.objToControll_l].pose.bones[
                                                  self.boneToControll_l].matrix.to_translation() - ctrl_l.location

                            self.initial_loc_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].location)
                            bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].rotation_mode = 'XYZ'
                            self.initial_rot_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].rotation_euler)
                            bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].rotation_mode = 'QUATERNION'

                        else:
                            self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * bpy.data.objects[
                                self.objToControll_l].rotation_quaternion
                            self.diff_loc_l = bpy.data.objects[self.objToControll_l].location - ctrl_l.location
                            self.initial_loc_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].location)
                            bpy.data.objects[self.objToControll_l].rotation_mode = 'XYZ'
                            self.initial_rot_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].rotation_euler)
                            bpy.data.objects[self.objToControll_l].rotation_mode = 'QUATERNION'

                    # NEXT/PREV/INSERT/DELETE FRAME
                    if ctrl_state_l.ulButtonPressed == 4294967296:
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y
                        if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                            print("NEXT")
                            bpy.context.scene.frame_current += 1
                            timeSlider.location[0]+=0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)
                            self.state_l = StateLeft.NEXT_FRAME

                        if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                            print("PREV")
                            bpy.context.scene.frame_current -= 1
                            timeSlider.location[0] -= 0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)
                            self.state_l = StateLeft.PREV_FRAME

                        if (x > 0 and y > 0 and self.objToControll_l != ""):
                            print("Increment Prop")
                            #self.state_l=StateLeft.INSERT_KEYFRAME

                        if (x < 0 and y > 0):
                            print("Decrease Prop")
                            #self.state_l= StateLeft.DELETE_KEYFRAME

                    # SETTING
                    if (ctrl_state_l.ulButtonPressed == 2):
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE (KEYFRAME MODE) -> SETTING_ENTER")
                            self.display_menu(False)
                            self.state_l = StateLeft.SETTING_ENTER

                '''
                if self.state_l == StateLeft.INSERT_KEYFRAME:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        if self.boneToControll_l != "":
                            loc = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].location)
                            rot = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].rotation_quaternion)
                            scale = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].scale)
                        else:
                            loc = copy.deepcopy(bpy.data.objects[self.objToControll_l].location)
                            rot = copy.deepcopy(bpy.data.objects[self.objToControll_l].rotation_quaternion)
                            scale = copy.deepcopy(bpy.data.objects[self.objToControll_l].scale)

                        global recordMode
                        f = Keyframe(bpy.context.scene.frame_current, rot, loc, scale, self.objToControll_l, self.boneToControll_l, recordMode)
                        insertFrame([f])
                        actions[self.action_l_index].frames += [f]

                        drawActions_Overview(currObject_l, currBone_l)
                        updateKeyframeVisualization()

                        self.state_l = StateLeft.IDLE_KEYMODE

                if self.state_l == StateLeft.DELETE_KEYFRAME:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        removeKeyFrame(bpy.context.scene.frame_current, self.objToControll_l, self.boneToControll_l)
                        drawActions_Overview(currObject_l, currBone_l)
                        updateKeyframeVisualization()
                        self.state_l = StateLeft.IDLE_KEYMODE
                '''

                if self.state_l == StateLeft.NEXT_FRAME:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        self.state_l = StateLeft.IDLE_KEYMODE

                if self.state_l == StateLeft.PREV_FRAME:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        self.state_l = StateLeft.IDLE_KEYMODE

                if self.state_l == StateLeft.IDLE_TUNING:
                    bpy.data.objects["Text.L"].data.body = "Property:\n" + self.properties[self.prop_index]

                    # SETTING
                    if ctrl_state_l.ulButtonPressed == 2:
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE (TUNING MODE) -> SETTING_ENTER")
                            self.display_menu(False)
                            self.state_l = StateLeft.SETTING_ENTER

                    # DECISIONAL
                    if ctrl_state_l.ulButtonPressed == 4:
                        print ("CHANGE PROP")
                        self.state_l = StateLeft.CHANGE_PROP

                    # TRACKPAD
                    if ctrl_state_l.ulButtonPressed == 4294967296:
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y
                        if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                            print("NEXT FRAME")
                            bpy.context.scene.frame_current += 1
                            timeSlider.location[0] += 0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                            print("PREV FRAME")
                            bpy.context.scene.frame_current -= 1
                            timeSlider.location[0] -= 0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        if (x > 0 and y > 0):
                            print ("+")
                            if 'Material_Diffuse_' in self.properties[self.prop_index] :
                                slot = int(self.properties[self.prop_index].split('Material_Diffuse_')[1])
                                mat = bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name]
                                if (mat.diffuse_color.v < 1):
                                    mat.diffuse_color.v += 0.02

                            if 'ShapeKey_' in self.properties[self.prop_index]:
                                slot = int(self.properties[self.prop_index].split('ShapeKey_')[1])
                                key = bpy.data.objects[self.objToControll].data.shape_keys.key_blocks[slot]
                                if (key.value < key.slider_max):
                                    key.value += 0.02

                            if 'Material_Alpha_' in self.properties[self.prop_index]:
                                slot = int(self.properties[self.prop_index].split('Material_Alpha_')[1])
                                mat = bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name]
                                if (mat.alpha < 1):
                                    mat.alpha += 0.02

                        if (x < 0 and y >0):
                            print ("-")
                            if 'Material_Diffuse_' in self.properties[self.prop_index]:
                                slot = int(self.properties[self.prop_index].split('Material_Diffuse_')[1])
                                mat = bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name]
                                if (mat.diffuse_color.v > 0):
                                    mat.diffuse_color.v -= 0.02

                            if 'ShapeKey_' in self.properties[self.prop_index]:
                                slot = int(self.properties[self.prop_index].split('ShapeKey_')[1])
                                key = bpy.data.objects[self.objToControll].data.shape_keys.key_blocks[slot]
                                if (key.value > key.slider_min):
                                    key.value -= 0.02

                            if 'Material_Alpha_' in self.properties[self.prop_index]:
                                slot = int(self.properties[self.prop_index].split('Material_Alpha_')[1])
                                mat = bpy.data.materials[bpy.data.objects[self.objToControll].material_slots[slot].name]
                                if (mat.alpha > 0):
                                    mat.alpha -= 0.02

                    # INTERACTION
                    if ctrl_state_l.ulButtonPressed == 8589934592:
                        if 'Material_Diffuse_' in self.properties[self.prop_index]:
                            self.state_l = StateLeft.MOVE_COLOR_CURSOR_ENTER

                if self.state_l == StateLeft.MOVE_COLOR_CURSOR_ENTER:
                    self.offesetColorCursor = ctrl_l.location - self.colorPaletteCursor.location
                    self.state_l = StateLeft.MOVE_COLOR_CURSOR

                if self.state_l == StateLeft.MOVE_COLOR_CURSOR:
                    bpy.data.objects["Text.L"].data.body = "Interaction\n" + self.objToControll + "-" + self.boneToControll + "\n[Material Diffuse]"
                    location = ctrl_l.location - self.offesetColorCursor

                    radius = (math.sqrt(pow((self.colorPalette.location[0] - location[0]), 2) +
                                        pow((self.colorPalette.location[2] - location[2]), 2)))

                    print ("DEBUG [StateLeft.MOVE_COLOR_CURSOR] - radius:", radius)
                    if radius <= self.colorPalette.dimensions[0]/2:
                        self.colorPaletteCursor.location = location

                        # radius = (math.sqrt(pow((self.colorPalette.location[0] - self.colorPaletteCursor.location[0]), 2) + pow((self.colorPalette.location[2] - self.colorPaletteCursor.location[2]), 2)))

                        normFact = self.colorPalette.dimensions[0] / 2
                        print ("DEBUG [StateLeft.MOVE_COLOR_CURSOR] - normFact:", normFact, self.colorPalette.dimensions[0])
                        x = (self.colorPaletteCursor.location[0] - self.colorPalette.location[0]) / (normFact)
                        z = (self.colorPaletteCursor.location[2] - self.colorPalette.location[2]) / (normFact)
                        print ("DEBUG [StateLeft.MOVE_COLOR_CURSOR] - x,z:", x,z)
                        phase = math.atan2(z, x)

                        saturation = radius / normFact
                        print ("DEBUG [StateLeft.MOVE_COLOR_CURSOR] - saturation:", saturation)
                        hue = ((phase / math.pi) + 1) / 2
                        slot = int(self.properties[self.prop_index].split('Material_Diffuse_')[1])
                        bpy.data.materials[
                            bpy.data.objects[self.objToControll].material_slots[slot].name].diffuse_color.h = hue
                        bpy.data.materials[
                            bpy.data.objects[self.objToControll].material_slots[slot].name].diffuse_color.s = saturation


                    if ctrl_state_l.ulButtonPressed != 8589934592:
                        self.state_l = StateLeft.IDLE_TUNING

                if self.state_l == StateLeft.CHANGE_PROP:
                    if ctrl_state_l.ulButtonPressed != 4:
                        global recordFlag
                        if not recordFlag:
                            self.prop_index +=1
                            if self.prop_index >= len(self.properties):
                                self.prop_index = 0
                            bpy.data.objects["Text.L"].data.body = "Property:\n" + self.properties[self.prop_index]
                            self.display_colorWheel()

                        self.state_l = StateLeft.IDLE_TUNING

                if self.state_l == StateLeft.IDLE_F_CURVEMODE:
                    if len(self.properties)> 0 and self.prop_index!=-1:
                        bpy.data.objects["Text.L"].data.body = "Property:\n" + self.properties[self.prop_index]
                        axes = int(self.properties[self.prop_index].split('-')[1])
                        if axes == 0:
                            bpy.data.objects["Text.L"].data.body += '\n X - Axes'
                        if axes == 1:
                            bpy.data.objects["Text.L"].data.body += '\n Y - Axes'
                        if axes == 2:
                            bpy.data.objects["Text.L"].data.body += '\n Z - Axes'
                    else:
                        bpy.data.objects["Text.L"].data.body = "Property not fount:\n"

                    # DECISIONAL
                    if ctrl_state_l.ulButtonPressed == 4 and len(self.properties)> 0 and self.prop_index!=-1:
                        print ("CHANGE PROP")
                        self.state_l = StateLeft.CHANGE_FCURVE

                    # SETTING
                    if ctrl_state_l.ulButtonPressed == 2:
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE (TUNING MODE) -> SETTING_ENTER")
                            self.display_menu(False)
                            self.drawFCurve(None, False)

                            self.state_l = StateLeft.SETTING_ENTER

                if self.state_l == StateLeft.CHANGE_FCURVE:
                    if ctrl_state_l.ulButtonPressed != 4:
                        self.drawFCurve(None, False)
                        self.prop_index += 1
                        if self.prop_index >= len(self.properties):
                            self.prop_index = 0

                        bpy.data.objects["Text.L"].data.body = "Property:\n" + self.properties[self.prop_index]
                        axes = int(self.properties[self.prop_index].split('-')[1])
                        if axes==0:
                            bpy.data.objects["Text.L"].data.body += '\n X - Axes'
                        if axes==1:
                            bpy.data.objects["Text.L"].data.body += '\n Y - Axes'
                        if axes==2:
                            bpy.data.objects["Text.L"].data.body += '\n Z - Axes'



                        if self.objToControll != "":
                            if self.boneToControll != "":
                                curves, bones = getBoneCurves(self.objToControll, self.boneToControll)
                                fcurves = curves[bones.index(self.boneToControll)]
                            else:
                                fcurves = bpy.data.objects[self.objToControll].animation_data.action.fcurves
                            self.drawFCurve(fcurves, True)

                        self.state_l = StateLeft.IDLE_F_CURVEMODE

                if self.state_l == StateLeft.IDLE_CURVEMODE:
                    bpy.data.objects["Text.L"].data.body = "Idle\n" + self.objToControll_l + "-" + self.boneToControll_l
                    tui_l.hide = True

                    '''
                    # DECISIONAL for POINTS GRABNING

                    if ctrl_state_l.ulButtonPressed == 4:
                        print("IDLE (CURVE MODE) -> DECISIONAL")
                        global pointIndex_l
                        if self.objToControll + self.boneToControll + "_PATH_OBJ" in bpy.data.objects and pointIndex_l != -1:
                            bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"].data.splines.active.points[pointIndex_l].select = False
                            print ("DEBUG [IDLE_CURVEMODE] - point deselected:")
                        self.state_l = StateLeft.DECISIONAL_CURVEMODE
                    '''

                    # INTERACTION_LOCAL
                    if ctrl_state_l.ulButtonPressed == 8589934592 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves:
                        ## PATH GRABBING
                        objCurve = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]

                        # self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * objCurve.rotation_quaternion
                        self.diff_loc_l = objCurve.location - ctrl_l.location

                        # self.offesetCurvePoint_l = objCurve.location - tui_l.location
                        self.state_l = StateLeft.INTERACTION_CURVEMODE
                        print("IDLE_CURVEMODE -> INTERACTION_CURVEMODE")

                    # NEXT/PREV/INSERT/DELETE FRAME
                    if ctrl_state_l.ulButtonPressed == 4294967296:
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y

                        if (x > 0 and y > 0 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves):
                            if bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].eval_time < \
                                    bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].path_duration:
                                bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].eval_time += 1
                                print("NEXT_EVAL_TIME")

                        if (x < 0 and y > 0 and self.objToControll + self.boneToControll + "_PATH" in bpy.data.curves):
                            if bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].eval_time > 0:
                                bpy.data.curves[self.objToControll + self.boneToControll + "_PATH"].eval_time -= 1
                                print("PREV_EVAL_TIME")

                        if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                            print("NEXT FRAME")
                            bpy.context.scene.frame_current += 1
                            timeSlider.location[0] += 0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                            print("PREV FRAME")
                            bpy.context.scene.frame_current -= 1
                            timeSlider.location[0] -= 0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)


                        '''
                        if (x > 0 and y < 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
                            print("NEXT FRAME")
                            bpy.context.scene.frame_current += 1
                            timeSlider.location[0] += 0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        if (x < 0 and y < 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
                            print("PREV FRAME")
                            bpy.context.scene.frame_current -= 1
                            timeSlider.location[0] -= 0.01
                            bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)

                        if (x > 0 and y > 0 and self.objToControll != ""):
                            print("INSERT KEYFRAME")
                            self.state_l = StateLeft.INSERT_EVAL_KEYFRAME

                        if (x < 0 and y > 0):
                            print("DELETE KEYFRAME")
                            self.state_l = StateLeft.DELETE_EVAL_KEYFRAME
                        '''

                    # SETTING
                    if (ctrl_state_l.ulButtonPressed == 2):
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE (KEYFRAME MODE) -> SETTING_ENTER")
                            self.display_menu(False)
                            self.state_l = StateLeft.SETTING_ENTER

                if self.state_l == StateLeft.DECISIONAL_CURVEMODE:
                    print ("DEBUG [DECISIONAL_CURVEMODE] - DECISIONAL")

                    # Compute the nearest object
                    global pointIndex_l
                    try:
                        pointIndex_l = self.getClosestPoint(False)
                    except:
                        print("Error during selection")

                    print ("DEBUG [DECISIONAL_CURVEMODE] - point_index_l:", pointIndex_l)

                    if ctrl_state_l.ulButtonPressed != 4:
                        # Select the new point
                        if pointIndex_l != -1:
                            bpy.data.objects[
                                self.objToControll + self.boneToControll + "_PATH_OBJ"].data.splines.active.points[
                                pointIndex_l].select = True
                            print ("DEBUG [DECISIONAL_CURVEMODE] - FINAL point_index_l:", pointIndex_l)
                        self.state_l = StateLeft.IDLE_CURVEMODE

                if self.state_l == StateLeft.INTERACTION_CURVEMODE:
                    print ("INTERACTION")
                    objCurve = bpy.data.objects[self.objToControll + self.boneToControll + "_PATH_OBJ"]

                    ## PATH GRABBING
                    # objCurve.rotation_quaternion = ctrl_l.rotation_quaternion * self.diff_rot_l
                    objCurve.location = ctrl_l.location + self.diff_loc_l

                    if (ctrl_state_l.ulButtonPressed != 8589934592):
                        self.state_l = StateLeft.IDLE_CURVEMODE

                if self.state_l == StateLeft.IDLE_RIGGING:
                    bpy.data.objects["Text.L"].data.body = "Idle\n" + self.objToControll_l + "-" + self.boneToControll_l

                    # SETTING
                    if ctrl_state_l.ulButtonPressed == 2:
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE (RIGGING MODE) -> SETTING_ENTER")
                            self.display_menu(False)
                            self.drawFCurve(None, False)

                            self.boneToControll = ""
                            bpy.ops.object.mode_set(mode='OBJECT')
                            bpy.data.objects[self.objToControll].select = False

                            self.objToControll = self.objToControll_l
                            bpy.data.objects[self.objToControll].select = True
                            bpy.context.scene.objects.active = bpy.data.objects[self.objToControll]

                            self.state_l = StateLeft.SETTING_ENTER

                    # DECISIONAL
                    if (ctrl_state_l.ulButtonPressed == 4):
                        print("IDLE -> DECISIONAL")
                        print ("DECISIONAL ENTER: ", self.objToControll_l, self.boneToControll_l)
                        #self.changeSelection(self.objToControll_l, self.boneToControll_l, False)
                        #drawAction(self.objToControll_l, self.boneToControll_l, False, False)
                        self.state_l = StateLeft.DECISIONAL

                    # TRACKPAD
                    if ctrl_state_l.ulButtonPressed == 4294967296:
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y

                        if x > 0 and y > 0:
                            self.state_l = StateLeft.RIGGING_ARMATURE_AUTO

                        if x < 0 and y > 0:
                            self.state_l = StateLeft.RIGGING_ARMATURE_EMPTY

                        if x > 0 and y < 0:
                            print ("split bone")
                            self.state_l = StateLeft.SUBDIVIDE_BONE

                        if x < 0 and y < 0:
                            print ("Toogle Connected")
                            self.state_l = StateLeft.TOOGLE_CONNECTION_BONE

                if self.state_l == StateLeft.TOOGLE_CONNECTION_BONE:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        global pointIndex_r
                        if pointIndex_r[0] != -1 and bpy.data.objects[self.objToControll].data.edit_bones[pointIndex_r[0]].parent != None:
                            bpy.data.objects[self.objToControll].data.edit_bones[pointIndex_r[0]].use_connect = not bpy.data.objects[self.objToControll].data.edit_bones[pointIndex_r[0]].use_connect

                        self.state_l = StateLeft.IDLE_RIGGING

                if self.state_l == StateLeft.SUBDIVIDE_BONE:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        bpy.ops.armature.subdivide()
                        bpy.data.objects[self.objToControll].data.edit_bones[-1].select = False
                        bpy.data.objects[self.objToControll].data.edit_bones[-1].select_head = False
                        bpy.data.objects[self.objToControll].data.edit_bones[-1].select_tail = False
                        self.state_l = StateLeft.IDLE_RIGGING

                if self.state_l == StateLeft.RIGGING_ARMATURE_AUTO:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        if self.objToControll_l != "":
                            print ("Create armature with Automatic weights")
                            a = bpy.data.objects[self.objToControll_l]
                            b = bpy.data.objects[self.objToControll]
                            bpy.ops.object.mode_set(mode='OBJECT')
                            # Select object in the correct order
                            a.select = True
                            b.select = True # select the object for the 'parenting'
                            bpy.context.scene.objects.active = b  # the active object will be the parent of all selected object
                            bpy.ops.object.parent_set(type='ARMATURE_AUTO')
                            bpy.ops.object.mode_set(mode='OBJECT')
                            a.select = False
                            bpy.ops.object.mode_set(mode='EDIT')
                            winsound.Beep(440, 500)
                            print("FINISHED")
                        else:
                            print("[DEBUG] - RIGGING_ARMATURE_AUTO: No mesh selected ")

                        self.state_l = StateLeft.IDLE_RIGGING

                if self.state_l == StateLeft.RIGGING_ARMATURE_EMPTY:
                    if ctrl_state_l.ulButtonPressed != 4294967296:
                        if self.objToControll_l != "":
                            print ("Create armature with Emtpy group")
                            a = bpy.data.objects[self.objToControll_l]
                            b = bpy.data.objects[self.objToControll]
                            bpy.ops.object.mode_set(mode='OBJECT')
                            # Select object in the correct order
                            a.select = True
                            b.select = True  # select the object for the 'parenting'
                            bpy.context.scene.objects.active = b  # the active object will be the parent of all selected object
                            bpy.ops.object.parent_set(type='ARMATURE_NAME')
                            bpy.ops.object.mode_set(mode='OBJECT')
                            a.select = False
                            bpy.ops.object.mode_set(mode='EDIT')
                            winsound.Beep(440, 500)
                            print("FINISHED")
                        else:
                            print("[DEBUG] - RIGGING_ARMATURE_EMPTY: No mesh selected ")

                        self.state_l = StateLeft.IDLE_RIGGING

                if self.state_l == StateLeft.IDLE_SKINNING:
                    bpy.data.objects["Text.L"].data.body = "Idle\n" + self.objToControll_l + "-" + self.boneToControll_l

                    # SETTING
                    if ctrl_state_l.ulButtonPressed == 2:
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE (RIGGING MODE) -> SETTING_ENTER")
                            self.display_menu(False)
                            self.drawFCurve(None, False)
                            bpy.data.objects['Brush'].hide = True

                            bpy.ops.object.mode_set(mode='OBJECT')
                            bpy.data.objects[self.objToControll].select = False
                            self.objToControll = self.objToControll_l
                            self.boneToControll = ""
                            bpy.data.objects[self.objToControll].select = True
                            bpy.context.scene.objects.active = bpy.data.objects[self.objToControll]

                            self.state_l = StateLeft.SETTING_ENTER

                    # DECISIONAL
                    if ctrl_state_l.ulButtonPressed == 4 and len(bpy.data.objects[self.objToControll].vertex_groups)>0:
                        print("DECISIONAL")

                    # TRACKPAD
                    if ctrl_state_l.ulButtonPressed == 4294967296:
                        x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y

                    # INTERACTION_LOCAL
                    if (ctrl_state_l.ulButtonPressed == 8589934592 and self.objToControll_l != ""):
                        print("IDLE -> INTERACTION LOCAL")
                        self.state_l = StateLeft.INTERACTION_LOCAL
                        self.curr_axes_l = 0

                        if self.boneToControll_l != "":
                            self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * \
                                              bpy.data.objects[self.objToControll_l].pose.bones[
                                                  self.boneToControll_l].matrix.to_quaternion()
                            self.diff_loc_l = bpy.data.objects[self.objToControll_l].pose.bones[
                                                  self.boneToControll_l].matrix.to_translation() - ctrl_l.location
                            self.initial_loc_l = copy.deepcopy(
                                bpy.data.objects[self.objToControll_l].pose.bones[self.boneToControll_l].location)
                            bpy.data.objects[self.objToControll_l].pose.bones[
                                self.boneToControll_l].rotation_mode = 'XYZ'
                            self.initial_rot_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].pose.bones[
                                                                   self.boneToControll_l].rotation_euler)
                            bpy.data.objects[self.objToControll_l].pose.bones[
                                self.boneToControll_l].rotation_mode = 'QUATERNION'

                        else:
                            self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * bpy.data.objects[
                                self.objToControll_l].rotation_quaternion
                            self.diff_loc_l = bpy.data.objects[self.objToControll_l].location - ctrl_l.location
                            self.initial_loc_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].location)
                            bpy.data.objects[self.objToControll_l].rotation_mode = 'XYZ'
                            self.initial_rot_l = copy.deepcopy(
                                bpy.data.objects[self.objToControll_l].rotation_euler)
                            bpy.data.objects[self.objToControll_l].rotation_mode = 'QUATERNION'

                if self.state_l == StateLeft.IDLE_ARM_CONSTR:
                    # SETTING
                    if (ctrl_state_l.ulButtonPressed == 2):
                        global playingAnimation
                        if not playingAnimation:
                            print ("IDLE -> SETTING_ENTER")
                            self.display_menu(False)
                            self.state_l = StateLeft.SETTING_ENTER


            # elif self.AppMode == "GEOMETRY_VR":
            #
            #     self.setController(self.ctrl_index_r)
            #     # ctrl_state contains the value of the button
            #     idx, ctrl_state = openvr.IVRSystem().getControllerState(self.ctrl_index_r)
            #     idx_l, ctrl_state_l = openvr.IVRSystem().getControllerState(self.ctrl_index_l)
            #
            #     ctrl = bpy.data.objects['Controller.R']
            #     ctrl_l = bpy.data.objects['Controller.L']
            #     tui = bpy.data.objects['TUI.R']
            #     tui_l = bpy.data.objects['TUI.L']
            #
            #     pointer = bpy.data.objects['SelectedObj']
            #     camera = bpy.data.objects['Camera']
            #
            #     timeSlider = bpy.data.objects['TimelineSlider']
            #
            #     ########## Right_Controller_States ##########
            #
            #     if self.state == State.IDLE:
            #         bpy.data.objects["Text.R"].data.body =  self.objToControll + "-" + self.boneToControll
            #         tui.hide = True
            #
            #         # DECISIONAL
            #         if (ctrl_state.ulButtonPressed == 4):
            #             print("IDLE -> DECISIONAL")
            #             self.changeSelection(self.objToControll, self.boneToControll, False)
            #             drawAction(self.objToControll, self.boneToControll, False, True)
            #             self.state = State.DECISIONAL
            #
            #         # INTERACTION_LOCAL
            #         if (ctrl_state.ulButtonPressed == 8589934592 and self.objToControll != ""):
            #             print("IDLE -> INTERACTION LOCAL")
            #             self.state = State.INTERACTION_LOCAL
            #             self.curr_axes_r = 0
            #
            #             if self.boneToControll != "":
            #                 self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].matrix.to_quaternion()
            #                 self.diff_loc = bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].matrix.to_translation() - ctrl.location
            #                 self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].location)
            #                 bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'XYZ'
            #                 self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_euler)
            #                 bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].rotation_mode = 'QUATERNION'
            #
            #             else:
            #                 self.diff_rot = ctrl.rotation_quaternion.inverted() * bpy.data.objects[self.objToControll].rotation_quaternion
            #                 self.diff_loc = bpy.data.objects[self.objToControll].location - ctrl.location
            #                 self.initial_loc = copy.deepcopy(bpy.data.objects[self.objToControll].location)
            #                 bpy.data.objects[self.objToControll].rotation_mode = 'XYZ'
            #                 self.initial_rot = copy.deepcopy(bpy.data.objects[self.objToControll].rotation_euler)
            #                 bpy.data.objects[self.objToControll].rotation_mode = 'QUATERNION'
            #
            #         # PLAY/RECORD
            #         if ctrl_state.ulButtonPressed == 4294967296:
            #             x,y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
            #             if y < 0 and x > 0:
            #                 print("PLAY BUTTON")
            #                 '''
            #                 self.state = State.START_ANIMATION
            #                 '''
            #
            #             if y < 0 and x < 0:
            #                 print("RECORD")
            #                 '''
            #                 global recordFlag
            #                 if not recordFlag:
            #                     self.state = State.START_RECORD
            #                 else:
            #                     self.state = State.END_RECORD
            #                 '''
            #
            #             if (x > 0 and y > 0 and bpy.context.scene.frame_current < bpy.data.scenes[0].frame_end):
            #                 print("NEXT FRAME")
            #                 '''
            #                 bpy.context.scene.frame_current += 1
            #                 timeSlider.location[0] += 0.01
            #                 bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)
            #                 '''
            #
            #             if (x < 0 and y > 0 and bpy.context.scene.frame_current > bpy.data.scenes[0].frame_start):
            #                 print("PREV FRAME")
            #                 '''
            #                 bpy.context.scene.frame_current -= 1
            #                 timeSlider.location[0] -= 0.01
            #                 bpy.data.objects["TextBox.000"].data.body = "Frame: " + str(bpy.context.scene.frame_current)
            #                 '''
            #
            #         # NAVIGATION
            #         if ctrl_state.ulButtonPressed == 2:
            #             print("IDLE -> NAVIGATION")
            #             self.state = State.NAVIGATION_ENTER
            #
            #     #2# Codice aggiunto per evidenziare gli oggetti selezionati
            #     if self.state == State.DECISIONAL:
            #         # Aggiorno le indicazioni fornite ai lati del controller
            #         bpy.data.objects["Text.R"].data.body = "Selezione\n " + self.objToControll + "-" + self.boneToControll
            #         tui.hide = False
            #         pointer.hide = False
            #
            #         # Calcolo l'oggetto piu' vicino al controller
            #         try:
            #             self.objToControll, self.boneToControll = self.getClosestItem(pointer,True)
            #         except:
            #             print("Error during selection")
            #             playerSound().start()
            #         global currObject
            #         global currBone
            #         currObject = self.objToControll
            #         currBone = self.boneToControll
            #
            #
            #         if ctrl_state.ulButtonPressed != 4: # Appena viene rilasciato il gripper
            #             # Aggiorno le stutture dati che contengo i riferimenti all'oggetto selezionato
            #             self.changeSelection(self.objToControll, self.boneToControll, True)
            #             drawAction(self.objToControll, self.boneToControll, True, True)
            #             drawAction(self.objToControll_l, self.boneToControll_l, True, False)
            #             pointer.hide = True
            #
            #             #2# - - - - - - - - - - - - righe da aggiungere - - - - - - - - - - - - #2#
            #             # verifico che l'oggetto selezionato abbia un materiale da poter modificare
            #             if currObject != "" and len(bpy.data.objects[currObject].data.materials)>0:
            #                 # verifico che il materiale rispetti alcuni vincolo (es. nome e colore)
            #                 if bpy.data.objects[currObject].material_slots[0].material.diffuse_color[0] <= 0.25 and \
            #                         'Materiale-Elemento-Selezionabile' in bpy.data.objects[currObject].material_slots[0].name:
            #                     # Aggisco su un canale di colore (rosso) modificandone l'intensita'
            #                     bpy.data.objects[currObject].material_slots[0].material.diffuse_color[0] = 1
            #
            #                 #ripeto gli stessi controlli/passaggi per deselezionare il solido
            #                 elif bpy.data.objects[currObject].material_slots[0].material.diffuse_color[0] >= 0.95 and \
            #                         'Materiale-Elemento-Selezionabile' in bpy.data.objects[currObject].material_slots[0].name:
            #                     bpy.data.objects[currObject].material_slots[0].material.diffuse_color[0] = 0.2
            #             #2# - - - - - - - - - - - - righe da aggiungere - - - - - - - - - - - - #2#
            #
            #             global mode
            #             if mode == "ACTION":
            #                 print ("DECISIONAL -> IDLE")
            #                 self.state = State.IDLE
            #
            #     if self.state == State.INTERACTION_LOCAL:
            #         bpy.data.objects["Text.R"].data.body = "Interazione\n" + self.objToControll + "-" + self.boneToControll + "\n" + self.axes[self.curr_axes_r]
            #         tui.hide = True
            #         pointer.hide = True
            #
            #         ## Controll object scale
            #         if self.objToControll == self.objToControll_l and self.boneToControll == self.boneToControll_l and ctrl_state_l.ulButtonPressed == 8589934592:
            #             if self.boneToControll!="":
            #                 self.initial_scale = copy.deepcopy(bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale)
            #             else:
            #                 self.initial_scale = copy.deepcopy(bpy.data.objects[self.objToControll].scale)
            #
            #             self.diff_distance = self.computeTargetObjDistance("TUI.L", "", True)
            #
            #             self.state = State.SCALING
            #             self.state_l = StateLeft.SCALING
            #
            #         else:
            #             if self.boneToControll != "":
            #                 ## The object to move is a bone
            #                 bone = bpy.data.objects[self.objToControll]
            #                 pbone = bone.pose.bones[self.boneToControll]
            #                 scale = copy.deepcopy(pbone.scale)
            #                 translationMatrix = Matrix(((0.0, 0.0, 0.0, self.diff_loc[0]),
            #                                             (0.0, 0.0, 0.0, self.diff_loc[1]),
            #                                             (0.0, 0.0, 0.0, self.diff_loc[2]),
            #                                             (0.0, 0.0, 0.0, 1.0)))
            #                 diff_rot_matr = self.diff_rot.to_matrix()
            #                 pbone.matrix = (ctrl.matrix_world + translationMatrix) * diff_rot_matr.to_4x4()
            #                 pbone.scale = scale
            #
            #                 self.applyConstraint(True)
            #
            #                 global local_repr_ON
            #                 if local_repr_ON and '_Local.Repr' in self.objToControll:
            #                     #Copy location and rotation to the target bone
            #                     pboneTarget = bpy.data.objects[self.objToControll.split('_Local.Repr')[0]].pose.bones[self.boneToControll]
            #                     pboneTarget.rotation_quaternion = copy.deepcopy(pbone.rotation_quaternion)
            #                     pboneTarget.location = copy.deepcopy(pbone.location)
            #
            #             else:
            #                 ## The object to move is a mesh
            #                 bpy.data.objects[self.objToControll].rotation_quaternion = ctrl.rotation_quaternion * self.diff_rot
            #                 bpy.data.objects[self.objToControll].location = ctrl.location + self.diff_loc
            #
            #                 self.applyConstraint(True)
            #
            #                 global local_repr_ON
            #                 if local_repr_ON and '_Local.Repr' in self.objToControll:
            #                     objTarget = bpy.data.objects[self.objToControll.split('_Local.Repr')[0]]
            #                     objTarget.rotation_quaternion = bpy.data.objects[self.objToControll].rotation_quaternion
            #
            #
            #         if (ctrl_state.ulButtonPressed==8589934596):
            #             print("INTERACTION_LOCAL -> CHANGE_AXIS")
            #             self.state = State.CHANGE_AXES
            #
            #         if (ctrl_state.ulButtonPressed != 8589934592 and ctrl_state.ulButtonPressed != 8589934596):
            #             # print("grillet released")
            #             global mode
            #             if mode == "ACTION":
            #                 self.state = State.IDLE
            #                 print ("INTERACTION_LOCAL -> IDLE")
            #             if mode == "KEYFRAME":
            #                 self.state = State.IDLE_KEYMODE
            #                 print ("INTERACTION_LOCAL -> IDLE (KEY MODE)")
            #             if mode == "TUNNING_PERF":
            #                 self.state = State.IDLE_TUNING_PERF
            #                 print ("INTERACTION_LOCAL -> IDLE (TUNNING PERF)")
            #             if mode == "TUNING_KEY":
            #                 self.state = State.IDLE_TUNING_KEY
            #                 print ("INTERACTION_LOCAL -> IDLE (TUNNING KEY)")
            #
            #     if self.state == State.NAVIGATION_ENTER:
            #         tui.hide = True
            #         pointer.hide = True
            #         bpy.data.objects["Text.R"].data.body = "Navigazione\n "
            #         bpy.data.objects["Text.L"].data.body = "Navigazione\n "
            #         if ctrl_state.ulButtonPressed != 2:
            #             bpy.data.textures['Texture.R'].image = bpy.data.images['Nav-R.png']
            #             bpy.data.textures['Texture.L'].image = bpy.data.images['Hand-L.png']
            #             self.state = State.NAVIGATION
            #             self.state_l = StateLeft.NAVIGATION
            #
            #     if self.state == State.NAVIGATION_EXIT:
            #         if ctrl_state.ulButtonPressed != 2:
            #             print("NAVIGATION -> IDLE")
            #             if not bpy.data.objects['SettingsPanel'].hide:
            #                 bpy.data.textures['Texture.R'].image = bpy.data.images['Sett-R.png']
            #                 bpy.data.objects[
            #                     "Text.R"].data.body = self.objToControll + "-" + self.boneToControll
            #                 bpy.data.objects[
            #                     "Text.L"].data.body = self.objToControll_l + "-" + self.boneToControll_l
            #
            #                 self.state = State.SETTING
            #                 self.state_l = StateLeft.SETTING
            #             else:
            #                 global mode  # 'ACTION', 'KEYFRAME', 'CURVE', 'TUNING', 'EDIT_ACTION'
            #                 if mode == "ACTION":
            #                     print("NAVIGATION -> IDLE")
            #                     bpy.data.textures['Texture.R'].image = bpy.data.images['Hand-R.png']
            #                     bpy.data.textures['Texture.L'].image = bpy.data.images['GEO-Left.png']
            #                     self.state = State.IDLE
            #                     self.state_l = StateLeft.IDLE
            #
            #     if self.state == State.NAVIGATION:
            #         if ctrl_state.ulButtonPressed == 4294967296:
            #             x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
            #             if (x > -0.3 and x < 0.3 and y < -0.8):
            #                 print("ZOOM_OUT")
            #                 camObjDist = bpy.data.objects["Origin"].location - camera.location
            #                 if self.objToControll != "":
            #                     camObjDist = bpy.data.objects[self.objToControll].location - camera.location
            #                 camera.location -= camObjDist
            #
            #                 scale_factor = camera.scale[0]
            #                 scale_factor = scale_factor * 2
            #                 camera.scale = Vector((scale_factor, scale_factor, scale_factor))
            #                 bpy.data.objects["Text.R"].scale = Vector((scale_factor, scale_factor, scale_factor))
            #                 bpy.data.objects["Text.L"].scale = Vector((scale_factor, scale_factor, scale_factor))
            #                 self.zoom = scale_factor
            #                 self.state = State.ZOOM_IN
            #
            #             if (x > -0.3 and x < 0.3 and y > 0.8):
            #                 print("ZOOM_IN")
            #                 camObjDist = bpy.data.objects["Origin"].location - camera.location
            #                 if self.objToControll != "":
            #                     camObjDist = bpy.data.objects[self.objToControll].location - camera.location
            #                 camObjDist = camObjDist / 2
            #                 camera.location += camObjDist
            #
            #                 scale_factor = camera.scale[0]
            #                 scale_factor = scale_factor / 2
            #                 camera.scale = Vector((scale_factor, scale_factor, scale_factor))
            #                 bpy.data.objects["Text.R"].scale = Vector((scale_factor, scale_factor, scale_factor))
            #                 bpy.data.objects["Text.L"].scale = Vector((scale_factor, scale_factor, scale_factor))
            #                 self.zoom = scale_factor
            #                 self.state = State.ZOOM_OUT
            #
            #         if (ctrl_state.ulButtonPressed == 4):
            #             self.diff_loc = copy.deepcopy(ctrl.location)
            #             self.state = State.CAMERA_MOVE_CONT
            #
            #         if (ctrl_state.ulButtonPressed == 2):
            #             self.state = State.NAVIGATION_EXIT
            #
            #     if self.state == State.ZOOM_IN:
            #         if (ctrl_state.ulButtonPressed != 4294967296):
            #             self.state = State.NAVIGATION
            #
            #     if self.state == State.ZOOM_OUT:
            #         if (ctrl_state.ulButtonPressed != 4294967296):
            #             self.state = State.NAVIGATION
            #
            #     if self.state == State.CAMERA_MOVE_CONT:
            #         camera.location = camera.location + (self.diff_loc - ctrl.location)
            #         if (ctrl_state.ulButtonPressed != 4):
            #             self.state = State.NAVIGATION
            #
            #     if self.state == State.START_RECORD:
            #         if ctrl_state.ulButtonPressed != 4294967296:
            #             global playingAnimation
            #             if not playingAnimation:
            #                 global recordFlag
            #                 recordFlag = True
            #                 recorder(0,self.AppMode).start()
            #                 playerSound().start()
            #                 self.state = State.IDLE
            #             else:
            #                 print ("The system is already playing an animation")
            #
            #     if self.state == State.END_RECORD:
            #         if ctrl_state.ulButtonPressed != 4294967296:
            #             global recordFlag
            #             recordFlag = False
            #             playerSound().start()
            #             self.state = State.IDLE
            #
            #     if self.state == State.START_ANIMATION:
            #         print ("START_ANIMATION")
            #         if ctrl_state.ulButtonPressed != 4294967296:
            #             global playingAnimation
            #
            #             if not playingAnimation:
            #                 global recordFlag
            #                 if not recordFlag:
            #                     playingAnimation = True
            #                     playerSound().start()
            #                     animator(self.AppMode).start()
            #                     bpy.data.textures['Texture.R'].image = bpy.data.images['GEO-Right-anim.png']
            #                 else:
            #                     print("The system is already recording")
            #
            #             self.state = State.PLAY_ANIMATION
            #
            #     if self.state == State.PLAY_ANIMATION:
            #         print ("PLAYING ANIMATION")
            #         global playingAnimation
            #         if not playingAnimation:
            #             if bpy.data.objects['SettingsPanel'].hide:
            #                 global mode
            #                 if mode == "ACTION":
            #                     self.state = State.IDLE
            #             else:
            #                 self.state = State.SETTING
            #         else:
            #             if ctrl_state.ulButtonPressed == 4294967296:
            #                 x, y = ctrl_state.rAxis[0].x, ctrl_state.rAxis[0].y
            #                 if y < 0 and x > 0:
            #                     self.state = State.STOP_ANIMATION
            #
            #     if self.state == State.STOP_ANIMATION:
            #         print ("STOP STATE")
            #         if ctrl_state.ulButtonPressed != 4294967296:
            #             global playingAnimation
            #             playingAnimation = False
            #             playerSound().start()
            #             self.state = State.PLAY_ANIMATION
            #             print ("STOP -> PLAY ANIMATION")
            #
            #     if self.state == State.SCALING:
            #         currDist = self.computeTargetObjDistance("TUI.L", "", True)
            #         offset = (currDist - self.diff_distance)/5
            #         if self.boneToControll!="":
            #             bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale = self.initial_scale
            #             bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale[0] += offset
            #             bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale[1] += offset
            #             bpy.data.objects[self.objToControll].pose.bones[self.boneToControll].scale[2] += offset
            #
            #         else:
            #             bpy.data.objects[self.objToControll].scale = self.initial_scale
            #             bpy.data.objects[self.objToControll].scale[0] += offset
            #             bpy.data.objects[self.objToControll].scale[1] += offset
            #             bpy.data.objects[self.objToControll].scale[2] += offset
            #
            #         #Exit from Scaling state
            #         if (ctrl_state.ulButtonPressed != 8589934592):
            #             if (ctrl_state_l.ulButtonPressed != 8589934592):
            #                 global mode
            #                 if mode == "ACTION":
            #                     self.state = State.IDLE
            #                     self.state_l = StateLeft.IDLE
            #                     print ("SCALING -> IDLE")
            #
            #     if self.state == State.CHANGE_AXES:
            #         if (ctrl_state.ulButtonPressed==8589934592):
            #             self.curr_axes_r+=1
            #             if self.curr_axes_r>=len(self.axes):
            #                 self.curr_axes_r=0
            #             self.curr_axes_l = 0
            #             print(self.curr_axes_r)
            #             print("CHANGE_AXIS -> INTERACTION_LOCAL")
            #             self.state = State.INTERACTION_LOCAL
            #
            #         if (ctrl_state.ulButtonPressed==0):
            #             # print("grillet released")
            #             global mode
            #             if mode == "ACTION":
            #                 self.state = State.IDLE
            #                 print ("CHANGE_AXIS -> IDLE")
            #
            #
            #     ########## Left_Controller_States ##########
            #
            #     if self.state_l == StateLeft.IDLE:
            #         bpy.data.objects["Text.L"].data.body = self.objToControll_l + "-" + self.boneToControll_l + "\n" + self.getOperatorStringFormIndex(self.prop_index)
            #         tui_l.hide = True
            #
            #         ## Trackpad
            #         if ctrl_state_l.ulButtonPressed == 4294967296:
            #             x, y = ctrl_state_l.rAxis[0].x, ctrl_state_l.rAxis[0].y
            #             #3# - - - - - - - - - - - - righe da aggiungere - - - - - - - - - - - - #3#
            #             if (y < 0):
            #                 # Attivare lo stato che si occupa di applicare l'operatore booleano selezionato
            #                 self.state_l = StateLeft.APPLY_BOOL_OPERATION
            #             if (y > 0 and x > 0):
            #                 # Attivare lo stato che si occupa di modificare l'operatore booleano corrente
            #                 self.state_l = StateLeft.INCREASE_OPERATOR
            #             if (y > 0 and x < 0):
            #                 # Attivare lo stato che si occupa di modificare l'operatore booleano corrente
            #                 self.state_l = StateLeft.DECREASE_OPERATOR
            #             #3# - - - - - - - - - - - - righe da aggiungere - - - - - - - - - - - - #3#
            #
            #         # Grip Button
            #         if (ctrl_state_l.ulButtonPressed == 4):
            #             print("IDLE -> DECISIONAL")
            #             print ("DECISIONAL ENTER: ", self.objToControll_l, self.boneToControll_l)
            #             self.changeSelection(self.objToControll_l, self.boneToControll_l, False)
            #             drawAction(self.objToControll_l, self.boneToControll_l, False, False)
            #             self.state_l = StateLeft.DECISIONAL
            #
            #         # Trigger
            #         if (ctrl_state_l.ulButtonPressed == 8589934592 and self.objToControll_l != ""):
            #             print("IDLE -> INTERACTION LOCAL")
            #             self.state_l = StateLeft.INTERACTION_LOCAL
            #             self.curr_axes_l = 0
            #
            #             if self.boneToControll_l != "":
            #                 self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * \
            #                                   bpy.data.objects[self.objToControll_l].pose.bones[
            #                                       self.boneToControll_l].matrix.to_quaternion()
            #                 self.diff_loc_l = bpy.data.objects[self.objToControll_l].pose.bones[
            #                                       self.boneToControll_l].matrix.to_translation() - ctrl_l.location
            #                 self.initial_loc_l = copy.deepcopy(
            #                     bpy.data.objects[self.objToControll_l].pose.bones[
            #                         self.boneToControll_l].location)
            #                 bpy.data.objects[self.objToControll_l].pose.bones[
            #                     self.boneToControll_l].rotation_mode = 'XYZ'
            #                 self.initial_rot_l = copy.deepcopy(
            #                     bpy.data.objects[self.objToControll_l].pose.bones[
            #                         self.boneToControll_l].rotation_euler)
            #                 bpy.data.objects[self.objToControll_l].pose.bones[
            #                     self.boneToControll_l].rotation_mode = 'QUATERNION'
            #
            #             else:
            #                 self.diff_rot_l = ctrl_l.rotation_quaternion.inverted() * bpy.data.objects[
            #                     self.objToControll_l].rotation_quaternion
            #                 self.diff_loc_l = bpy.data.objects[self.objToControll_l].location - ctrl_l.location
            #                 self.initial_loc_l = copy.deepcopy(bpy.data.objects[self.objToControll_l].location)
            #                 bpy.data.objects[self.objToControll_l].rotation_mode = 'XYZ'
            #                 self.initial_rot_l = copy.deepcopy(
            #                     bpy.data.objects[self.objToControll_l].rotation_euler)
            #                 bpy.data.objects[self.objToControll_l].rotation_mode = 'QUATERNION'
            #
            #     #3# Codice aggiunto per utilizzare gli operatori booleani
            #     #3# - - - - - - - - - - - - righe da aggiungere - - - - - - - - - - - - #3#
            #     if self.state_l == StateLeft.APPLY_BOOL_OPERATION:
            #         if ctrl_state_l.ulButtonPressed != 4294967296:
            #             if currObject!="" and currObject_l!="":
            #                 # settare come elemento attivo l'oggetto selzionato con il controller sinistro (vincolo di Blender)
            #                 bpy.context.scene.objects.active = bpy.data.objects[currObject_l]
            #                 bpy.data.objects[currObject_l].select = True
            #                 index = -1
            #                 # Aggiungo all'elemento attivo un modificatore di tipo Boolean che mi consetira' di effeture l'operazione richiesta
            #                 if len(bpy.data.objects[currObject_l].modifiers) > 0:
            #                     for i in range(0, len(bpy.data.objects[currObject_l].modifiers)):
            #                         if bpy.data.objects[currObject_l].modifiers[i].type == 'BOOLEAN':
            #                             bpy.data.objects[currObject_l].modifiers[i]
            #                             index = i
            #
            #                 if index == -1:
            #                     bpy.ops.object.modifier_add(type='BOOLEAN')
            #                     index = len(bpy.data.objects[currObject_l].modifiers) - 1
            #
            #                 # Configuro l'operatore booleano
            #                 bpy.data.objects[currObject_l].modifiers[index].name = "BooleanExercise"
            #                 bpy.data.objects[currObject_l].modifiers[index].object = bpy.data.objects[currObject]
            #                 bpy.data.objects[currObject_l].modifiers[index].operation = self.getOperatorFormIndex(self.prop_index)
            #                 # Applico l'operazione
            #                 bpy.ops.object.modifier_apply(modifier="BooleanExercise")
            #
            #             self.state_l = StateLeft.IDLE
            #
            #     if self.state_l == StateLeft.INCREASE_OPERATOR:
            #         if ctrl_state_l.ulButtonPressed != 4294967296:
            #             # Modifico l'operazione booleana che verra' applicata scorrendo verso destra la lista delle possibili operazioni
            #             if self.prop_index >= 2:
            #                 self.prop_index = 0
            #             else:
            #                 self.prop_index += 1
            #             self.state_l = StateLeft.IDLE
            #
            #     if self.state_l == StateLeft.DECREASE_OPERATOR:
            #         if ctrl_state_l.ulButtonPressed != 4294967296:
            #             # Modifico l'operazione booleana che verra' applicata scorrendo verso sinistra la lista delle possibili operazioni
            #             if self.prop_index <= 0:
            #                 self.prop_index = 2
            #             else:
            #                 self.prop_index -= 1
            #             self.state_l = StateLeft.IDLE
            #         #
            #     # 3# - - - - - - - - - - - - righe da aggiungere - - - - - - - - - - - - #3#
            #
            #     if self.state_l == StateLeft.INTERACTION_LOCAL:
            #         bpy.data.objects["Text.L"].data.body = "Interazione\n" + self.objToControll_l + "-" + self.boneToControll_l + "\n" + self.axes[self.curr_axes_l]
            #         tui_l.hide = True
            #         pointer.hide = True
            #
            #         if self.objToControll == self.objToControll_l \
            #                 and self.boneToControll == self.boneToControll_l \
            #                 and ctrl_state.ulButtonPressed == 8589934592\
            #                 and self.state != State.CAMERA_ROT_CONT \
            #                 and self.state != State.NAVIGATION:
            #             self.state_l = StateLeft.SCALING
            #             self.state = State.SCALING
            #
            #         else:
            #             if self.boneToControll_l != "":
            #                 ## The object to move is a bone
            #                 bone = bpy.data.objects[self.objToControll_l]
            #                 pbone = bone.pose.bones[self.boneToControll_l]
            #                 scale = copy.deepcopy(pbone.scale)
            #                 translationMatrix = Matrix(((0.0, 0.0, 0.0, self.diff_loc_l[0]),
            #                                             (0.0, 0.0, 0.0, self.diff_loc_l[1]),
            #                                             (0.0, 0.0, 0.0, self.diff_loc_l[2]),
            #                                             (0.0, 0.0, 0.0, 1.0)))
            #                 diff_rot_matr = self.diff_rot_l.to_matrix()
            #                 pbone.matrix = (ctrl_l.matrix_world + translationMatrix) * diff_rot_matr.to_4x4()
            #                 pbone.scale = scale
            #
            #                 self.applyConstraint(False)
            #
            #                 global local_repr_ON
            #                 if local_repr_ON and '_Local.Repr' in self.objToControll_l:
            #                     # Copy location and rotation to the target bone
            #                     pboneTarget = bpy.data.objects[self.objToControll_l.split('_Local.Repr')[0]].pose.bones[self.boneToControll_l]
            #                     pboneTarget.rotation_quaternion = copy.deepcopy(pbone.rotation_quaternion)
            #                     pboneTarget.location = copy.deepcopy(pbone.location)
            #
            #             else:
            #                 ## The object to move is a mesh
            #                 bpy.data.objects[self.objToControll_l].rotation_quaternion = ctrl_l.rotation_quaternion * self.diff_rot_l
            #                 bpy.data.objects[self.objToControll_l].location = ctrl_l.location + self.diff_loc_l
            #
            #                 self.applyConstraint(False)
            #
            #                 global local_repr_ON
            #                 if local_repr_ON and '_Local.Repr' in self.objToControll_l:
            #                     objTarget = bpy.data.objects[self.objToControll_l.split('_Local.Repr')[0]]
            #                     objTarget.rotation_quaternion = bpy.data.objects[self.objToControll_l].rotation_quaternion
            #
            #         if (ctrl_state_l.ulButtonPressed==8589934596):
            #             print("INTERACTION_LOCAL -> CHANGE_AXIS")
            #             self.state_l = StateLeft.CHANGE_AXES
            #
            #         if (ctrl_state_l.ulButtonPressed != 8589934592 and ctrl_state_l.ulButtonPressed != 8589934596):
            #             global mode
            #             if mode == "ACTION":
            #                 self.state_l = StateLeft.IDLE
            #                 print ("INTERACTION_LOCAL -> IDLE")
            #
            #     if self.state_l == StateLeft.DECISIONAL:
            #         bpy.data.objects["Text.L"].data.body = "Selezione\n" + self.objToControll_l + "-" + self.boneToControll_l
            #         tui_l.hide = False
            #         pointer.hide = False
            #
            #         # Compute the nearest object
            #         self.objToControll_l, self.boneToControll_l = self.getClosestItem(pointer, False)
            #         global currObject_l
            #         global currBone_l
            #         currObject_l = self.objToControll_l
            #         currBone_l = self.boneToControll_l
            #         print("Current obj:", self.objToControll_l, self.boneToControll_l)
            #
            #         if ctrl_state_l.ulButtonPressed != 4:
            #             #print("touch button released")
            #             self.changeSelection(self.objToControll_l, self.boneToControll_l, True)
            #             drawAction(self.objToControll_l, self.boneToControll_l, True, False)
            #             drawAction(self.objToControll, self.boneToControll, True, True)
            #             pointer.hide = True
            #
            #             if currObject_l != "" and len(bpy.data.objects[currObject_l].data.materials)>0:
            #                 if bpy.data.objects[currObject_l].material_slots[0].material.diffuse_color[0] <= 0.25 and \
            #                         'Materiale-Elemento-Selezionabile' in bpy.data.objects[currObject_l].material_slots[0].name:
            #                     bpy.data.objects[currObject_l].material_slots[0].material.diffuse_color[0] = 1
            #
            #                 elif bpy.data.objects[currObject_l].material_slots[0].material.diffuse_color[0] >= 0.95 and \
            #                         'Materiale-Elemento-Selezionabile' in bpy.data.objects[currObject_l].material_slots[0].name:
            #                     bpy.data.objects[currObject_l].material_slots[0].material.diffuse_color[0] = 0.2
            #
            #             global mode
            #             if mode == "ACTION":
            #                 self.state_l = StateLeft.IDLE
            #                 print ("DECISIONAL -> IDLE")
            #
            #     if self.state_l == StateLeft.CHANGE_AXES:
            #         if (ctrl_state_l.ulButtonPressed==8589934592):
            #             self.curr_axes_l+=1
            #             if self.curr_axes_l>=len(self.axes):
            #                 self.curr_axes_l=0
            #             self.curr_axes_r=0
            #             print(self.curr_axes_l)
            #             print("CHANGE_AXIS -> INTERACTION_LOCAL")
            #             self.state_l = StateLeft.INTERACTION_LOCAL
            #
            #         if (ctrl_state_l.ulButtonPressed==0):
            #             # print("grillet released")
            #             global mode
            #             if mode == "ACTION":
            #                 self.state_l = StateLeft.IDLE
            #                 print ("CHANGE_AXIS -> IDLE")
            #
            #     if self.state_l == StateLeft.SCALING:
            #         # Exit from Scaling state
            #         if (ctrl_state_l.ulButtonPressed != 8589934592):
            #             if (ctrl_state.ulButtonPressed != 8589934592):
            #                 global mode
            #                 if mode == "ACTION":
            #                     self.state = State.IDLE
            #                     self.state_l = StateLeft.IDLE
            #                     print ("SCALING -> IDLE")

            super(OpenVR, self).loop(context)

        except Exception as E:
            self.error("OpenVR.loop", E, False)
            return False

        #if VERBOSE:
        #    print("Left Eye Orientation Raw: " + str(self._eye_orientation_raw[0]))
        #    print("Right Eye Orientation Raw: " + str(self._eye_orientation_raw[1]))

        return True

    def frameReady(self):
        """
        The frame is ready to be sent to the device
        """
        try:
            self._hmd.frameReady()

        except Exception as E:
            self.error("OpenVR.frameReady", E, False)
            return False

        return True

    def reCenter(self):
        """
        Re-center the HMD device

        :return: return True if success
        :rtype: bool
        """
        return self._hmd.reCenter()

    def quit(self):
        """
        Garbage collection
        """
        self._hmd = None
        return super(OpenVR, self).quit()



